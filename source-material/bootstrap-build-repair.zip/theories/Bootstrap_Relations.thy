theory Bootstrap_Relations
  imports Main
begin

section \<open>Finite extensional relations\<close>

text \<open>
  These definitions are mathematical conveniences only.  They introduce no
  stored map object and no procedural reading.  Whenever a relation is used as
  a map, its exact graph is the fact being supplied.
\<close>

definition rel_dom :: "('a \<times> 'b) set \<Rightarrow> 'a set" where
  "rel_dom R = {x. \<exists>y. (x,y) \<in> R}"

definition rel_ran :: "('a \<times> 'b) set \<Rightarrow> 'b set" where
  "rel_ran R = {y. \<exists>x. (x,y) \<in> R}"

definition single_valued :: "('a \<times> 'b) set \<Rightarrow> bool" where
  "single_valued R \<longleftrightarrow> (\<forall>x y z. (x,y) \<in> R \<longrightarrow> (x,z) \<in> R \<longrightarrow> y = z)"

definition total_on :: "'a set \<Rightarrow> ('a \<times> 'b) set \<Rightarrow> bool" where
  "total_on A R \<longleftrightarrow> rel_dom R = A"

definition graph_map :: "'a set \<Rightarrow> ('a \<Rightarrow> 'b) \<Rightarrow> ('a \<times> 'b) set" where
  "graph_map A f = {(x,f x) |x. x \<in> A}"

definition rel_value :: "('a \<times> 'b) set \<Rightarrow> 'a \<Rightarrow> 'b" where
  "rel_value R x = (THE y. (x,y) \<in> R)"

definition exact_map :: "'a set \<Rightarrow> 'b set \<Rightarrow> ('a \<times> 'b) set \<Rightarrow> bool" where
  "exact_map A B R \<longleftrightarrow>
     finite A \<and> finite B \<and> finite R \<and>
     single_valued R \<and> rel_dom R = A \<and> rel_ran R = B"

lemma graph_map_single_valued:
  "single_valued (graph_map A f)"
  by (auto simp: single_valued_def graph_map_def)

lemma graph_map_dom:
  "rel_dom (graph_map A f) = A"
  by (auto simp: rel_dom_def graph_map_def)

lemma graph_map_ran:
  "rel_ran (graph_map A f) = f ` A"
  by (auto simp: rel_ran_def graph_map_def)

lemma rel_value_graph_map:
  assumes "x \<in> A"
  shows "rel_value (graph_map A f) x = f x"
  using assms by (simp add: rel_value_def graph_map_def)

lemma rel_value_eq:
  assumes "single_valued R" "(x,y) \<in> R"
  shows "rel_value R x = y"
  unfolding rel_value_def
  by (rule the_equality) (use assms in \<open>auto simp: single_valued_def\<close>)

lemma exact_map_value:
  assumes "exact_map A B R" "x \<in> A"
  shows "(x, rel_value R x) \<in> R"
proof -
  from assms have "x \<in> rel_dom R"
    by (simp add: exact_map_def)
  then obtain y where xy: "(x,y) \<in> R"
    by (auto simp: rel_dom_def)
  from assms have sv: "single_valued R"
    by (simp add: exact_map_def)
  have "(THE z. (x,z) \<in> R) = y"
    by (rule the_equality) (use xy sv in \<open>auto simp: single_valued_def\<close>)
  with xy show ?thesis
    by (simp add: rel_value_def)
qed

lemma exact_map_value_in_ran:
  assumes "exact_map A B R" "x \<in> A"
  shows "rel_value R x \<in> B"
  using exact_map_value[OF assms] assms
  by (auto simp: exact_map_def rel_ran_def)

lemma exact_map_surjective:
  assumes "exact_map A B R" "y \<in> B"
  shows "\<exists>x \<in> A. (x,y) \<in> R"
  using assms unfolding exact_map_def rel_dom_def rel_ran_def by blast

definition relation_image ::
  "('a \<times> 'b) set \<Rightarrow> ('a \<times> 'a) set \<Rightarrow> ('b \<times> 'b) set" where
  "relation_image f R =
     {(rel_value f x, rel_value f y) |x y. (x,y) \<in> R}"

definition ternary_image ::
  "('a \<times> 'b) set \<Rightarrow> ('a \<times> 'a \<times> 'a) set \<Rightarrow> ('b \<times> 'b \<times> 'b) set" where
  "ternary_image f R =
     {(rel_value f r, rel_value f p, rel_value f x) |r p x.
        (r,p,x) \<in> R}"

section \<open>Finite ancestry\<close>

text \<open>Only direct edges are stored.  Transitive ancestry is always derived.\<close>

definition strict_ancestor :: "('a \<times> 'a) set \<Rightarrow> 'a \<Rightarrow> 'a \<Rightarrow> bool" where
  "strict_ancestor E x y \<longleftrightarrow> (x,y) \<in> E\<^sup>+"

definition acyclic_edges :: "('a \<times> 'a) set \<Rightarrow> bool" where
  "acyclic_edges E \<longleftrightarrow> (\<forall>x. (x,x) \<notin> E\<^sup>+)"

lemma strict_ancestor_irrefl:
  assumes "acyclic_edges E"
  shows "\<not> strict_ancestor E x x"
  using assms by (simp add: acyclic_edges_def strict_ancestor_def)

lemma strict_ancestor_trans:
  assumes "strict_ancestor E x y" "strict_ancestor E y z"
  shows "strict_ancestor E x z"
  using assms unfolding strict_ancestor_def by (meson trancl_trans)

end
