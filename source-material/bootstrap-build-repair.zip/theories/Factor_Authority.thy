theory Factor_Authority
  imports Factor_Evidence
begin

section \<open>Exact authority applications\<close>

definition factor_application_exact ::
  "artifact_resolver \<Rightarrow> exact_anchor \<Rightarrow> exact_anchor \<Rightarrow> exact_anchor list \<Rightarrow> bool" where
  "factor_application_exact \<rho> j definition arguments \<longleftrightarrow>
     (\<exists>J. factor_judgment_at \<rho> j J \<and>
          judgment_definition J = definition \<and>
          judgment_arguments J = arguments)"

definition factor_adopts ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow>
   exact_anchor \<Rightarrow> exact_anchor \<Rightarrow> exact_anchor \<Rightarrow> exact_anchor \<Rightarrow>
   exact_anchor \<Rightarrow> exact_anchor \<Rightarrow> bool" where
  "factor_adopts \<rho> \<Phi> adoption_definition judgment authority subject purpose basis \<longleftrightarrow>
     factor_application_exact \<rho> judgment adoption_definition
       [authority,subject,purpose,basis] \<and>
     factor_holds \<rho> \<Phi> judgment"

text \<open>
  Adoption is an exact Factor judgment.  It neither proves its subject nor
  changes the subject's structure.  Different authority, purpose, basis, or
  foundation arguments produce different judgments.
\<close>

section \<open>Publication-relative currentness\<close>

definition publication_anchor :: "publication \<Rightarrow> exact_anchor" where
  "publication_anchor P =
     Occurrence_Citation (publication_reference P) (publication_root P)"

definition factor_current ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> exact_anchor \<Rightarrow> exact_anchor \<Rightarrow>
   exact_anchor \<Rightarrow> publication \<Rightarrow> exact_anchor \<Rightarrow> exact_anchor \<Rightarrow> exact_anchor \<Rightarrow> bool" where
  "factor_current \<rho> \<Phi> current_definition judgment authority P locus generation purpose \<longleftrightarrow>
     publication_formed \<rho> P \<and>
     (locus,generation) \<in>
       publication_selections (projected_publication \<rho> P) \<and>
     factor_application_exact \<rho> judgment current_definition
       [authority,publication_anchor P,locus,generation,purpose] \<and>
     factor_holds \<rho> \<Phi> judgment"

lemma factor_current_has_exact_publication:
  assumes "factor_current \<rho> \<Phi> d j A P l g purpose"
  shows "publication_formed \<rho> P \<and>
         (l,g) \<in> publication_selections (projected_publication \<rho> P)"
  using assms by (simp add: factor_current_def)

text \<open>
  There is intentionally no unqualified current predicate.  Removing any of
  foundation, authority, publication, locus, generation, or purpose changes the
  question rather than abbreviating it.
\<close>

section \<open>Certified immutable advancement\<close>

definition generation_in_trajectory ::
  "artifact_resolver \<Rightarrow> trajectory \<Rightarrow> local_address \<Rightarrow>
   generation_projection \<Rightarrow> bool" where
  "generation_in_trajectory \<rho> T g G \<longleftrightarrow>
     trajectory_formed \<rho> T \<and>
     g \<in> trajectory_generation_roots \<rho> T \<and>
     generation_at \<rho> (trajectory_artifact \<rho> T) g G"

definition factor_advances ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> trajectory \<Rightarrow> local_address \<Rightarrow>
   exact_anchor \<Rightarrow> factor_derivation \<Rightarrow> evidence_envelope \<Rightarrow>
   local_address assembly_witness \<Rightarrow> bool" where
  "factor_advances \<rho> \<Phi> T g' j D E W \<longleftrightarrow>
     (\<exists>G C out_ref.
        generation_in_trajectory \<rho> T g' G \<and>
        factor_construction_at \<rho> j C \<and>
        factor_certifies \<rho> \<Phi> E j D W \<and>
        generation_payload G = Whole_Artifact out_ref \<and>
        resolves \<rho> out_ref (assembly_output W) \<and>
        generation_predecessors G \<union> generation_dependencies G =
          set (construction_inputs C) \<and>
        evidence_envelope_anchor E \<in> generation_evidence G)"

lemma factor_advances_is_certified_construction:
  assumes "factor_advances \<rho> \<Phi> T g j D E W"
  shows "factor_certifies \<rho> \<Phi> E j D W \<and> K2 W"
  using assms factor_certifies_sound
  by (auto simp: factor_advances_def)

lemma factor_advances_payload_is_output:
  assumes "factor_advances \<rho> \<Phi> T g j D E W"
  shows "\<exists>G out_ref.
           generation_in_trajectory \<rho> T g G \<and>
           generation_payload G = Whole_Artifact out_ref \<and>
           resolves \<rho> out_ref (assembly_output W)"
  using assms by (auto simp: factor_advances_def)

text \<open>
  Advancement relates immutable structures.  Branches are multiple generations
  with a common predecessor; a merge is a later certified construction whose
  predecessor set contains the merged generations.  No transaction, lock,
  compare-and-swap, clock, or mutable head belongs to this semantics.
\<close>

end
