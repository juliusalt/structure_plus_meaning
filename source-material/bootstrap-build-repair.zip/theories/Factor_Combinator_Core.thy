theory Factor_Combinator_Core
  imports RRA_Trajectory
begin

section \<open>A pure structurally quoted universal calculus\<close>

text \<open>
  SK is used only because it gives the smallest convenient universality witness.
  Its constructors below are a metalevel proof instrument.  A term admitted to
  Factor is recovered from incidence topology: zero fields is K, one self field
  is S, and two fields is application.  No constructor name is stored.
\<close>

datatype sk_term =
    SK_K
  | SK_S
  | SK_App sk_term sk_term

inductive raw_sk_term_at :: "exact_artifact \<Rightarrow> local_address \<Rightarrow> sk_term \<Rightarrow> bool" where
  raw_term_K:
    "record_at (object_structure E) r [] \<Longrightarrow> raw_sk_term_at E r SK_K"
| raw_term_S:
    "record_at (object_structure E) r [r] \<Longrightarrow> raw_sk_term_at E r SK_S"
| raw_term_App:
    "record_at (object_structure E) r [l,u] \<Longrightarrow>
     raw_sk_term_at E l x \<Longrightarrow> raw_sk_term_at E u y \<Longrightarrow>
     raw_sk_term_at E r (SK_App x y)"

definition sk_term_at :: "exact_artifact \<Rightarrow> local_address \<Rightarrow> sk_term \<Rightarrow> bool" where
  "sk_term_at E r t \<longleftrightarrow>
     raw_sk_term_at E r t \<and> (\<forall>u. raw_sk_term_at E r u \<longrightarrow> u = t)"

lemma sk_term_at_unique:
  assumes "sk_term_at E r t" "sk_term_at E r u"
  shows "t = u"
  using assms by (auto simp: sk_term_at_def)

definition quoted_sk_term ::
  "artifact_resolver \<Rightarrow> exact_anchor \<Rightarrow> sk_term \<Rightarrow> bool" where
  "quoted_sk_term \<rho> a t \<longleftrightarrow>
     (case a of
        Whole_Artifact ref \<Rightarrow> False
      | Occurrence_Citation ref root \<Rightarrow>
          (\<exists>E.
             resolves \<rho> ref E \<and> exact_formed E \<and>
             sk_term_at E root t))"

lemma quoted_sk_term_unique:
  assumes "resolver_formed \<rho>" "quoted_sk_term \<rho> a t" "quoted_sk_term \<rho> a u"
  shows "t = u"
  using assms sk_term_at_unique
  by (cases a) (auto simp: quoted_sk_term_def dest: resolver_non_rebinding)

inductive sk_step :: "sk_term \<Rightarrow> sk_term \<Rightarrow> bool" where
  K_step:
    "sk_step (SK_App (SK_App SK_K x) y) x"
| S_step:
    "sk_step
       (SK_App (SK_App (SK_App SK_S x) y) z)
       (SK_App (SK_App x z) (SK_App y z))"
| App_left:
    "sk_step x x' \<Longrightarrow> sk_step (SK_App x y) (SK_App x' y)"
| App_right:
    "sk_step y y' \<Longrightarrow> sk_step (SK_App x y) (SK_App x y')"

definition sk_reduces :: "sk_term \<Rightarrow> sk_term \<Rightarrow> bool" where
  "sk_reduces x y \<longleftrightarrow> rtranclp sk_step x y"

section \<open>The definition itself is selected by topology\<close>

text \<open>
  A combinator-step definition is a rooted exact artifact containing precisely a
  two-field record whose children are structurally recovered S and K terms.  S
  and K are not selected by byte names or an external registry.
\<close>

definition raw_combinator_step_definition ::
  "artifact_resolver \<Rightarrow> exact_anchor \<Rightarrow> bool" where
  "raw_combinator_step_definition \<rho> d \<longleftrightarrow>
     (case d of
        Whole_Artifact ref \<Rightarrow> False
      | Occurrence_Citation ref root \<Rightarrow>
          (\<exists>E s k.
             resolves \<rho> ref E \<and> exact_formed E \<and>
             rooted_complete (object_structure E) root \<and>
             record_at (object_structure E) root [s,k] \<and>
             sk_term_at E s SK_S \<and>
             sk_term_at E k SK_K))"

definition combinator_step_definition ::
  "artifact_resolver \<Rightarrow> exact_anchor \<Rightarrow> bool" where
  "combinator_step_definition \<rho> d \<longleftrightarrow> raw_combinator_step_definition \<rho> d"

text \<open>
  The relation is intentionally small and pure.  Its use as a Factor program is
  defined later only when a concrete judgment also contains a complete K2
  assembly quote and an independently cited output artifact.
\<close>

end
