theory Factor_Construction
  imports Factor_Derivation
begin

section \<open>Structurally closed construction applications\<close>

record factor_construction_projection =
  construction_program :: exact_anchor
  construction_inputs :: "exact_anchor list"
  construction_assembly :: structural_assembly
  construction_output :: exact_anchor

definition raw_factor_construction ::
  "artifact_resolver \<Rightarrow> exact_anchor \<Rightarrow> factor_construction_projection \<Rightarrow> bool" where
  "raw_factor_construction \<rho> j C \<longleftrightarrow>
     (\<exists>J input_bundle.
        factor_judgment_at \<rho> j J \<and>
        judgment_definition J = construction_program C \<and>
        judgment_arguments J =
          [input_bundle,
           structural_assembly_anchor (construction_assembly C),
           construction_output C] \<and>
        anchor_record_bundle \<rho> input_bundle (construction_inputs C))"

definition factor_construction_at ::
  "artifact_resolver \<Rightarrow> exact_anchor \<Rightarrow> factor_construction_projection \<Rightarrow> bool" where
  "factor_construction_at \<rho> j C \<longleftrightarrow>
     raw_factor_construction \<rho> j C \<and>
     (\<forall>D. raw_factor_construction \<rho> j D \<longrightarrow> D = C)"

lemma factor_construction_unique:
  assumes "factor_construction_at \<rho> j C" "factor_construction_at \<rho> j D"
  shows "C = D"
  using assms by (auto simp: factor_construction_at_def)

definition construction_output_resolves ::
  "artifact_resolver \<Rightarrow> factor_construction_projection \<Rightarrow> exact_artifact \<Rightarrow> bool" where
  "construction_output_resolves \<rho> C R \<longleftrightarrow>
     anchor_formed \<rho> (construction_output C) \<and>
     anchor_artifact \<rho> (construction_output C) = R"

definition factor_constructs ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> exact_anchor \<Rightarrow>
   local_address assembly_witness \<Rightarrow> bool" where
  "factor_constructs \<rho> \<Phi> j W \<longleftrightarrow>
     (\<exists>C.
        factor_construction_at \<rho> j C \<and>
        factor_holds \<rho> \<Phi> j \<and>
        structural_assembly_formed \<rho> (construction_assembly C) \<and>
        assembly_quote_at \<rho> (construction_assembly C) W \<and>
        construction_output_resolves \<rho> C (assembly_output W))"

lemma factor_constructs_has_one_K2_account:
  assumes "factor_constructs \<rho> \<Phi> j W"
  shows "K2 W"
  using assms structural_assembly_quote_K2
  by (auto simp: factor_constructs_def)

lemma factor_constructs_output_is_cited:
  assumes "factor_constructs \<rho> \<Phi> j W"
  shows "\<exists>C. factor_construction_at \<rho> j C \<and>
             anchor_formed \<rho> (construction_output C) \<and>
             anchor_artifact \<rho> (construction_output C) = assembly_output W"
  using assms
  by (auto simp: factor_constructs_def construction_output_resolves_def)

lemma factor_constructs_no_unexplained_output:
  assumes "factor_constructs \<rho> \<Phi> j W"
      and "a \<in> rra_carrier (object_structure (assembly_output W))"
  shows "\<exists>c \<in> copied_carrier (assembly_pieces W).
           (c,a) \<in> assembly_origin W"
  using K2_no_unexplained_output_atom factor_constructs_has_one_K2_account
        assms by blast

section \<open>Construction is not evaluation\<close>

text \<open>
  A candidate constructor may search for a finite W satisfying
  factor_constructs.  Search order, allocation, scheduling, failure to find a
  witness, and physical execution are absent from the relation.  The output is
  the independently cited assembly output; it is neither the artifact quoting
  j nor the artifact quoting W.
\<close>

definition function_like ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> exact_anchor \<Rightarrow> bool" where
  "function_like \<rho> \<Phi> program \<longleftrightarrow>
     (\<forall>j W j' W' C C'.
        factor_constructs \<rho> \<Phi> j W \<and>
        factor_constructs \<rho> \<Phi> j' W' \<and>
        factor_construction_at \<rho> j C \<and>
        factor_construction_at \<rho> j' C' \<and>
        construction_program C = program \<and>
        construction_program C' = program \<and>
        construction_inputs C = construction_inputs C' \<longrightarrow>
        rra_isomorphic (object_structure (assembly_output W))
                       (object_structure (assembly_output W')))"

text \<open>
  Functionality is a theorem about a structurally defined program relation.  It
  is not a primitive category of program and does not privilege one evaluator.
\<close>

end
