theory Factor_Evidence
  imports Factor_Construction
begin

section \<open>Factor recognition of retained evidence\<close>

definition factor_foundation_anchor ::
  "factor_foundation \<Rightarrow> exact_anchor" where
  "factor_foundation_anchor \<Phi> =
     Occurrence_Citation (foundation_reference \<Phi>) (foundation_root \<Phi>)"

definition factor_derivation_anchor ::
  "factor_derivation \<Rightarrow> exact_anchor" where
  "factor_derivation_anchor D =
     Occurrence_Citation (derivation_reference D) (derivation_root D)"

definition required_certificate_links ::
  "factor_foundation \<Rightarrow> factor_derivation \<Rightarrow> structural_assembly \<Rightarrow>
   exact_anchor \<Rightarrow> (exact_anchor \<times> exact_anchor) set" where
  "required_certificate_links \<Phi> D A j =
     {(j, factor_derivation_anchor D),
      (j, structural_assembly_anchor A),
      (factor_derivation_anchor D, factor_foundation_anchor \<Phi>)}"

definition factor_certifies ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> evidence_envelope \<Rightarrow>
   exact_anchor \<Rightarrow> factor_derivation \<Rightarrow> local_address assembly_witness \<Rightarrow> bool" where
  "factor_certifies \<rho> \<Phi> E j D W \<longleftrightarrow>
     evidence_envelope_formed \<rho> E \<and>
     factor_derives \<rho> \<Phi> D j \<and>
     factor_constructs \<rho> \<Phi> j W \<and>
     (\<exists>C.
        factor_construction_at \<rho> j C \<and>
        required_certificate_links \<Phi> D (construction_assembly C) j
          \<subseteq> envelope_links \<rho> E)"

lemma factor_certifies_derivation:
  assumes "factor_certifies \<rho> \<Phi> E j D W"
  shows "factor_derives \<rho> \<Phi> D j"
  using assms by (simp add: factor_certifies_def)

lemma factor_certifies_construction:
  assumes "factor_certifies \<rho> \<Phi> E j D W"
  shows "factor_constructs \<rho> \<Phi> j W"
  using assms by (simp add: factor_certifies_def)

lemma factor_certifies_sound:
  assumes "factor_certifies \<rho> \<Phi> E j D W"
  shows "factor_holds \<rho> \<Phi> j \<and> K2 W"
  using assms factor_derives_sound factor_constructs_has_one_K2_account
  by (auto simp: factor_certifies_def)

section \<open>Replay without semantic duplication\<close>

text \<open>
  Replay checks that a valid derivation, its exact assembly, and their retained
  citations occur together.  It does not add a second truth relation.  Its
  semantic consequence is inherited solely from factor_derives_sound.
\<close>

definition factor_replays ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> evidence_envelope \<Rightarrow>
   exact_anchor \<Rightarrow> factor_derivation \<Rightarrow> local_address assembly_witness \<Rightarrow> bool" where
  "factor_replays \<rho> \<Phi> E j D W \<longleftrightarrow> factor_certifies \<rho> \<Phi> E j D W"

lemma factor_replays_sound:
  assumes "factor_replays \<rho> \<Phi> E j D W"
  shows "factor_holds \<rho> \<Phi> j \<and> factor_constructs \<rho> \<Phi> j W \<and> K2 W"
  using assms factor_certifies_sound factor_certifies_construction
  by (auto simp: factor_replays_def)

text \<open>
  Additional envelope links may retain sources, correspondence, challenges,
  residuals, or provenance.  They acquire a role only through further exact
  Factor definitions.  Their mere presence cannot change the conclusion of the
  derivation retained here.
\<close>

end
