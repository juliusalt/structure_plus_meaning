theory Factor_Semantics
  imports Factor_Combinator_Core
begin

section \<open>Structural judgments\<close>

text \<open>
  The records in this theory are uniquely recovered metalevel projections.  No
  public judgment accepts one without the exact RRA artifact and incidence
  pattern that determine it.  Their field names carry no stored or independently
  supplied semantic force.
\<close>

record factor_judgment_projection =
  judgment_definition :: exact_anchor
  judgment_arguments :: "exact_anchor list"

definition anchor_record_at ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow> exact_anchor list \<Rightarrow> bool" where
  "anchor_record_at \<rho> E root A \<longleftrightarrow>
     (\<exists>R.
        record_at (object_structure E) root R \<and>
        length R = length A \<and>
        (\<forall>i < length R. anchored_at \<rho> E (R ! i) (A ! i)))"

definition anchor_record_bundle ::
  "artifact_resolver \<Rightarrow> exact_anchor \<Rightarrow> exact_anchor list \<Rightarrow> bool" where
  "anchor_record_bundle \<rho> a A \<longleftrightarrow>
     (case a of
        Whole_Artifact r \<Rightarrow> False
      | Occurrence_Citation r root \<Rightarrow>
          (\<exists>E. resolves \<rho> r E \<and> anchor_record_at \<rho> E root A))"

definition raw_factor_judgment ::
  "artifact_resolver \<Rightarrow> exact_anchor \<Rightarrow> factor_judgment_projection \<Rightarrow> bool" where
  "raw_factor_judgment \<rho> j J \<longleftrightarrow>
     (case j of
        Whole_Artifact r \<Rightarrow> False
      | Occurrence_Citation r root \<Rightarrow>
          (\<exists>E dr ar.
             resolves \<rho> r E \<and>
             record_at (object_structure E) root [dr,ar] \<and>
             anchored_at \<rho> E dr (judgment_definition J) \<and>
             anchor_record_at \<rho> E ar (judgment_arguments J)))"

lemma anchor_record_at_unique:
  assumes "anchor_record_at \<rho> E root A" "anchor_record_at \<rho> E root B"
  shows "A = B"
proof -
  from assms obtain X Y where
    x: "record_at (object_structure E) root X"
    and y: "record_at (object_structure E) root Y"
    and lengths: "length X = length A" "length Y = length B"
    and a: "\<forall>i < length X. anchored_at \<rho> E (X ! i) (A ! i)"
    and b: "\<forall>i < length Y. anchored_at \<rho> E (Y ! i) (B ! i)"
    by (auto simp: anchor_record_at_def)
  have xy: "X = Y" by (rule record_at_unique[OF x y])
  show ?thesis
  proof (rule nth_equalityI)
    show "length A = length B" using lengths xy by simp
    fix i assume "i < length A"
    then show "A ! i = B ! i"
      using a b lengths xy anchored_at_unique[of \<rho> E "X ! i" "A ! i" "B ! i"]
      by auto
  qed
qed

lemma anchor_record_bundle_unique:
  assumes "resolver_formed \<rho>" "anchor_record_bundle \<rho> a A" "anchor_record_bundle \<rho> a B"
  shows "A = B"
  using assms
  by (cases a) (auto simp: anchor_record_bundle_def
    dest: resolver_non_rebinding intro: anchor_record_at_unique)

definition factor_judgment_at ::
  "artifact_resolver \<Rightarrow> exact_anchor \<Rightarrow> factor_judgment_projection \<Rightarrow> bool" where
  "factor_judgment_at \<rho> j J \<longleftrightarrow>
     raw_factor_judgment \<rho> j J \<and>
     (\<forall>K. raw_factor_judgment \<rho> j K \<longrightarrow> K = J)"

definition formed_factor_judgment ::
  "artifact_resolver \<Rightarrow> exact_anchor \<Rightarrow> bool" where
  "formed_factor_judgment \<rho> j \<longleftrightarrow> (\<exists>!J. factor_judgment_at \<rho> j J)"

lemma factor_judgment_unique:
  assumes "factor_judgment_at \<rho> j J" "factor_judgment_at \<rho> j K"
  shows "J = K"
  using assms by (auto simp: factor_judgment_at_def)

definition projected_judgment ::
  "artifact_resolver \<Rightarrow> exact_anchor \<Rightarrow> factor_judgment_projection" where
  "projected_judgment \<rho> j = (THE J. factor_judgment_at \<rho> j J)"

section \<open>Ground structural clauses\<close>

record factor_clause_projection =
  clause_premises :: "exact_anchor set"
  clause_conclusion :: exact_anchor

definition raw_factor_clause ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow>
   factor_clause_projection \<Rightarrow> bool" where
  "raw_factor_clause \<rho> E c C \<longleftrightarrow>
     (\<exists>pr cr.
        record_at (object_structure E) c [pr,cr] \<and>
        anchor_family_at \<rho> E pr (clause_premises C) \<and>
        anchored_at \<rho> E cr (clause_conclusion C))"

definition factor_clause_at ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow>
   factor_clause_projection \<Rightarrow> bool" where
  "factor_clause_at \<rho> E c C \<longleftrightarrow>
     raw_factor_clause \<rho> E c C \<and>
     (\<forall>D. raw_factor_clause \<rho> E c D \<longrightarrow> D = C)"

lemma factor_clause_unique:
  assumes "factor_clause_at \<rho> E c C" "factor_clause_at \<rho> E c D"
  shows "C = D"
  using assms by (auto simp: factor_clause_at_def)

section \<open>Exact foundations\<close>

record factor_foundation_projection =
  foundation_primitives :: "exact_anchor set"
  foundation_seeds :: "exact_anchor set"
  foundation_clauses :: "factor_clause_projection set"
  foundation_dependencies :: "exact_anchor set"

record factor_foundation =
  foundation_reference :: artifact_reference
  foundation_root :: local_address

definition factor_foundation_artifact ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> exact_artifact" where
  "factor_foundation_artifact \<rho> \<Phi> = rel_value \<rho> (foundation_reference \<Phi>)"

definition clause_family_at ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow>
   factor_clause_projection set \<Rightarrow> bool" where
  "clause_family_at \<rho> E root C \<longleftrightarrow>
     (\<exists>R.
        family_at (object_structure E) root R \<and>
        (\<forall>r \<in> R. \<exists>!c. factor_clause_at \<rho> E r c) \<and>
        C = {c. \<exists>r \<in> R. factor_clause_at \<rho> E r c})"

definition raw_factor_foundation_at ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow>
   factor_foundation_projection \<Rightarrow> bool" where
  "raw_factor_foundation_at \<rho> E root F \<longleftrightarrow>
     (\<exists>pr sr cr dr.
        record_at (object_structure E) root [pr,sr,cr,dr] \<and>
        anchor_family_at \<rho> E pr (foundation_primitives F) \<and>
        anchor_family_at \<rho> E sr (foundation_seeds F) \<and>
        clause_family_at \<rho> E cr (foundation_clauses F) \<and>
        anchor_family_at \<rho> E dr (foundation_dependencies F))"

definition factor_foundation_at ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow>
   factor_foundation_projection \<Rightarrow> bool" where
  "factor_foundation_at \<rho> E root F \<longleftrightarrow>
     raw_factor_foundation_at \<rho> E root F \<and>
     (\<forall>G. raw_factor_foundation_at \<rho> E root G \<longrightarrow> G = F)"

definition factor_foundation_formed ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> bool" where
  "factor_foundation_formed \<rho> \<Phi> \<longleftrightarrow>
     resolver_formed \<rho> \<and>
     resolves \<rho> (foundation_reference \<Phi>) (factor_foundation_artifact \<rho> \<Phi>) \<and>
     exact_formed (factor_foundation_artifact \<rho> \<Phi>) \<and>
     rooted_complete (object_structure (factor_foundation_artifact \<rho> \<Phi>))
                     (foundation_root \<Phi>) \<and>
     (\<exists>!F. factor_foundation_at \<rho> (factor_foundation_artifact \<rho> \<Phi>)
                                    (foundation_root \<Phi>) F) \<and>
     (\<forall>F. factor_foundation_at \<rho> (factor_foundation_artifact \<rho> \<Phi>)
                                  (foundation_root \<Phi>) F \<longrightarrow>
        (\<forall>p \<in> foundation_primitives F. combinator_step_definition \<rho> p) \<and>
        (\<forall>j \<in> foundation_seeds F. formed_factor_judgment \<rho> j) \<and>
        (\<forall>C \<in> foundation_clauses F.
           formed_factor_judgment \<rho> (clause_conclusion C) \<and>
           (\<forall>j \<in> clause_premises C. formed_factor_judgment \<rho> j)) \<and>
        (\<forall>d \<in> foundation_dependencies F. anchor_formed \<rho> d))"

definition projected_foundation ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> factor_foundation_projection" where
  "projected_foundation \<rho> \<Phi> =
     (THE F. factor_foundation_at \<rho> (factor_foundation_artifact \<rho> \<Phi>)
                                     (foundation_root \<Phi>) F)"

section \<open>Pure combinator construction is a structural primitive\<close>

text \<open>
  The only bootstrap computational primitive is the topology-recognized SK
  relation.  A primitive judgment is accepted only when it also cites a complete
  structural assembly quote and an independently resolved output artifact.
\<close>

definition combinator_construction_holds ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> exact_anchor \<Rightarrow> bool" where
  "combinator_construction_holds \<rho> \<Phi> j \<longleftrightarrow>
     (\<exists>J input_bundle input A W output t u.
        factor_judgment_at \<rho> j J \<and>
        judgment_definition J \<in>
          foundation_primitives (projected_foundation \<rho> \<Phi>) \<and>
        combinator_step_definition \<rho> (judgment_definition J) \<and>
        judgment_arguments J =
          [input_bundle,structural_assembly_anchor A,output] \<and>
        anchor_record_bundle \<rho> input_bundle [input] \<and>
        structural_assembly_formed \<rho> A \<and>
        assembly_quote_at \<rho> A W \<and>
        anchor_formed \<rho> output \<and>
        anchor_artifact \<rho> output = assembly_output W \<and>
        quoted_sk_term \<rho> input t \<and>
        quoted_sk_term \<rho> output u \<and>
        sk_step t u)"

section \<open>Least structural meaning\<close>

inductive_set factor_closure ::
  "factor_clause_projection set \<Rightarrow> exact_anchor set \<Rightarrow> exact_anchor set"
  for C S
where
  seed[intro]: "j \<in> S \<Longrightarrow> j \<in> factor_closure C S"
| consequence[intro]:
    "c \<in> C \<Longrightarrow> (\<And>p. p \<in> clause_premises c \<Longrightarrow> p \<in> factor_closure C S) \<Longrightarrow>
     clause_conclusion c \<in> factor_closure C S"

definition factor_holds ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> exact_anchor \<Rightarrow> bool" where
  "factor_holds \<rho> \<Phi> j \<longleftrightarrow>
     factor_foundation_formed \<rho> \<Phi> \<and>
     formed_factor_judgment \<rho> j \<and>
      j \<in> factor_closure
            (foundation_clauses (projected_foundation \<rho> \<Phi>))
            (foundation_seeds (projected_foundation \<rho> \<Phi>) \<union>
             {k. combinator_construction_holds \<rho> \<Phi> k})"

lemma factor_holds_is_structurally_grounded:
  assumes "factor_holds \<rho> \<Phi> j"
  shows "factor_foundation_formed \<rho> \<Phi> \<and> formed_factor_judgment \<rho> j"
  using assms by (simp add: factor_holds_def)

lemma factor_seed_holds:
  assumes formed: "factor_foundation_formed \<rho> \<Phi>"
      and seed: "j \<in> foundation_seeds (projected_foundation \<rho> \<Phi>)"
      and jformed: "formed_factor_judgment \<rho> j"
  shows "factor_holds \<rho> \<Phi> j"
  using assms by (auto simp: factor_holds_def)

lemma combinator_factor_holds:
  assumes formed: "factor_foundation_formed \<rho> \<Phi>"
      and jformed: "formed_factor_judgment \<rho> j"
      and primitive: "combinator_construction_holds \<rho> \<Phi> j"
  shows "factor_holds \<rho> \<Phi> j"
  using assms by (auto simp: factor_holds_def)

text \<open>
  Apart from the structurally quoted universal combinator relation, meaning is
  the explicit least finite-derivation closure of exact ground clauses.  There
  is no callback selected by a predicate name and no nominal syntax tree
  accepted in place of its quotation.
\<close>

end
