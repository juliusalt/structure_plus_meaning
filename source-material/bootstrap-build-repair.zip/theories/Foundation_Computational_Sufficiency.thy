theory Foundation_Computational_Sufficiency
  imports Foundation_Genesis
begin

section \<open>Factor realization of pure SK reduction\<close>

definition sk_factor_step ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> exact_anchor \<Rightarrow>
   exact_anchor \<Rightarrow> sk_term \<Rightarrow> exact_anchor \<Rightarrow> sk_term \<Rightarrow>
   exact_anchor \<Rightarrow> local_address assembly_witness \<Rightarrow> bool" where
  "sk_factor_step \<rho> \<Phi> program input t output u j W \<longleftrightarrow>
     quoted_sk_term \<rho> input t \<and>
     quoted_sk_term \<rho> output u \<and>
     combinator_construction_holds \<rho> \<Phi> j \<and>
     factor_constructs \<rho> \<Phi> j W \<and>
     (\<exists>C.
        factor_construction_at \<rho> j C \<and>
        construction_program C = program \<and>
        construction_inputs C = [input] \<and>
        construction_output C = output)"

definition sk_program_complete ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> exact_anchor \<Rightarrow> bool" where
  "sk_program_complete \<rho> \<Phi> program \<longleftrightarrow>
     factor_foundation_formed \<rho> \<Phi> \<and>
     program \<in> foundation_primitives (projected_foundation \<rho> \<Phi>) \<and>
     combinator_step_definition \<rho> program \<and>
     (\<forall>input t output u j W.
        sk_factor_step \<rho> \<Phi> program input t output u j W \<longrightarrow> sk_step t u) \<and>
     (\<forall>input t u.
        quoted_sk_term \<rho> input t \<and> sk_step t u \<longrightarrow>
        (\<exists>output j W.
           sk_factor_step \<rho> \<Phi> program input t output u j W))"

lemma sk_factor_step_sound:
  assumes "sk_factor_step \<rho> \<Phi> program input t output u j W"
  shows "sk_step t u"
proof -
  from assms obtain C where fc: "factor_constructs \<rho> \<Phi> j W"
    and ca: "factor_construction_at \<rho> j C"
    and inp: "construction_inputs C = [input]"
    and out: "construction_output C = output"
    and qt: "quoted_sk_term \<rho> input t" and qu: "quoted_sk_term \<rho> output u"
    and prim: "combinator_construction_holds \<rho> \<Phi> j"
    by (auto simp: sk_factor_step_def)
  from fc have formed: "factor_foundation_formed \<rho> \<Phi>"
    by (auto simp: factor_constructs_def factor_holds_def)
  have rf: "resolver_formed \<rho>" using formed by (simp add: factor_foundation_formed_def)
  from prim obtain J ib i0 A W0 out0 t0 u0 where
    pj: "factor_judgment_at \<rho> j J"
    and pa: "judgment_arguments J = [ib,structural_assembly_anchor A,out0]"
    and pb: "anchor_record_bundle \<rho> ib [i0]"
    and qi0: "quoted_sk_term \<rho> i0 t0" and qo0: "quoted_sk_term \<rho> out0 u0"
    and st: "sk_step t0 u0"
    by (auto simp: combinator_construction_holds_def)
  from ca obtain JC ibc where jc: "factor_judgment_at \<rho> j JC"
    and ja: "judgment_arguments JC =
      [ibc,structural_assembly_anchor (construction_assembly C),construction_output C]"
    and jb: "anchor_record_bundle \<rho> ibc (construction_inputs C)"
    by (auto simp: factor_construction_at_def raw_factor_construction_def)
  have jj: "J = JC" by (rule factor_judgment_unique[OF pj jc])
  have ib: "ib = ibc" and oo: "out0 = output" using pa ja jj out by simp_all
  have same_inputs: "[i0] = construction_inputs C"
    by (rule anchor_record_bundle_unique[OF rf pb]) (use jb ib in simp)
  have ii: "i0 = input" using same_inputs inp by simp
  have tt: "t0 = t"
    by (rule quoted_sk_term_unique[OF rf _ qt]) (use qi0 ii in simp)
  have uu: "u0 = u"
    by (rule quoted_sk_term_unique[OF rf _ qu]) (use qo0 oo in simp)
  show ?thesis using st tt uu by simp
qed

inductive factor_sk_reduces ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> exact_anchor \<Rightarrow>
   exact_anchor \<Rightarrow> sk_term \<Rightarrow> exact_anchor \<Rightarrow> sk_term \<Rightarrow> bool"
  for \<rho> \<Phi> program
where
  factor_sk_refl:
    "quoted_sk_term \<rho> a t \<Longrightarrow>
     factor_sk_reduces \<rho> \<Phi> program a t a t"
| factor_sk_trans:
    "sk_factor_step \<rho> \<Phi> program a t b u j W \<Longrightarrow>
     factor_sk_reduces \<rho> \<Phi> program b u c v \<Longrightarrow>
     factor_sk_reduces \<rho> \<Phi> program a t c v"

lemma factor_sk_reduces_sound:
  assumes "factor_sk_reduces \<rho> \<Phi> program a t b u"
  shows "sk_reduces t u"
  using assms
proof (induction rule: factor_sk_reduces.induct)
  case (factor_sk_refl a t)
  then show ?case
    by (simp add: sk_reduces_def)
next
  case (factor_sk_trans a t b u j W c v)
  then show ?case
    by (auto simp: sk_reduces_def intro: converse_rtranclp_into_rtranclp
      dest: sk_factor_step_sound)
qed

lemma sk_program_complete_one_step:
  assumes complete: "sk_program_complete \<rho> \<Phi> program"
      and input: "quoted_sk_term \<rho> a t"
      and step: "sk_step t u"
  shows "\<exists>b j W. sk_factor_step \<rho> \<Phi> program a t b u j W"
  using assms by (auto simp: sk_program_complete_def)

lemma sk_program_complete_finite_reduction:
  assumes complete: "sk_program_complete \<rho> \<Phi> program"
      and input: "quoted_sk_term \<rho> a t"
      and reduction: "sk_reduces t u"
  shows "\<exists>b. factor_sk_reduces \<rho> \<Phi> program a t b u"
  using reduction[unfolded sk_reduces_def] input
proof (induction arbitrary: a rule: converse_rtranclp_induct)
  case base
  then show ?case by (auto intro: factor_sk_reduces.factor_sk_refl)
next
  case (step x y)
  from sk_program_complete_one_step[OF complete step.prems step.hyps(1)]
  obtain b j W where one: "sk_factor_step \<rho> \<Phi> program a x b y j W" by blast
  have qy: "quoted_sk_term \<rho> b y" using one by (simp add: sk_factor_step_def)
  from step.IH[OF qy] obtain c where rest: "factor_sk_reduces \<rho> \<Phi> program b y c u" by blast
  show ?case using factor_sk_reduces.factor_sk_trans[OF one rest] by blast
qed

section \<open>Computational sufficiency is an adoption condition\<close>

text \<open>
  SK combinatory reduction is a standard universal pure calculus.  The
  bootstrap does not add a machine, store, continuation, or effect semantics.
  It requires the exact genesis foundation to contain one topology-recognized
  program satisfying sk_program_complete.  The preceding theorems then transport
  every finite SK reduction into finite Factor constructions and transport every
  such construction back to the corresponding SK step.
\<close>

definition bootstrap_computationally_sufficient ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> bool" where
  "bootstrap_computationally_sufficient \<rho> \<Phi> \<longleftrightarrow>
     (\<exists>program. sk_program_complete \<rho> \<Phi> program)"

lemma computational_sufficiency_yields_finite_simulation:
  assumes "bootstrap_computationally_sufficient \<rho> \<Phi>"
      and "quoted_sk_term \<rho> a t"
      and "sk_reduces t u"
  shows "\<exists>program b.
           sk_program_complete \<rho> \<Phi> program \<and>
           factor_sk_reduces \<rho> \<Phi> program a t b u"
  using assms sk_program_complete_finite_reduction
  by (auto simp: bootstrap_computationally_sufficient_def)

definition complete_genesis ::
  "artifact_resolver \<Rightarrow> reflection_specification \<Rightarrow> genesis_bundle \<Rightarrow> bool" where
  "complete_genesis \<rho> X G \<longleftrightarrow>
     genesis_formed \<rho> X G \<and>
     bootstrap_computationally_sufficient \<rho> (genesis_foundation G)"

lemma complete_genesis_has_reflection_and_computation:
  assumes "complete_genesis \<rho> X G"
  shows "reflection_valid \<rho> X (genesis_reflection_bundle G) \<and>
         bootstrap_computationally_sufficient \<rho> (genesis_foundation G)"
  using assms by (auto simp: complete_genesis_def genesis_formed_def)

end
