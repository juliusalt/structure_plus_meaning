theory Foundation_Genesis
  imports Foundation_Reflection
begin

section \<open>The exact genesis handoff\<close>

record genesis_bundle =
  genesis_reflection_bundle :: reflection_bundle
  genesis_trajectory :: trajectory
  genesis_generation_root :: local_address
  genesis_publication :: publication
  genesis_foundation_locus :: exact_anchor
  genesis_authority :: exact_anchor
  genesis_purpose :: exact_anchor
  genesis_current_definition :: exact_anchor
  genesis_current_judgment :: exact_anchor

definition genesis_foundation :: "genesis_bundle \<Rightarrow> factor_foundation" where
  "genesis_foundation G = reflected_foundation (genesis_reflection_bundle G)"

definition genesis_formed ::
  "artifact_resolver \<Rightarrow> reflection_specification \<Rightarrow> genesis_bundle \<Rightarrow> bool" where
  "genesis_formed \<rho> X G \<longleftrightarrow>
     reflection_valid \<rho> X (genesis_reflection_bundle G) \<and>
     (\<exists>P.
        generation_in_trajectory \<rho> (genesis_trajectory G)
          (genesis_generation_root G) P \<and>
        generation_locus P = genesis_foundation_locus G \<and>
        generation_predecessors P = {} \<and>
        generation_payload P =
          Whole_Artifact (foundation_reference (genesis_foundation G)) \<and>
        evidence_envelope_anchor
          (reflection_evidence (genesis_reflection_bundle G))
          \<in> generation_evidence P) \<and>
     publication_formed \<rho> (genesis_publication G) \<and>
     (genesis_foundation_locus G,
      generation_identity (genesis_trajectory G)
                          (genesis_generation_root G))
       \<in> publication_selections
            (projected_publication \<rho> (genesis_publication G)) \<and>
     factor_foundation_anchor (genesis_foundation G)
       \<in> publication_dependencies
            (projected_publication \<rho> (genesis_publication G)) \<and>
     evidence_envelope_anchor
       (reflection_evidence (genesis_reflection_bundle G))
       \<in> publication_evidence
            (projected_publication \<rho> (genesis_publication G)) \<and>
     factor_current \<rho> (genesis_foundation G)
       (genesis_current_definition G)
       (genesis_current_judgment G)
       (genesis_authority G)
       (genesis_publication G)
       (genesis_foundation_locus G)
       (generation_identity (genesis_trajectory G)
                            (genesis_generation_root G))
       (genesis_purpose G)"

lemma genesis_has_external_internal_agreement:
  assumes "genesis_formed \<rho> X G" "j \<in> reflection_domain X"
  shows "j \<in> external_truth X \<longleftrightarrow> factor_holds \<rho> (genesis_foundation G) j"
  using assms reflection_handoff
  by (auto simp: genesis_formed_def genesis_foundation_def)

lemma genesis_is_not_self_authorized:
  assumes "genesis_formed \<rho> X G"
  shows "reflection_valid \<rho> X (genesis_reflection_bundle G)"
  using assms by (simp add: genesis_formed_def)

lemma genesis_current_is_publication_relative:
  assumes "genesis_formed \<rho> X G"
  shows "factor_current \<rho> (genesis_foundation G)
           (genesis_current_definition G)
           (genesis_current_judgment G)
           (genesis_authority G)
           (genesis_publication G)
           (genesis_foundation_locus G)
           (generation_identity (genesis_trajectory G)
                                (genesis_generation_root G))
           (genesis_purpose G)"
  using assms by (simp add: genesis_formed_def)

section \<open>Reflective continuation without retroactive meaning\<close>

record foundation_successor_bundle =
  predecessor_foundation :: factor_foundation
  successor_foundation :: factor_foundation
  foundation_trajectory :: trajectory
  successor_generation_root :: local_address
  successor_judgment :: exact_anchor
  successor_derivation :: factor_derivation
  successor_evidence :: evidence_envelope
  successor_assembly :: "local_address assembly_witness"
  successor_publication :: publication

definition foundation_successor ::
  "artifact_resolver \<Rightarrow> foundation_successor_bundle \<Rightarrow> bool" where
  "foundation_successor \<rho> B \<longleftrightarrow>
     factor_foundation_formed \<rho> (predecessor_foundation B) \<and>
     factor_foundation_formed \<rho> (successor_foundation B) \<and>
     factor_advances \<rho> (predecessor_foundation B)
       (foundation_trajectory B)
       (successor_generation_root B)
       (successor_judgment B)
       (successor_derivation B)
       (successor_evidence B)
       (successor_assembly B) \<and>
     assembly_output (successor_assembly B) =
       factor_foundation_artifact \<rho> (successor_foundation B) \<and>
     publication_formed \<rho> (successor_publication B)"

lemma successor_uses_predecessor_meaning:
  assumes "foundation_successor \<rho> B"
  shows "factor_certifies \<rho> (predecessor_foundation B)
           (successor_evidence B)
           (successor_judgment B)
           (successor_derivation B)
           (successor_assembly B)"
  using assms by (auto simp: foundation_successor_def factor_advances_def)

text \<open>
  A successor foundation is a new exact artifact justified under its exact
  predecessor.  It does not alter the predecessor artifact or any judgment
  whose explicit foundation argument is that predecessor.  A change outside
  the predecessor's reflective continuation relation requires a new external
  Isabelle/HOL adequacy handoff; no foundation may grant itself new semantic
  force merely by publication.
\<close>

end
