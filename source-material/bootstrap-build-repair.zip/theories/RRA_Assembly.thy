theory RRA_Assembly
  imports RRA_Fragment
begin

section \<open>Exact piece occurrences\<close>

record 's exact_piece_family =
  piece_graph :: "('s \<times> exact_artifact) set"

definition piece_family_formed :: "'s exact_piece_family \<Rightarrow> bool" where
  "piece_family_formed P \<longleftrightarrow>
     finite (piece_graph P) \<and>
     single_valued (piece_graph P) \<and>
     (\<forall>s R. (s,R) \<in> piece_graph P \<longrightarrow> exact_formed R)"

definition piece_slots :: "'s exact_piece_family \<Rightarrow> 's set" where
  "piece_slots P = rel_dom (piece_graph P)"

definition piece_at :: "'s exact_piece_family \<Rightarrow> 's \<Rightarrow> exact_artifact" where
  "piece_at P s = rel_value (piece_graph P) s"

definition copied_carrier ::
  "'s exact_piece_family \<Rightarrow> ('s \<times> local_address) set" where
  "copied_carrier P =
     {(s,a). s \<in> piece_slots P \<and>
             a \<in> rra_carrier (object_structure (piece_at P s))}"

definition copied_incidence ::
  "'s exact_piece_family \<Rightarrow>
   (('s \<times> local_address) \<times> ('s \<times> local_address) \<times>
    ('s \<times> local_address)) set" where
  "copied_incidence P =
     {((s,r),(s,p),(s,x)) |s r p x.
        s \<in> piece_slots P \<and>
        (r,p,x) \<in> rra_incidence (object_structure (piece_at P s))}"

section \<open>Copied data\<close>

fun functional_component :: "(local_address,octets) rra_data \<Rightarrow>
  (local_address \<times> octets) set" where
  "functional_component (Functional_Data F) = F"
| "functional_component No_Data = {}"
| "functional_component (Bag_Data B) = {}"
| "functional_component (Node_Data N) = {}"

fun bag_component :: "(local_address,octets) rra_data \<Rightarrow>
  (local_address \<times> octets \<times> nat) set" where
  "bag_component (Bag_Data B) = B"
| "bag_component No_Data = {}"
| "bag_component (Functional_Data F) = {}"
| "bag_component (Node_Data N) = {}"

fun node_component :: "(local_address,octets) rra_data \<Rightarrow>
  (local_address \<times> local_address \<times> octets) set" where
  "node_component (Node_Data N) = N"
| "node_component No_Data = {}"
| "node_component (Functional_Data F) = {}"
| "node_component (Bag_Data B) = {}"

definition copied_functional ::
  "'s exact_piece_family \<Rightarrow> (('s \<times> local_address) \<times> octets) set" where
  "copied_functional P =
     {((s,a),v) |s a v.
        s \<in> piece_slots P \<and>
        (a,v) \<in> functional_component (object_data (piece_at P s))}"

definition copied_bag ::
  "'s exact_piece_family \<Rightarrow> (('s \<times> local_address) \<times> octets \<times> nat) set" where
  "copied_bag P =
     {((s,a),v,n) |s a v n.
        s \<in> piece_slots P \<and>
        (a,v,n) \<in> bag_component (object_data (piece_at P s))}"

definition copied_node ::
  "'s exact_piece_family \<Rightarrow>
   (('s \<times> local_address) \<times> ('s \<times> local_address) \<times> octets) set" where
  "copied_node P =
     {((s,d),(s,a),v) |s d a v.
        s \<in> piece_slots P \<and>
        (d,a,v) \<in> node_component (object_data (piece_at P s))}"

definition copied_bag_values :: "'s exact_piece_family \<Rightarrow> octets set" where
  "copied_bag_values P = {v. \<exists>c n. (c,v,n) \<in> copied_bag P}"

definition copied_bag_count ::
  "'s exact_piece_family \<Rightarrow> ('s \<times> local_address) \<Rightarrow> octets \<Rightarrow> nat" where
  "copied_bag_count P c v =
     (if \<exists>n. (c,v,n) \<in> copied_bag P
      then (THE n. (c,v,n) \<in> copied_bag P)
      else 0)"

section \<open>One complete assembly account\<close>

record 's assembly_witness =
  assembly_pieces :: "'s exact_piece_family"
  assembly_origin :: "(('s \<times> local_address) \<times> local_address) set"
  assembly_output :: exact_artifact

definition expected_incidence ::
  "'s exact_piece_family \<Rightarrow>
   ((('s \<times> local_address) \<times> local_address) set) \<Rightarrow>
   (local_address \<times> local_address \<times> local_address) set" where
  "expected_incidence P q = ternary_image q (copied_incidence P)"

definition expected_functional ::
  "'s exact_piece_family \<Rightarrow>
   ((('s \<times> local_address) \<times> local_address) set) \<Rightarrow>
   (local_address \<times> octets) set" where
  "expected_functional P q =
     {(rel_value q c,v) |c v. (c,v) \<in> copied_functional P}"

definition expected_node ::
  "'s exact_piece_family \<Rightarrow>
   ((('s \<times> local_address) \<times> local_address) set) \<Rightarrow>
   (local_address \<times> local_address \<times> octets) set" where
  "expected_node P q =
     {(rel_value q d,rel_value q a,v) |d a v. (d,a,v) \<in> copied_node P}"

definition expected_bag ::
  "'s exact_piece_family \<Rightarrow>
   ((('s \<times> local_address) \<times> local_address) set) \<Rightarrow>
   (local_address \<times> octets \<times> nat) set" where
  "expected_bag P q =
     {(y,v,n) |y v n.
       y \<in> rel_ran q \<and> v \<in> copied_bag_values P \<and>
       n = (\<Sum>c\<in>copied_carrier P.
              if rel_value q c = y then copied_bag_count P c v else 0) \<and>
       n > 0}"

definition family_has_profile ::
  "'s exact_piece_family \<Rightarrow> data_profile_kind \<Rightarrow> bool" where
  "family_has_profile P k \<longleftrightarrow>
     (\<forall>s \<in> piece_slots P. profile_kind (object_data (piece_at P s)) = k)"

definition assembled_data ::
  "'s exact_piece_family \<Rightarrow>
   ((('s \<times> local_address) \<times> local_address) set) \<Rightarrow>
   (local_address,octets) rra_data \<Rightarrow> bool" where
  "assembled_data P q D \<longleftrightarrow>
       (family_has_profile P No_Data_Profile \<and> D = No_Data)
     \<or> (family_has_profile P Functional_Profile \<and>
        D = Functional_Data (expected_functional P q))
     \<or> (family_has_profile P Bag_Profile \<and>
        D = Bag_Data (expected_bag P q))
     \<or> (family_has_profile P Node_Profile \<and>
        D = Node_Data (expected_node P q))"

definition K2 :: "'s assembly_witness \<Rightarrow> bool" where
  "K2 W \<longleftrightarrow>
     piece_family_formed (assembly_pieces W) \<and>
     exact_formed (assembly_output W) \<and>
     exact_map (copied_carrier (assembly_pieces W))
               (rra_carrier (object_structure (assembly_output W)))
               (assembly_origin W) \<and>
     rra_incidence (object_structure (assembly_output W)) =
       expected_incidence (assembly_pieces W) (assembly_origin W) \<and>
     assembled_data (assembly_pieces W) (assembly_origin W)
                    (object_data (assembly_output W))"

lemma K2_no_unexplained_output_atom:
  assumes "K2 W"
      and "a \<in> rra_carrier (object_structure (assembly_output W))"
  shows "\<exists>c \<in> copied_carrier (assembly_pieces W).
           (c,a) \<in> assembly_origin W"
proof -
  have mapping: "exact_map (copied_carrier (assembly_pieces W))
      (rra_carrier (object_structure (assembly_output W))) (assembly_origin W)"
    using assms(1) by (simp add: K2_def)
  show ?thesis by (rule exact_map_surjective[OF mapping assms(2)])
qed

lemma K2_origin_is_single_valued:
  assumes "K2 W"
  shows "single_valued (assembly_origin W)"
  using assms by (simp add: K2_def exact_map_def)

lemma K2_glued_iff_same_output:
  assumes "K2 W"
      and "c \<in> copied_carrier (assembly_pieces W)"
      and "d \<in> copied_carrier (assembly_pieces W)"
  shows "rel_value (assembly_origin W) c = rel_value (assembly_origin W) d \<longleftrightarrow>
         (\<exists>a. (c,a) \<in> assembly_origin W \<and>
              (d,a) \<in> assembly_origin W)"
proof
  assume eq: "rel_value (assembly_origin W) c =
              rel_value (assembly_origin W) d"
  have ca: "(c,rel_value (assembly_origin W) c) \<in> assembly_origin W"
    using exact_map_value assms by (auto simp: K2_def)
  have da: "(d,rel_value (assembly_origin W) d) \<in> assembly_origin W"
    using exact_map_value assms by (auto simp: K2_def)
  show "\<exists>a. (c,a) \<in> assembly_origin W \<and> (d,a) \<in> assembly_origin W"
    by (rule exI[of _ "rel_value (assembly_origin W) c"])
       (use ca da eq in simp)
next
  assume "\<exists>a. (c,a) \<in> assembly_origin W \<and> (d,a) \<in> assembly_origin W"
  then obtain a where ca: "(c,a) \<in> assembly_origin W"
                    and da: "(d,a) \<in> assembly_origin W" by blast
  from assms have sv: "single_valued (assembly_origin W)"
    by (simp add: K2_def exact_map_def)
  have "rel_value (assembly_origin W) c = a"
    by (rule rel_value_eq[OF sv ca])
  moreover have "rel_value (assembly_origin W) d = a"
    by (rule rel_value_eq[OF sv da])
  ultimately show "rel_value (assembly_origin W) c =
                   rel_value (assembly_origin W) d"
    by simp
qed

lemma K2_output_incidence_has_origin:
  assumes "K2 W"
      and "(r,p,x) \<in> rra_incidence (object_structure (assembly_output W))"
  shows "\<exists>cr cp cx.
           (cr,cp,cx) \<in> copied_incidence (assembly_pieces W) \<and>
           rel_value (assembly_origin W) cr = r \<and>
           rel_value (assembly_origin W) cp = p \<and>
           rel_value (assembly_origin W) cx = x"
  using assms
  by (auto simp: K2_def expected_incidence_def ternary_image_def; blast)

text \<open>
  K2 contains no semantic premise.  It verifies only exact reuse, identity
  gluing, incidence transport, and profile-preserving data transport.  Whether
  a program is permitted to select or glue the pieces is a later Factor fact.
\<close>

section \<open>Structural quotation of assembly witnesses\<close>

record structural_assembly =
  structural_assembly_reference :: artifact_reference
  structural_assembly_root :: local_address

definition structural_assembly_artifact ::
  "artifact_resolver \<Rightarrow> structural_assembly \<Rightarrow> exact_artifact" where
  "structural_assembly_artifact \<rho> A =
     rel_value \<rho> (structural_assembly_reference A)"

definition structural_assembly_anchor ::
  "structural_assembly \<Rightarrow> exact_anchor" where
  "structural_assembly_anchor A =
     Occurrence_Citation (structural_assembly_reference A)
                         (structural_assembly_root A)"

definition quoted_piece_at ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow> exact_artifact \<Rightarrow> bool" where
  "quoted_piece_at \<rho> E p R \<longleftrightarrow>
     (\<exists>ar ref.
        record_at (object_structure E) p [ar] \<and>
        anchored_at \<rho> E ar (Whole_Artifact ref) \<and>
        resolves \<rho> ref R)"

definition quoted_piece_family_at ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow>
   local_address exact_piece_family \<Rightarrow> bool" where
  "quoted_piece_family_at \<rho> E root P \<longleftrightarrow>
     (\<exists>R.
        family_at (object_structure E) root R \<and>
        (\<forall>p \<in> R. \<exists>!obj. quoted_piece_at \<rho> E p obj) \<and>
        piece_graph P = {(p,obj). p \<in> R \<and> quoted_piece_at \<rho> E p obj})"

definition quoted_origin_at ::
  "artifact_resolver \<Rightarrow> structural_assembly \<Rightarrow> exact_artifact \<Rightarrow>
   local_address \<Rightarrow> ((local_address \<times> local_address) \<times> local_address) \<Rightarrow> bool" where
  "quoted_origin_at \<rho> A E entry cy \<longleftrightarrow>
     (\<exists>pr ir yr p a y.
        record_at (object_structure E) entry [pr,ir,yr] \<and>
        anchored_at \<rho> E pr
          (Occurrence_Citation (structural_assembly_reference A) p) \<and>
        functional_payload E ir a \<and>
        functional_payload E yr y \<and>
        cy = ((p,a),y))"

definition quoted_origin_family_at ::
  "artifact_resolver \<Rightarrow> structural_assembly \<Rightarrow> exact_artifact \<Rightarrow>
   local_address \<Rightarrow> (((local_address \<times> local_address) \<times> local_address) set) \<Rightarrow> bool" where
  "quoted_origin_family_at \<rho> A E root q \<longleftrightarrow>
     (\<exists>R.
        family_at (object_structure E) root R \<and>
        (\<forall>entry \<in> R. \<exists>!cy. quoted_origin_at \<rho> A E entry cy) \<and>
        q = {cy. \<exists>entry \<in> R. quoted_origin_at \<rho> A E entry cy})"

definition raw_assembly_quote_at ::
  "artifact_resolver \<Rightarrow> structural_assembly \<Rightarrow>
   local_address assembly_witness \<Rightarrow> bool" where
  "raw_assembly_quote_at \<rho> A W \<longleftrightarrow>
     (let E = structural_assembly_artifact \<rho> A in
      \<exists>pr qr yr ref.
        record_at (object_structure E) (structural_assembly_root A)
                  [pr,qr,yr] \<and>
        quoted_piece_family_at \<rho> E pr (assembly_pieces W) \<and>
        quoted_origin_family_at \<rho> A E qr (assembly_origin W) \<and>
        anchored_at \<rho> E yr (Whole_Artifact ref) \<and>
        resolves \<rho> ref (assembly_output W))"

definition assembly_quote_at ::
  "artifact_resolver \<Rightarrow> structural_assembly \<Rightarrow>
   local_address assembly_witness \<Rightarrow> bool" where
  "assembly_quote_at \<rho> A W \<longleftrightarrow>
     raw_assembly_quote_at \<rho> A W \<and>
     (\<forall>V. raw_assembly_quote_at \<rho> A V \<longrightarrow> V = W)"

definition structural_assembly_formed ::
  "artifact_resolver \<Rightarrow> structural_assembly \<Rightarrow> bool" where
  "structural_assembly_formed \<rho> A \<longleftrightarrow>
     resolver_formed \<rho> \<and>
     resolves \<rho> (structural_assembly_reference A)
                (structural_assembly_artifact \<rho> A) \<and>
     exact_formed (structural_assembly_artifact \<rho> A) \<and>
     rooted_complete (object_structure (structural_assembly_artifact \<rho> A))
                     (structural_assembly_root A) \<and>
     (\<exists>!W. assembly_quote_at \<rho> A W \<and> K2 W)"

lemma assembly_quote_unique:
  assumes "assembly_quote_at \<rho> A W" "assembly_quote_at \<rho> A V"
  shows "W = V"
  using assms by (auto simp: assembly_quote_at_def)

lemma structural_assembly_quote_K2:
  assumes "structural_assembly_formed \<rho> A" "assembly_quote_at \<rho> A W"
  shows "K2 W"
proof -
  from assms(1) obtain V where av: "assembly_quote_at \<rho> A V" and kv: "K2 V"
    by (auto simp: structural_assembly_formed_def)
  have "V = W"
    using assembly_quote_unique[OF av assms(2)] .
  with kv show ?thesis by simp
qed

text \<open>
  This quotation stores no second construction map.  Its origin-entry family is
  precisely the graph used by K2, and the output anchor resolves to precisely
  the output value used by K2.
\<close>

end
