theory RRA_Core
  imports Bootstrap_Relations
begin

section \<open>The sole structural universe\<close>

record 'a rra_structure =
  rra_carrier :: "'a set"
  rra_incidence :: "('a \<times> 'a \<times> 'a) set"

definition rra_formed :: "'a rra_structure \<Rightarrow> bool" where
  "rra_formed S \<longleftrightarrow>
     finite (rra_carrier S) \<and>
     finite (rra_incidence S) \<and>
     (\<forall>r p x. (r,p,x) \<in> rra_incidence S \<longrightarrow>
        r \<in> rra_carrier S \<and> p \<in> rra_carrier S \<and> x \<in> rra_carrier S)"

definition relation_occurrences :: "'a rra_structure \<Rightarrow> 'a set" where
  "relation_occurrences S = {r. \<exists>p x. (r,p,x) \<in> rra_incidence S}"

definition participation_occurrences :: "'a rra_structure \<Rightarrow> 'a set" where
  "participation_occurrences S = {p. \<exists>r x. (r,p,x) \<in> rra_incidence S}"

definition reached_occurrences :: "'a rra_structure \<Rightarrow> 'a set" where
  "reached_occurrences S = {x. \<exists>r p. (r,p,x) \<in> rra_incidence S}"

text \<open>
  These three sets are projections of tuple positions.  They are not sorts and
  need not be disjoint.  An occurrence may occupy any combination of positions.
\<close>

lemma role_occurrences_in_carrier:
  assumes "rra_formed S"
  shows "relation_occurrences S \<subseteq> rra_carrier S"
    and "participation_occurrences S \<subseteq> rra_carrier S"
    and "reached_occurrences S \<subseteq> rra_carrier S"
  using assms
  by (auto simp: rra_formed_def relation_occurrences_def
      participation_occurrences_def reached_occurrences_def)

definition touching_incidence ::
  "'a rra_structure \<Rightarrow> 'a set \<Rightarrow> ('a \<times> 'a \<times> 'a) set" where
  "touching_incidence S A =
     {(r,p,x) \<in> rra_incidence S. r \<in> A \<or> p \<in> A \<or> x \<in> A}"

definition internal_incidence ::
  "'a rra_structure \<Rightarrow> 'a set \<Rightarrow> ('a \<times> 'a \<times> 'a) set" where
  "internal_incidence S A =
     {(r,p,x) \<in> rra_incidence S. r \<in> A \<and> p \<in> A \<and> x \<in> A}"

definition crossing_incidence ::
  "'a rra_structure \<Rightarrow> 'a set \<Rightarrow> ('a \<times> 'a \<times> 'a) set" where
  "crossing_incidence S A = touching_incidence S A - internal_incidence S A"

definition restrict_structure :: "'a rra_structure \<Rightarrow> 'a set \<Rightarrow> 'a rra_structure" where
  "restrict_structure S A =
     \<lparr> rra_carrier = rra_carrier S \<inter> A,
       rra_incidence = internal_incidence S (rra_carrier S \<inter> A) \<rparr>"

lemma restrict_structure_formed:
  assumes "rra_formed S"
  shows "rra_formed (restrict_structure S A)"
proof -
  have sub: "internal_incidence S (rra_carrier S \<inter> A) \<subseteq> rra_incidence S"
    by (auto simp: internal_incidence_def)
  have fin: "finite (internal_incidence S (rra_carrier S \<inter> A))"
    using finite_subset[OF sub] assms by (auto simp: rra_formed_def)
  show ?thesis
    using assms fin
    by (auto simp: rra_formed_def restrict_structure_def internal_incidence_def)
qed

section \<open>Renaming\<close>

definition push_structure :: "('a \<Rightarrow> 'b) \<Rightarrow> 'a rra_structure \<Rightarrow> 'b rra_structure" where
  "push_structure f S =
     \<lparr> rra_carrier = f ` rra_carrier S,
       rra_incidence =
         (\<lambda>(r,p,x). (f r,f p,f x)) ` rra_incidence S \<rparr>"

definition rra_isomorphism ::
  "('a \<Rightarrow> 'b) \<Rightarrow> 'a rra_structure \<Rightarrow> 'b rra_structure \<Rightarrow> bool" where
  "rra_isomorphism f S T \<longleftrightarrow>
     bij_betw f (rra_carrier S) (rra_carrier T) \<and>
     push_structure f S = T"

definition rra_isomorphic :: "'a rra_structure \<Rightarrow> 'b rra_structure \<Rightarrow> bool" where
  "rra_isomorphic S T \<longleftrightarrow> (\<exists>f. rra_isomorphism f S T)"

lemma push_structure_formed:
  assumes "rra_formed S"
  shows "rra_formed (push_structure f S)"
  using assms by (auto simp: rra_formed_def push_structure_def)

lemma push_structure_iso:
  assumes "inj_on f (rra_carrier S)"
  shows "rra_isomorphism f S (push_structure f S)"
  using assms
  by (auto simp: rra_isomorphism_def push_structure_def bij_betw_def inj_on_def)

lemma rra_isomorphic_refl:
  "rra_isomorphic S S"
  unfolding rra_isomorphic_def rra_isomorphism_def bij_betw_def
  by (rule exI[of _ id]) (cases S; auto simp: push_structure_def)

section \<open>Externally bounded views\<close>

record ('k,'a) bounded_view =
  bounded_structure :: "'a rra_structure"
  boundary_graph :: "('k \<times> 'a) set"

definition boundary_formed :: "('k,'a) bounded_view \<Rightarrow> bool" where
  "boundary_formed V \<longleftrightarrow>
     rra_formed (bounded_structure V) \<and>
     finite (boundary_graph V) \<and>
     single_valued (boundary_graph V) \<and>
     rel_ran (boundary_graph V) \<subseteq> rra_carrier (bounded_structure V)"

definition bounded_isomorphism ::
  "('a \<Rightarrow> 'b) \<Rightarrow> ('k,'a) bounded_view \<Rightarrow> ('k,'b) bounded_view \<Rightarrow> bool" where
  "bounded_isomorphism f V W \<longleftrightarrow>
     rra_isomorphism f (bounded_structure V) (bounded_structure W) \<and>
     rel_dom (boundary_graph V) = rel_dom (boundary_graph W) \<and>
     boundary_graph W = {(k,f a) |k a. (k,a) \<in> boundary_graph V}"

lemma bounded_isomorphism_preserves_keys:
  assumes "bounded_isomorphism f V W"
  shows "rel_dom (boundary_graph V) = rel_dom (boundary_graph W)"
  using assms by (simp add: bounded_isomorphism_def)

lemma boundary_does_not_change_structure:
  assumes "bounded_structure V = bounded_structure W"
  shows "rra_incidence (bounded_structure V) = rra_incidence (bounded_structure W)"
  using assms by simp

text \<open>
  A boundary key belongs to the supplied view.  No predicate in this theory
  turns a key into a property, kind, or stored name of the reached occurrence.
\<close>

section \<open>Rooted structural completeness\<close>

definition incidence_step ::
  "'a rra_structure \<Rightarrow> ('a \<times> 'a) set" where
  "incidence_step S =
     {(a,b). \<exists>r p x.
        (r,p,x) \<in> rra_incidence S \<and>
        a \<in> {r,p,x} \<and> b \<in> {r,p,x} \<and> a \<noteq> b}"

definition rooted_complete :: "'a rra_structure \<Rightarrow> 'a \<Rightarrow> bool" where
  "rooted_complete S root \<longleftrightarrow>
     root \<in> rra_carrier S \<and>
     rra_carrier S = {root} \<union> {x. (root,x) \<in> (incidence_step S)\<^sup>+}"

end
