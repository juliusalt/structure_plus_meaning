theory RRA_Data
  imports RRA_Core
begin

section \<open>Opaque finite payloads\<close>

type_synonym octets = "nat list"

definition octets_formed :: "octets \<Rightarrow> bool" where
  "octets_formed xs \<longleftrightarrow> (\<forall>x \<in> set xs. x < 256)"

datatype ('a,'v) rra_data =
    No_Data
  | Functional_Data "('a \<times> 'v) set"
  | Bag_Data "('a \<times> 'v \<times> nat) set"
  | Node_Data "('a \<times> 'a \<times> 'v) set"

datatype data_profile_kind =
    No_Data_Profile
  | Functional_Profile
  | Bag_Profile
  | Node_Profile

fun profile_kind :: "('a,'v) rra_data \<Rightarrow> data_profile_kind" where
  "profile_kind No_Data = No_Data_Profile"
| "profile_kind (Functional_Data F) = Functional_Profile"
| "profile_kind (Bag_Data B) = Bag_Profile"
| "profile_kind (Node_Data N) = Node_Profile"

definition pair_functional :: "('a \<times> 'b) set \<Rightarrow> bool" where
  "pair_functional F \<longleftrightarrow> (\<forall>a x y. (a,x) \<in> F \<longrightarrow> (a,y) \<in> F \<longrightarrow> x = y)"

definition bag_functional :: "('a \<times> 'b \<times> nat) set \<Rightarrow> bool" where
  "bag_functional B \<longleftrightarrow>
     (\<forall>a v m n. (a,v,m) \<in> B \<longrightarrow> (a,v,n) \<in> B \<longrightarrow> m = n)"

definition node_functional :: "('a \<times> 'a \<times> 'b) set \<Rightarrow> bool" where
  "node_functional N \<longleftrightarrow>
     (\<forall>d a v b w. (d,a,v) \<in> N \<longrightarrow> (d,b,w) \<in> N \<longrightarrow> a = b \<and> v = w)"

fun data_formed :: "'a set \<Rightarrow> ('a,'v) rra_data \<Rightarrow> bool" where
  "data_formed U No_Data = True"
| "data_formed U (Functional_Data F) =
     (finite F \<and> pair_functional F \<and> (\<forall>a v. (a,v) \<in> F \<longrightarrow> a \<in> U))"
| "data_formed U (Bag_Data B) =
     (finite B \<and> bag_functional B \<and>
      (\<forall>a v n. (a,v,n) \<in> B \<longrightarrow> a \<in> U \<and> n > 0))"
| "data_formed U (Node_Data N) =
     (finite N \<and> node_functional N \<and>
      (\<forall>d a v. (d,a,v) \<in> N \<longrightarrow> d \<in> U \<and> a \<in> U))"

record ('a,'v) structured_object =
  object_structure :: "'a rra_structure"
  object_data :: "('a,'v) rra_data"

definition object_formed :: "('a,'v) structured_object \<Rightarrow> bool" where
  "object_formed obj \<longleftrightarrow>
     rra_formed (object_structure obj) \<and>
     data_formed (rra_carrier (object_structure obj)) (object_data obj)"

fun restrict_data :: "'a set \<Rightarrow> ('a,'v) rra_data \<Rightarrow> ('a,'v) rra_data" where
  "restrict_data A No_Data = No_Data"
| "restrict_data A (Functional_Data F) =
     Functional_Data {t \<in> F. fst t \<in> A}"
| "restrict_data A (Bag_Data B) =
     Bag_Data {t \<in> B. fst t \<in> A}"
| "restrict_data A (Node_Data N) =
     Node_Data {t \<in> N. fst t \<in> A \<and> fst (snd t) \<in> A}"

definition restrict_object ::
  "('a,'v) structured_object \<Rightarrow> 'a set \<Rightarrow> ('a,'v) structured_object" where
  "restrict_object obj A =
     \<lparr> object_structure = restrict_structure (object_structure obj) A,
       object_data = restrict_data (rra_carrier (object_structure obj) \<inter> A)
                                   (object_data obj) \<rparr>"

lemma restrict_data_formed:
  assumes "data_formed U D"
  shows "data_formed (U \<inter> A) (restrict_data (U \<inter> A) D)"
  using assms
  by (cases D) (auto simp: pair_functional_def bag_functional_def node_functional_def)

lemma restrict_object_formed:
  assumes "object_formed obj"
  shows "object_formed (restrict_object obj A)"
  using assms restrict_structure_formed[of "object_structure obj" A]
    restrict_data_formed[of "rra_carrier (object_structure obj)" "object_data obj" A]
  by (auto simp: object_formed_def restrict_object_def restrict_structure_def)

fun push_data :: "('a \<Rightarrow> 'b) \<Rightarrow> ('a,'v) rra_data \<Rightarrow> ('b,'v) rra_data" where
  "push_data f No_Data = No_Data"
| "push_data f (Functional_Data F) =
     Functional_Data {(f a,v) |a v. (a,v) \<in> F}"
| "push_data f (Bag_Data B) =
     Bag_Data {(f a,v,n) |a v n. (a,v,n) \<in> B}"
| "push_data f (Node_Data N) =
     Node_Data {(f d,f a,v) |d a v. (d,a,v) \<in> N}"

definition push_object ::
  "('a \<Rightarrow> 'b) \<Rightarrow> ('a,'v) structured_object \<Rightarrow> ('b,'v) structured_object" where
  "push_object f obj =
     \<lparr> object_structure = push_structure f (object_structure obj),
       object_data = push_data f (object_data obj) \<rparr>"

text \<open>
  The data profile records exact payload association only.  No operation in this
  theory interprets a payload as text, number, program, address, authority, or
  proposition.  Such readings require an explicit later Factor definition.
\<close>

end
