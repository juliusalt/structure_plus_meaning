theory RRA_Structural_Syntax
  imports RRA_Exact
begin

section \<open>Incidence-only record geometry\<close>

text \<open>
  The following geometry gives finite records a recoverable field order without
  storing names, tags, ordinals, or a second successor relation.  A field
  participation is accompanied by an isolated incidence chain whose length is
  its structural rank.  All incidence touching that chain is accounted for.
\<close>

fun code_edges :: "'a list \<Rightarrow> ('a \<times> 'a \<times> 'a) set" where
  "code_edges [] = {}"
| "code_edges [a] = {(a,a,a)}"
| "code_edges (a # b # xs) = insert (a,a,b) (code_edges (b # xs))"

definition field_code ::
  "'a rra_structure \<Rightarrow> 'a \<Rightarrow> 'a \<Rightarrow> 'a \<Rightarrow> nat \<Rightarrow> bool" where
  "field_code S r p x n \<longleftrightarrow>
     (\<exists>cs.
        length cs = Suc n \<and> hd cs = p \<and> distinct cs \<and>
        r \<notin> set cs \<and> x \<notin> set cs \<and>
        touching_incidence S (set cs) =
          insert (r,p,x) (code_edges cs))"

definition headed_incidence ::
  "'a rra_structure \<Rightarrow> 'a \<Rightarrow> ('a \<times> 'a) set" where
  "headed_incidence S r = {(p,x). (r,p,x) \<in> rra_incidence S}"

definition raw_record_at ::
  "'a rra_structure \<Rightarrow> 'a \<Rightarrow> 'a list \<Rightarrow> bool" where
  "raw_record_at S r xs \<longleftrightarrow>
     (\<exists>ps.
        length ps = length xs \<and> distinct ps \<and>
        (\<forall>i < length xs. field_code S r (ps ! i) (xs ! i) i) \<and>
        headed_incidence S r =
          {(ps ! i, xs ! i) |i. i < length xs})"

definition record_at ::
  "'a rra_structure \<Rightarrow> 'a \<Rightarrow> 'a list \<Rightarrow> bool" where
  "record_at S r xs \<longleftrightarrow>
     raw_record_at S r xs \<and>
     (\<forall>ys. raw_record_at S r ys \<longrightarrow> ys = xs)"

definition record_root :: "'a rra_structure \<Rightarrow> 'a \<Rightarrow> bool" where
  "record_root S r \<longleftrightarrow> (\<exists>xs. record_at S r xs)"

lemma record_at_unique:
  assumes "record_at S r xs" "record_at S r ys"
  shows "xs = ys"
  using assms by (auto simp: record_at_def)

section \<open>Unordered structural families\<close>

text \<open>
  Families use indistinguishable member positions.  Their semantic projection is
  the exact endpoint set, so no enumeration order acquires force.
\<close>

definition family_member_at ::
  "'a rra_structure \<Rightarrow> 'a \<Rightarrow> 'a \<Rightarrow> 'a \<Rightarrow> bool" where
  "family_member_at S r p x \<longleftrightarrow> field_code S r p x 0"

definition raw_family_at ::
  "'a rra_structure \<Rightarrow> 'a \<Rightarrow> 'a set \<Rightarrow> bool" where
  "raw_family_at S r X \<longleftrightarrow>
     finite X \<and>
     (\<exists>P.
        finite P \<and>
        (\<forall>p \<in> P. \<exists>!x. x \<in> X \<and> family_member_at S r p x) \<and>
        (\<forall>x \<in> X. \<exists>!p. p \<in> P \<and> family_member_at S r p x) \<and>
        headed_incidence S r =
          {(p,x). p \<in> P \<and> x \<in> X \<and> family_member_at S r p x})"

definition family_at ::
  "'a rra_structure \<Rightarrow> 'a \<Rightarrow> 'a set \<Rightarrow> bool" where
  "family_at S r X \<longleftrightarrow>
     raw_family_at S r X \<and>
     (\<forall>Y. raw_family_at S r Y \<longrightarrow> Y = X)"

lemma family_at_unique:
  assumes "family_at S r X" "family_at S r Y"
  shows "X = Y"
  using assms by (auto simp: family_at_def)

section \<open>Structurally recovered exact anchors\<close>

fun functional_pairs ::
  "('a,'v) rra_data \<Rightarrow> ('a \<times> 'v) set" where
  "functional_pairs (Functional_Data F) = F"
| "functional_pairs No_Data = {}"
| "functional_pairs (Bag_Data B) = {}"
| "functional_pairs (Node_Data N) = {}"

definition functional_payload ::
  "('a,'v) structured_object \<Rightarrow> 'a \<Rightarrow> 'v \<Rightarrow> bool" where
  "functional_payload obj a v \<longleftrightarrow>
     profile_kind (object_data obj) = Functional_Profile \<and>
     (a,v) \<in> functional_pairs (object_data obj)"

definition raw_anchor_shape ::
  "exact_artifact \<Rightarrow> local_address \<Rightarrow> exact_anchor \<Rightarrow> bool" where
  "raw_anchor_shape E root a \<longleftrightarrow>
     (case a of
        Whole_Artifact ref \<Rightarrow>
          (\<exists>rnode.
             record_at (object_structure E) root [rnode] \<and>
             functional_payload E rnode ref)
      | Occurrence_Citation ref addr \<Rightarrow>
          (\<exists>rnode anode.
             record_at (object_structure E) root [rnode,anode] \<and>
             functional_payload E rnode ref \<and>
             functional_payload E anode addr))"

definition anchor_shape ::
  "exact_artifact \<Rightarrow> local_address \<Rightarrow> exact_anchor \<Rightarrow> bool" where
  "anchor_shape E root a \<longleftrightarrow>
     exact_formed E \<and> raw_anchor_shape E root a \<and>
     (\<forall>b. raw_anchor_shape E root b \<longrightarrow> b = a)"

definition anchored_at ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow> exact_anchor \<Rightarrow> bool" where
  "anchored_at \<rho> E root a \<longleftrightarrow> anchor_shape E root a \<and> anchor_formed \<rho> a"

lemma anchor_shape_unique:
  assumes "anchor_shape E r a" "anchor_shape E r b"
  shows "a = b"
  using assms by (auto simp: anchor_shape_def)

lemma anchored_at_unique:
  assumes "anchored_at \<rho> E r a" "anchored_at \<rho> E r b"
  shows "a = b"
  using assms anchor_shape_unique by (auto simp: anchored_at_def)

section \<open>Quotation geometry and irrelevance of representation choice\<close>

record 's quotation_geometry =
  quote_value :: "'s \<Rightarrow> exact_artifact"
  read_value :: "exact_artifact \<Rightarrow> 's option"

definition faithful_geometry ::
  "'s set \<Rightarrow> 's quotation_geometry \<Rightarrow> bool" where
  "faithful_geometry A Q \<longleftrightarrow>
     (\<forall>x \<in> A.
        exact_formed (quote_value Q x) \<and>
        read_value Q (quote_value Q x) = Some x) \<and>
     (\<forall>R x. read_value Q R = Some x \<longrightarrow> x \<in> A)"

definition requote ::
  "'s quotation_geometry \<Rightarrow> 's quotation_geometry \<Rightarrow> exact_artifact \<Rightarrow> exact_artifact" where
  "requote Q Q' R = quote_value Q' (the (read_value Q R))"

lemma faithful_requote:
  assumes "faithful_geometry A Q" "faithful_geometry A Q'" "x \<in> A"
  shows "requote Q Q' (quote_value Q x) = quote_value Q' x"
  using assms by (simp add: faithful_geometry_def requote_def)

lemma faithful_requote_round_trip:
  assumes "faithful_geometry A Q" "faithful_geometry A Q'" "x \<in> A"
  shows "requote Q' Q (requote Q Q' (quote_value Q x)) = quote_value Q x"
  using assms by (simp add: faithful_requote)

lemma faithful_behavior_transport:
  assumes "faithful_geometry A Q" "faithful_geometry A Q'" "x \<in> A"
  shows "P (the (read_value Q (quote_value Q x))) \<longleftrightarrow>
         P (the (read_value Q' (requote Q Q' (quote_value Q x))))"
  using assms by (simp add: faithful_geometry_def faithful_requote)

text \<open>
  Reflexive quotation needs no extra representational layer: an exact RRA
  artifact quotes itself.  Any alternative faithful geometry can be transported
  through its structural reader, and the preceding lemmas show that every
  behavior depending only on the recovered value is invariant under transport.
\<close>

definition reflexive_geometry :: "exact_artifact quotation_geometry" where
  "reflexive_geometry =
     \<lparr> quote_value = id,
       read_value = (\<lambda>R. if exact_formed R then Some R else None) \<rparr>"

lemma reflexive_geometry_faithful:
  "faithful_geometry {R. exact_formed R} reflexive_geometry"
  by (auto simp: faithful_geometry_def reflexive_geometry_def)

end
