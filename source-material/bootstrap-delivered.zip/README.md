# RRA–Factor Structural Foundation Bootstrap

## Status

This directory is an Isabelle/HOL bootstrap source session for the integrated
RRA–Factor foundation.  During bootstrap, only the theories named by `ROOT`
are normative.  This README, the audit material, source-package copies,
checksums, archives, and any implementation are nonnormative.

The delivered theories have not been accepted by Isabelle.  No successful
build of this session is on record, and the sections below therefore state
intent rather than established results.  `plan.md` records the verified
defects, the decisions that govern their repair, and the obligations that
must close each one.

## Governing division

RRA is the sole structural substrate. It records occurrence, incidence,
opaque payload, exact identity, fragments, assembly, evidence envelopes,
generations, and publications.

Factor is the programming and semantic language over RRA.  It gives formal
meaning to exact, structurally recovered applications and constructions.  It
does not introduce a second carrier, graph, evaluator, state, effect system,
or live head.

The division is deliberate:

```
RRA formation or linkage  does not imply  Factor meaning or truth.
Factor meaning             cannot escape  exact RRA structure.
```

## Dependency order

The following is the intended order in which structural facts become
available.  It is not the delivered import graph: the delivered `imports`
clauses form one total chain, and several of its links are not dependencies
of the mathematics.  See `THEORY_MAP.md` and `plan.md`.

1. finite relation utilities;
2. RRA occurrence and incidence;
3. semantically opaque data;
4. exact artifacts, references, and citations;
5. incidence-only structural syntax;
6. boundary-complete fragments;
7. exact assembly and its sole origin map;
8. semantically inert evidence links;
9. immutable trajectories and publications;
10. a pure structurally recognized combinator core;
11. Factor semantic closure;
12. finite Factor derivation;
13. Factor-constrained RRA construction;
14. retained evidence and replay;
15. authority-relative succession and currentness;
16. quotation transport and reflective adequacy;
17. genesis and conservative continuation;
18. computational sufficiency;
19. constitutional audit consequences.

A lower theory must never import a later semantic layer, and must not import
an earlier one it does not use.  The second condition fails in the delivered
graph.

## Central distinctions

The theories keep the following propositions separate:

- an RRA artifact is formed;
- an RRA assembly witness is exact (`K2`);
- a structurally quoted Factor judgment is formed;
- a Factor judgment holds;
- a finite Factor derivation is valid;
- an RRA Evidence Envelope retains the required anchors;
- a retained derivation certifies a construction;
- an authority adopts a publication or interpretation;
- a publication selects a generation for a purpose.

No one of these is used as a synonym for another.

## Construction

A Factor construction is semantically valid only through an exact `K2`
assembly witness.  Assembly has one source-to-output map, `q`; Factor may
constrain it but does not carry a second origin map.  The artifact quoting a
judgment is not identified with the judgment's output.  The output is an
independently resolved exact artifact cited by the quoted judgment and by the
assembly witness.

## Evidence

The RRA evidence layer has no nominal envelope kind and no built-in claim,
proof, execution, checker, or trust role.  It records exact anchors and links.
Factor alone recognizes semantic evidence patterns and supplies derivational
or authoritative force.

## Trajectories

Generations and publications are immutable exact structure.  A generation is
identified by its exact occurrence citation in the quoted trajectory.  Only
direct predecessors are stored; ancestry is derived.  There is no mutable
head map.  `Current` is a Factor judgment relative to an exact authority,
publication, locus, generation, purpose, and foundation.

## Bootstrap handoff

Isabelle/HOL is the sole normative source before the handoff.  Reflective
normativity requires an exact genesis artifact together with an Isabelle
proof that its internal Factor interpretation agrees with the externally
defined public judgments on every formed application in the declared domain.
Self-description is not self-authorization.

A successor foundation is a new immutable generation.  It does not change the
meaning of its predecessor.  Its admissibility must be established under the
predecessor foundation and retained through exact assembly and evidence.

## Source basis

The supplied RRA package and Factor proposal are retained under
`source-material/` with checksums.  Their broad separation of concerns and
goals informed the bootstrap.  Their individual generated details are not
automatically normative and are retained only as design provenance.

