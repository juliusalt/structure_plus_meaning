# Theory map

This file is explanatory.  Exact definitions and theorem statements are in the
Isabelle theories.

| Theory | Responsibility |
|---|---|
| `Bootstrap_Relations` | Finite extensional relation, domain/range, exact-map, image, and derived ancestry utilities. |
| `RRA_Core` | The sole carrier/incidence substrate, formation, restriction, transport, isomorphism, reachability, and bounded views. |
| `RRA_Data` | Exact opaque octets and data-profile formation without assigning value semantics. |
| `RRA_Exact` | Exact artifacts, resolvers, non-rebinding reference behavior, whole-artifact anchors, occurrence citations, and exact realization. |
| `RRA_Structural_Syntax` | Incidence-only records, families, byte leaves, anchors, unique structural recovery, and quotation geometry. |
| `RRA_Fragment` | Exact selected substructure, boundary crossings, and explicit omission/remainder. |
| `RRA_Assembly` | Slot-separated piece reuse, copied carriers/incidence/data, one exact `q`, `K2`, and structural quotation of assembly witnesses. |
| `RRA_Evidence` | Generic exact anchor/link envelopes without semantic envelope kinds. |
| `RRA_Trajectory` | Structurally recovered immutable generations, direct predecessors, acyclicity, publications, and exact generation citations. |
| `Factor_Combinator_Core` | Pure topology-recognized S, K, application, and finite combinator reduction as the minimal universal proof instrument. |
| `Factor_Semantics` | Exact structurally quoted judgments, semantic foundations, direct dependency, primitive structural clauses, and least semantic closure. |
| `Factor_Derivation` | Finite structural derivation trees and soundness with respect to already fixed Factor meaning. |
| `Factor_Construction` | Factor admissibility joined to exact `K2` assembly; quoted judgment and result remain distinct. |
| `Factor_Evidence` | Certification and replay as Factor interpretation of generic RRA evidence. |
| `Factor_Authority` | Exact adoption, certified succession, and publication-relative currentness with no head map. |
| `Foundation_Reflection` | Faithful quotation, behavioral transport between quotation choices, identity quotation, and external/internal adequacy. |
| `Foundation_Genesis` | Genesis formation, handoff, and conservative foundation succession. |
| `Foundation_Computational_Sufficiency` | Sound-and-complete Factor realization of finite SK reduction. |
| `Bootstrap_Audit` | Isabelle-visible consequences exposing the constitutional separations. |

## Delivered state of this order

The table above states the intended responsibility of each theory.  It does not
state the delivered import graph.

The delivered `imports` clauses form one total chain, `Bootstrap_Relations`
through `Bootstrap_Audit`.  Several links in that chain are not dependencies of
the mathematics: `RRA_Evidence` imports `RRA_Assembly` without using an assembly
concept, `RRA_Trajectory` imports `RRA_Evidence`, `Factor_Combinator_Core`
imports `RRA_Trajectory`, and `Factor_Semantics` therefore depends transitively
on assembly, evidence, and trajectory.  A generic anchor utility,
`anchor_family_at`, is defined in `RRA_Trajectory` and used by
`Factor_Semantics`, which is one cause of that chain.

An Isabelle import is a logical dependency.  The delivered graph therefore does
not carry the separation this table describes, and the separation must not be
read out of the table instead.  `plan.md` records the dependency structure that
replaces it and the repairs required to reach it.
