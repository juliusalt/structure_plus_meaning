theory Bootstrap_Audit
  imports Foundation_Computational_Sufficiency
begin

section ‹Machine-visible constitutional consequences›

lemma audit_reference_never_rebinds:
  assumes "resolver_formed ρ" "resolves ρ r R" "resolves ρ r R'"
  shows "R = R'"
  using assms resolver_non_rebinding by blast

lemma audit_factor_requires_exact_structure:
  assumes "factor_holds ρ Φ j"
  shows "factor_foundation_formed ρ Φ ∧ formed_factor_judgment ρ j"
  using assms factor_holds_is_structurally_grounded by blast

lemma audit_construction_has_one_origin_graph:
  assumes "factor_constructs ρ Φ j W"
  shows "K2 W ∧ single_valued (assembly_origin W)"
  using assms factor_constructs_has_one_K2_account K2_origin_is_single_valued
  by blast

lemma audit_no_output_occurrence_without_origin:
  assumes "factor_constructs ρ Φ j W"
      and "a ∈ rra_carrier (object_structure (assembly_output W))"
  shows "∃c ∈ copied_carrier (assembly_pieces W).
           (c,a) ∈ assembly_origin W"
  using assms factor_constructs_no_unexplained_output by blast

lemma audit_evidence_formation_is_only_formation:
  assumes "evidence_envelope_formed ρ E"
  shows "exact_formed (evidence_artifact ρ E)"
  using assms evidence_envelope_exact by blast

lemma audit_certification_keeps_questions_distinct:
  assumes "factor_certifies ρ Φ E j D W"
  shows "evidence_envelope_formed ρ E ∧
         factor_derives ρ Φ D j ∧
         factor_constructs ρ Φ j W ∧
         K2 W"
  using assms factor_certifies_sound
  by (auto simp: factor_certifies_def)

lemma audit_currentness_has_no_ambient_form:
  assumes "factor_current ρ Φ d j A P l g purpose"
  shows "publication_formed ρ P ∧
         (l,g) ∈ publication_selections (projected_publication ρ P) ∧
         factor_holds ρ Φ j"
  using assms by (simp add: factor_current_def)

lemma audit_advancement_is_not_mutation:
  assumes "factor_advances ρ Φ T g j D E W"
  shows "trajectory_formed ρ T ∧
         factor_certifies ρ Φ E j D W ∧ K2 W"
  using assms factor_advances_is_certified_construction
  by (auto simp: factor_advances_def generation_in_trajectory_def)

lemma audit_quotation_choice_is_behaviorally_irrelevant:
  assumes "faithful_geometry A Q" "faithful_geometry A Q'"
  shows "behaviorally_equivalent_geometries A Q Q'"
  using assms all_faithful_geometries_behaviorally_equivalent by blast

lemma audit_reflection_is_external_internal_agreement:
  assumes "reflection_valid ρ X B" "j ∈ reflection_domain X"
  shows "j ∈ external_truth X ⟷ factor_holds ρ (reflected_foundation B) j"
  using assms reflection_handoff by blast

lemma audit_complete_genesis_has_no_unstated_computation_layer:
  assumes "complete_genesis ρ X G"
  shows "genesis_formed ρ X G ∧
         (∃program. sk_program_complete ρ (genesis_foundation G) program)"
  using assms
  by (auto simp: complete_genesis_def bootstrap_computationally_sufficient_def)

text ‹
  The theory graph contains no semantic transition system over mutable machine
  states, no effect datatype, no ambient current-head map, no second Factor
  carrier, and no second construction-origin relation.  These absences are also
  checked textually by the nonnormative delivery audit; the lemmas above expose
  the positive mathematical boundaries on which that audit relies.
›

end
