theory Bootstrap_Relations
  imports Main
begin

section ‹Finite extensional relations›

text ‹
  These definitions are mathematical conveniences only.  They introduce no
  stored map object and no procedural reading.  Whenever a relation is used as
  a map, its exact graph is the fact being supplied.
›

definition rel_dom :: "('a × 'b) set ⇒ 'a set" where
  "rel_dom R = {x. ∃y. (x,y) ∈ R}"

definition rel_ran :: "('a × 'b) set ⇒ 'b set" where
  "rel_ran R = {y. ∃x. (x,y) ∈ R}"

definition single_valued :: "('a × 'b) set ⇒ bool" where
  "single_valued R ⟷ (∀x y z. (x,y) ∈ R ⟶ (x,z) ∈ R ⟶ y = z)"

definition total_on :: "'a set ⇒ ('a × 'b) set ⇒ bool" where
  "total_on A R ⟷ rel_dom R = A"

definition graph_map :: "'a set ⇒ ('a ⇒ 'b) ⇒ ('a × 'b) set" where
  "graph_map A f = {(x,f x) |x. x ∈ A}"

definition rel_value :: "('a × 'b) set ⇒ 'a ⇒ 'b" where
  "rel_value R x = (THE y. (x,y) ∈ R)"

definition exact_map :: "'a set ⇒ 'b set ⇒ ('a × 'b) set ⇒ bool" where
  "exact_map A B R ⟷
     finite A ∧ finite B ∧ finite R ∧
     single_valued R ∧ rel_dom R = A ∧ rel_ran R = B"

lemma graph_map_single_valued:
  "single_valued (graph_map A f)"
  by (auto simp: single_valued_def graph_map_def)

lemma graph_map_dom:
  "rel_dom (graph_map A f) = A"
  by (auto simp: rel_dom_def graph_map_def)

lemma graph_map_ran:
  "rel_ran (graph_map A f) = f ` A"
  by (auto simp: rel_ran_def graph_map_def)

lemma rel_value_graph_map:
  assumes "x ∈ A"
  shows "rel_value (graph_map A f) x = f x"
proof -
  have "(THE y. (x,y) ∈ graph_map A f) = f x"
    using assms by (rule the_equality) (auto simp: graph_map_def)
  then show ?thesis
    by (simp add: rel_value_def)
qed

lemma exact_map_value:
  assumes "exact_map A B R" "x ∈ A"
  shows "(x, rel_value R x) ∈ R"
proof -
  from assms have "x ∈ rel_dom R"
    by (simp add: exact_map_def)
  then obtain y where xy: "(x,y) ∈ R"
    by (auto simp: rel_dom_def)
  moreover from assms have "single_valued R"
    by (simp add: exact_map_def)
  ultimately have "(THE z. (x,z) ∈ R) = y"
    by (rule the_equality) (auto simp: single_valued_def)
  with xy show ?thesis
    by (simp add: rel_value_def)
qed

lemma exact_map_value_in_ran:
  assumes "exact_map A B R" "x ∈ A"
  shows "rel_value R x ∈ B"
  using exact_map_value[OF assms] assms
  by (auto simp: exact_map_def rel_ran_def)

definition relation_image ::
  "('a × 'b) set ⇒ ('a × 'a) set ⇒ ('b × 'b) set" where
  "relation_image f R =
     {(rel_value f x, rel_value f y) |x y. (x,y) ∈ R}"

definition ternary_image ::
  "('a × 'b) set ⇒ ('a × 'a × 'a) set ⇒ ('b × 'b × 'b) set" where
  "ternary_image f R =
     {(rel_value f r, rel_value f p, rel_value f x) |r p x.
        (r,p,x) ∈ R}"

section ‹Finite ancestry›

text ‹Only direct edges are stored.  Transitive ancestry is always derived.›

definition strict_ancestor :: "('a × 'a) set ⇒ 'a ⇒ 'a ⇒ bool" where
  "strict_ancestor E x y ⟷ (x,y) ∈ E⁺"

definition acyclic_edges :: "('a × 'a) set ⇒ bool" where
  "acyclic_edges E ⟷ (∀x. (x,x) ∉ E⁺)"

lemma strict_ancestor_irrefl:
  assumes "acyclic_edges E"
  shows "¬ strict_ancestor E x x"
  using assms by (simp add: acyclic_edges_def strict_ancestor_def)

lemma strict_ancestor_trans:
  assumes "strict_ancestor E x y" "strict_ancestor E y z"
  shows "strict_ancestor E x z"
  using assms unfolding strict_ancestor_def by (meson trancl_trans)

end
