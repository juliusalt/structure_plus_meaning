theory Factor_Authority
  imports Factor_Evidence
begin

section ‹Exact authority applications›

definition factor_application_exact ::
  "artifact_resolver ⇒ exact_anchor ⇒ exact_anchor ⇒ exact_anchor list ⇒ bool" where
  "factor_application_exact ρ j definition arguments ⟷
     (∃J. factor_judgment_at ρ j J ∧
          judgment_definition J = definition ∧
          judgment_arguments J = arguments)"

definition factor_adopts ::
  "artifact_resolver ⇒ factor_foundation ⇒
   exact_anchor ⇒ exact_anchor ⇒ exact_anchor ⇒ exact_anchor ⇒
   exact_anchor ⇒ exact_anchor ⇒ bool" where
  "factor_adopts ρ Φ adoption_definition judgment authority subject purpose basis ⟷
     factor_application_exact ρ judgment adoption_definition
       [authority,subject,purpose,basis] ∧
     factor_holds ρ Φ judgment"

text ‹
  Adoption is an exact Factor judgment.  It neither proves its subject nor
  changes the subject's structure.  Different authority, purpose, basis, or
  foundation arguments produce different judgments.
›

section ‹Publication-relative currentness›

definition publication_anchor :: "publication ⇒ exact_anchor" where
  "publication_anchor P =
     Occurrence_Citation (publication_reference P) (publication_root P)"

definition factor_current ::
  "artifact_resolver ⇒ factor_foundation ⇒ exact_anchor ⇒ exact_anchor ⇒
   exact_anchor ⇒ publication ⇒ exact_anchor ⇒ exact_anchor ⇒ exact_anchor ⇒ bool" where
  "factor_current ρ Φ current_definition judgment authority P locus generation purpose ⟷
     publication_formed ρ P ∧
     (locus,generation) ∈
       publication_selections (projected_publication ρ P) ∧
     factor_application_exact ρ judgment current_definition
       [authority,publication_anchor P,locus,generation,purpose] ∧
     factor_holds ρ Φ judgment"

lemma factor_current_has_exact_publication:
  assumes "factor_current ρ Φ d j A P l g purpose"
  shows "publication_formed ρ P ∧
         (l,g) ∈ publication_selections (projected_publication ρ P)"
  using assms by (simp add: factor_current_def)

text ‹
  There is intentionally no unqualified current predicate.  Removing any of
  foundation, authority, publication, locus, generation, or purpose changes the
  question rather than abbreviating it.
›

section ‹Certified immutable advancement›

definition generation_in_trajectory ::
  "artifact_resolver ⇒ trajectory ⇒ local_address ⇒
   generation_projection ⇒ bool" where
  "generation_in_trajectory ρ T g G ⟷
     trajectory_formed ρ T ∧
     g ∈ trajectory_generation_roots ρ T ∧
     generation_at ρ (trajectory_artifact ρ T) g G"

definition factor_advances ::
  "artifact_resolver ⇒ factor_foundation ⇒ trajectory ⇒ local_address ⇒
   exact_anchor ⇒ factor_derivation ⇒ evidence_envelope ⇒
   local_address assembly_witness ⇒ bool" where
  "factor_advances ρ Φ T g' j D E W ⟷
     (∃G C out_ref.
        generation_in_trajectory ρ T g' G ∧
        factor_construction_at ρ j C ∧
        factor_certifies ρ Φ E j D W ∧
        generation_payload G = Whole_Artifact out_ref ∧
        resolves ρ out_ref (assembly_output W) ∧
        generation_predecessors G ∪ generation_dependencies G =
          set (construction_inputs C) ∧
        evidence_envelope_anchor E ∈ generation_evidence G)"

lemma factor_advances_is_certified_construction:
  assumes "factor_advances ρ Φ T g j D E W"
  shows "factor_certifies ρ Φ E j D W ∧ K2 W"
  using assms factor_certifies_sound
  by (auto simp: factor_advances_def)

lemma factor_advances_payload_is_output:
  assumes "factor_advances ρ Φ T g j D E W"
  shows "∃G out_ref.
           generation_in_trajectory ρ T g G ∧
           generation_payload G = Whole_Artifact out_ref ∧
           resolves ρ out_ref (assembly_output W)"
  using assms by (auto simp: factor_advances_def)

text ‹
  Advancement relates immutable structures.  Branches are multiple generations
  with a common predecessor; a merge is a later certified construction whose
  predecessor set contains the merged generations.  No transaction, lock,
  compare-and-swap, clock, or mutable head belongs to this semantics.
›

end
