theory Factor_Combinator_Core
  imports RRA_Trajectory
begin

section ‹A pure structurally quoted universal calculus›

text ‹
  SK is used only because it gives the smallest convenient universality witness.
  Its constructors below are a metalevel proof instrument.  A term admitted to
  Factor is recovered from incidence topology: zero fields is K, one self field
  is S, and two fields is application.  No constructor name is stored.
›

datatype sk_term =
    SK_K
  | SK_S
  | SK_App sk_term sk_term

inductive raw_sk_term_at :: "exact_artifact ⇒ local_address ⇒ sk_term ⇒ bool" where
  raw_term_K:
    "record_at (object_structure E) r [] ⟹ raw_sk_term_at E r SK_K"
| raw_term_S:
    "record_at (object_structure E) r [r] ⟹ raw_sk_term_at E r SK_S"
| raw_term_App:
    "record_at (object_structure E) r [l,u] ⟹
     raw_sk_term_at E l x ⟹ raw_sk_term_at E u y ⟹
     raw_sk_term_at E r (SK_App x y)"

definition sk_term_at :: "exact_artifact ⇒ local_address ⇒ sk_term ⇒ bool" where
  "sk_term_at E r t ⟷
     raw_sk_term_at E r t ∧ (∀u. raw_sk_term_at E r u ⟶ u = t)"

lemma sk_term_at_unique:
  assumes "sk_term_at E r t" "sk_term_at E r u"
  shows "t = u"
  using assms by (auto simp: sk_term_at_def)

definition quoted_sk_term ::
  "artifact_resolver ⇒ exact_anchor ⇒ sk_term ⇒ bool" where
  "quoted_sk_term ρ a t ⟷
     (case a of
        Whole_Artifact ref ⇒ False
      | Occurrence_Citation ref root ⇒
          (∃E.
             resolves ρ ref E ∧ exact_formed E ∧
             sk_term_at E root t))"

lemma quoted_sk_term_unique:
  assumes "quoted_sk_term ρ a t" "quoted_sk_term ρ a u"
  shows "t = u"
  using assms sk_term_at_unique
  by (cases a) (auto simp: quoted_sk_term_def)

inductive sk_step :: "sk_term ⇒ sk_term ⇒ bool" where
  K_step:
    "sk_step (SK_App (SK_App SK_K x) y) x"
| S_step:
    "sk_step
       (SK_App (SK_App (SK_App SK_S x) y) z)
       (SK_App (SK_App x z) (SK_App y z))"
| App_left:
    "sk_step x x' ⟹ sk_step (SK_App x y) (SK_App x' y)"
| App_right:
    "sk_step y y' ⟹ sk_step (SK_App x y) (SK_App x y')"

definition sk_reduces :: "sk_term ⇒ sk_term ⇒ bool" where
  "sk_reduces x y ⟷ rtranclp sk_step x y"

section ‹The definition itself is selected by topology›

text ‹
  A combinator-step definition is a rooted exact artifact containing precisely a
  two-field record whose children are structurally recovered S and K terms.  S
  and K are not selected by byte names or an external registry.
›

definition raw_combinator_step_definition ::
  "artifact_resolver ⇒ exact_anchor ⇒ bool" where
  "raw_combinator_step_definition ρ d ⟷
     (case d of
        Whole_Artifact ref ⇒ False
      | Occurrence_Citation ref root ⇒
          (∃E s k.
             resolves ρ ref E ∧ exact_formed E ∧
             rooted_complete (object_structure E) root ∧
             record_at (object_structure E) root [s,k] ∧
             sk_term_at E s SK_S ∧
             sk_term_at E k SK_K))"

definition combinator_step_definition ::
  "artifact_resolver ⇒ exact_anchor ⇒ bool" where
  "combinator_step_definition ρ d ⟷ raw_combinator_step_definition ρ d"

text ‹
  The relation is intentionally small and pure.  Its use as a Factor program is
  defined later only when a concrete judgment also contains a complete K2
  assembly quote and an independently cited output artifact.
›

end
