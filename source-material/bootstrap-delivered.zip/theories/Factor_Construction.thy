theory Factor_Construction
  imports Factor_Derivation
begin

section ‹Structurally closed construction applications›

record factor_construction_projection =
  construction_program :: exact_anchor
  construction_inputs :: "exact_anchor list"
  construction_assembly :: structural_assembly
  construction_output :: exact_anchor

definition raw_factor_construction ::
  "artifact_resolver ⇒ exact_anchor ⇒ factor_construction_projection ⇒ bool" where
  "raw_factor_construction ρ j C ⟷
     (∃J input_bundle.
        factor_judgment_at ρ j J ∧
        judgment_definition J = construction_program C ∧
        judgment_arguments J =
          [input_bundle,
           structural_assembly_anchor (construction_assembly C),
           construction_output C] ∧
        anchor_record_bundle ρ input_bundle (construction_inputs C))"

definition factor_construction_at ::
  "artifact_resolver ⇒ exact_anchor ⇒ factor_construction_projection ⇒ bool" where
  "factor_construction_at ρ j C ⟷
     raw_factor_construction ρ j C ∧
     (∀D. raw_factor_construction ρ j D ⟶ D = C)"

lemma factor_construction_unique:
  assumes "factor_construction_at ρ j C" "factor_construction_at ρ j D"
  shows "C = D"
  using assms by (auto simp: factor_construction_at_def)

definition construction_output_resolves ::
  "artifact_resolver ⇒ factor_construction_projection ⇒ exact_artifact ⇒ bool" where
  "construction_output_resolves ρ C R ⟷
     anchor_formed ρ (construction_output C) ∧
     anchor_artifact ρ (construction_output C) = R"

definition factor_constructs ::
  "artifact_resolver ⇒ factor_foundation ⇒ exact_anchor ⇒
   local_address assembly_witness ⇒ bool" where
  "factor_constructs ρ Φ j W ⟷
     (∃C.
        factor_construction_at ρ j C ∧
        factor_holds ρ Φ j ∧
        structural_assembly_formed ρ (construction_assembly C) ∧
        assembly_quote_at ρ (construction_assembly C) W ∧
        construction_output_resolves ρ C (assembly_output W))"

lemma factor_constructs_has_one_K2_account:
  assumes "factor_constructs ρ Φ j W"
  shows "K2 W"
  using assms structural_assembly_quote_K2
  by (auto simp: factor_constructs_def)

lemma factor_constructs_output_is_cited:
  assumes "factor_constructs ρ Φ j W"
  shows "∃C. factor_construction_at ρ j C ∧
             anchor_formed ρ (construction_output C) ∧
             anchor_artifact ρ (construction_output C) = assembly_output W"
  using assms
  by (auto simp: factor_constructs_def construction_output_resolves_def)

lemma factor_constructs_no_unexplained_output:
  assumes "factor_constructs ρ Φ j W"
      and "a ∈ rra_carrier (object_structure (assembly_output W))"
  shows "∃c ∈ copied_carrier (assembly_pieces W).
           (c,a) ∈ assembly_origin W"
  using K2_no_unexplained_output_atom factor_constructs_has_one_K2_account
        assms by blast

section ‹Construction is not evaluation›

text ‹
  A candidate constructor may search for a finite W satisfying
  factor_constructs.  Search order, allocation, scheduling, failure to find a
  witness, and physical execution are absent from the relation.  The output is
  the independently cited assembly output; it is neither the artifact quoting
  j nor the artifact quoting W.
›

definition function_like ::
  "artifact_resolver ⇒ factor_foundation ⇒ exact_anchor ⇒ bool" where
  "function_like ρ Φ program ⟷
     (∀j W j' W' C C'.
        factor_constructs ρ Φ j W ∧
        factor_constructs ρ Φ j' W' ∧
        factor_construction_at ρ j C ∧
        factor_construction_at ρ j' C' ∧
        construction_program C = program ∧
        construction_program C' = program ∧
        construction_inputs C = construction_inputs C' ⟶
        rra_isomorphic (object_structure (assembly_output W))
                       (object_structure (assembly_output W')))"

text ‹
  Functionality is a theorem about a structurally defined program relation.  It
  is not a primitive category of program and does not privilege one evaluator.
›

end
