theory Factor_Derivation
  imports Factor_Semantics
begin

section ‹Structurally retained finite derivations›

record factor_derivation =
  derivation_reference :: artifact_reference
  derivation_root :: local_address

definition factor_derivation_artifact ::
  "artifact_resolver ⇒ factor_derivation ⇒ exact_artifact" where
  "factor_derivation_artifact ρ D = rel_value ρ (derivation_reference D)"

definition seed_node_shape ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒ exact_anchor ⇒ bool" where
  "seed_node_shape ρ E n j ⟷
     (∃jr. record_at (object_structure E) n [jr] ∧ anchored_at ρ E jr j)"

definition primitive_node_shape ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒
   exact_anchor ⇒ exact_anchor ⇒ bool" where
  "primitive_node_shape ρ E n j d ⟷
     (∃jr dr.
        record_at (object_structure E) n [jr,dr] ∧
        anchored_at ρ E jr j ∧ anchored_at ρ E dr d)"

definition consequence_node_shape ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒
   exact_anchor ⇒ exact_anchor ⇒ local_address set ⇒ bool" where
  "consequence_node_shape ρ E n j c N ⟷
     (∃jr cr pr.
        record_at (object_structure E) n [jr,cr,pr] ∧
        anchored_at ρ E jr j ∧
        anchored_at ρ E cr c ∧
        family_at (object_structure E) pr N)"

definition derivation_node_conclusion ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒ exact_anchor ⇒ bool" where
  "derivation_node_conclusion ρ E n j ⟷
     (seed_node_shape ρ E n j ∨
      (∃d. primitive_node_shape ρ E n j d) ∨
      (∃c N. consequence_node_shape ρ E n j c N)) ∧
     (∀k.
       (seed_node_shape ρ E n k ∨
        (∃d. primitive_node_shape ρ E n k d) ∨
        (∃c N. consequence_node_shape ρ E n k c N)) ⟶ k = j)"

inductive derivation_shape_node ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒ bool"
  for ρ E
where
  shape_seed:
    "seed_node_shape ρ E n j ⟹ derivation_shape_node ρ E n"
| shape_primitive:
    "primitive_node_shape ρ E n j d ⟹ derivation_shape_node ρ E n"
| shape_consequence:
    "consequence_node_shape ρ E n j c N ⟹
     (⋀m. m ∈ N ⟹ derivation_shape_node ρ E m) ⟹
     derivation_shape_node ρ E n"

definition factor_derivation_formed ::
  "artifact_resolver ⇒ factor_derivation ⇒ bool" where
  "factor_derivation_formed ρ D ⟷
     resolver_formed ρ ∧
     resolves ρ (derivation_reference D) (factor_derivation_artifact ρ D) ∧
     exact_formed (factor_derivation_artifact ρ D) ∧
     rooted_complete (object_structure (factor_derivation_artifact ρ D))
                     (derivation_root D) ∧
     derivation_shape_node ρ (factor_derivation_artifact ρ D)
                           (derivation_root D)"

section ‹Clause citations›

definition foundation_clause_citation ::
  "factor_foundation ⇒ local_address ⇒ exact_anchor" where
  "foundation_clause_citation Φ c =
     Occurrence_Citation (foundation_reference Φ) c"

definition foundation_clause_at_anchor ::
  "artifact_resolver ⇒ factor_foundation ⇒ exact_anchor ⇒
   factor_clause_projection ⇒ bool" where
  "foundation_clause_at_anchor ρ Φ a C ⟷
     (∃c.
        a = foundation_clause_citation Φ c ∧
        factor_clause_at ρ (factor_foundation_artifact ρ Φ) c C ∧
        C ∈ foundation_clauses (projected_foundation ρ Φ))"

section ‹Validity follows the retained tree›

inductive derives_node ::
  "artifact_resolver ⇒ factor_foundation ⇒ exact_artifact ⇒
   local_address ⇒ exact_anchor ⇒ bool"
  for ρ Φ E
where
  derives_seed:
    "factor_foundation_formed ρ Φ ⟹
     seed_node_shape ρ E n j ⟹
     formed_factor_judgment ρ j ⟹
     j ∈ foundation_seeds (projected_foundation ρ Φ) ⟹
     derives_node ρ Φ E n j"
| derives_primitive:
    "factor_foundation_formed ρ Φ ⟹
     primitive_node_shape ρ E n j d ⟹
     formed_factor_judgment ρ j ⟹
     d = judgment_definition (projected_judgment ρ j) ⟹
     combinator_construction_holds ρ Φ j ⟹
     derives_node ρ Φ E n j"
| derives_consequence:
    "factor_foundation_formed ρ Φ ⟹
     consequence_node_shape ρ E n j ca N ⟹
     foundation_clause_at_anchor ρ Φ ca C ⟹
     clause_conclusion C = j ⟹
     formed_factor_judgment ρ j ⟹
     (⋀m. m ∈ N ⟹ ∃k. derivation_node_conclusion ρ E m k ∧
                           derives_node ρ Φ E m k) ⟹
     {k. ∃m ∈ N. derivation_node_conclusion ρ E m k} =
       clause_premises C ⟹
     (∀k ∈ clause_premises C.
        ∃!m. m ∈ N ∧ derivation_node_conclusion ρ E m k) ⟹
     derives_node ρ Φ E n j"

definition factor_derives ::
  "artifact_resolver ⇒ factor_foundation ⇒ factor_derivation ⇒
   exact_anchor ⇒ bool" where
  "factor_derives ρ Φ D j ⟷
     factor_derivation_formed ρ D ∧
     derives_node ρ Φ (factor_derivation_artifact ρ D)
                       (derivation_root D) j"

lemma derives_node_sound:
  assumes "derives_node ρ Φ E n j"
  shows "factor_holds ρ Φ j"
  using assms
proof (induction rule: derives_node.induct)
  case (derives_seed n j)
  then show ?case
    by (auto simp: factor_holds_def)
next
  case (derives_primitive n j d)
  then show ?case
    by (auto simp: factor_holds_def)
next
  case (derives_consequence n j ca N C)
  have formed: "factor_foundation_formed ρ Φ"
    using derives_consequence.hyps by simp
  have premises:
    "clause_premises C ⊆
       factor_closure
         (foundation_clauses (projected_foundation ρ Φ))
         (foundation_seeds (projected_foundation ρ Φ))"
  proof
    fix k
    assume kin: "k ∈ clause_premises C"
    from derives_consequence.hyps kin obtain m where
      min: "m ∈ N" and mk: "derivation_node_conclusion ρ E m k"
      by blast
    from derives_consequence.hyps(6)[OF min]
    obtain k' where mk': "derivation_node_conclusion ρ E m k'"
                    and dk': "derives_node ρ Φ E m k'" by blast
    have "k' = k"
      using mk mk' by (auto simp: derivation_node_conclusion_def)
    with derives_consequence.IH[OF min, of k'] dk'
    show "k ∈ factor_closure
              (foundation_clauses (projected_foundation ρ Φ))
              (foundation_seeds (projected_foundation ρ Φ))"
      by (auto simp: factor_holds_def)
  qed
  from derives_consequence.hyps have cin:
    "C ∈ foundation_clauses (projected_foundation ρ Φ)"
    by (auto simp: foundation_clause_at_anchor_def)
  have concl:
    "j ∈ factor_closure
          (foundation_clauses (projected_foundation ρ Φ))
          (foundation_seeds (projected_foundation ρ Φ))"
    using factor_closure.consequence[OF cin premises]
          derives_consequence.hyps by simp
  show ?case
    using formed concl derives_consequence.hyps
    by (auto simp: factor_holds_def)
qed

lemma factor_derives_sound:
  assumes "factor_derives ρ Φ D j"
  shows "factor_holds ρ Φ j"
  using assms derives_node_sound
  by (auto simp: factor_derives_def)

text ‹
  A derivation is evidence for an already meaningful judgment.  Seed,
  structural primitive, and clause-consequence nodes have disjoint arities.
  Every premise occurrence remains explicit and no layout node creates a
  semantic fact.
›

end
