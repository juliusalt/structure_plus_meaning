theory Factor_Evidence
  imports Factor_Construction
begin

section ‹Factor recognition of retained evidence›

definition factor_foundation_anchor ::
  "factor_foundation ⇒ exact_anchor" where
  "factor_foundation_anchor Φ =
     Occurrence_Citation (foundation_reference Φ) (foundation_root Φ)"

definition factor_derivation_anchor ::
  "factor_derivation ⇒ exact_anchor" where
  "factor_derivation_anchor D =
     Occurrence_Citation (derivation_reference D) (derivation_root D)"

definition required_certificate_links ::
  "factor_foundation ⇒ factor_derivation ⇒ structural_assembly ⇒
   exact_anchor ⇒ (exact_anchor × exact_anchor) set" where
  "required_certificate_links Φ D A j =
     {(j, factor_derivation_anchor D),
      (j, structural_assembly_anchor A),
      (factor_derivation_anchor D, factor_foundation_anchor Φ)}"

definition factor_certifies ::
  "artifact_resolver ⇒ factor_foundation ⇒ evidence_envelope ⇒
   exact_anchor ⇒ factor_derivation ⇒ local_address assembly_witness ⇒ bool" where
  "factor_certifies ρ Φ E j D W ⟷
     evidence_envelope_formed ρ E ∧
     factor_derives ρ Φ D j ∧
     factor_constructs ρ Φ j W ∧
     (∃C.
        factor_construction_at ρ j C ∧
        required_certificate_links Φ D (construction_assembly C) j
          ⊆ envelope_links ρ E)"

lemma factor_certifies_derivation:
  assumes "factor_certifies ρ Φ E j D W"
  shows "factor_derives ρ Φ D j"
  using assms by (simp add: factor_certifies_def)

lemma factor_certifies_construction:
  assumes "factor_certifies ρ Φ E j D W"
  shows "factor_constructs ρ Φ j W"
  using assms by (simp add: factor_certifies_def)

lemma factor_certifies_sound:
  assumes "factor_certifies ρ Φ E j D W"
  shows "factor_holds ρ Φ j ∧ K2 W"
  using assms factor_derives_sound factor_constructs_has_one_K2_account
  by (auto simp: factor_certifies_def)

section ‹Replay without semantic duplication›

text ‹
  Replay checks that a valid derivation, its exact assembly, and their retained
  citations occur together.  It does not add a second truth relation.  Its
  semantic consequence is inherited solely from factor_derives_sound.
›

definition factor_replays ::
  "artifact_resolver ⇒ factor_foundation ⇒ evidence_envelope ⇒
   exact_anchor ⇒ factor_derivation ⇒ local_address assembly_witness ⇒ bool" where
  "factor_replays ρ Φ E j D W ⟷ factor_certifies ρ Φ E j D W"

lemma factor_replays_sound:
  assumes "factor_replays ρ Φ E j D W"
  shows "factor_holds ρ Φ j ∧ factor_constructs ρ Φ j W ∧ K2 W"
  using assms factor_certifies_sound factor_certifies_construction
  by (auto simp: factor_replays_def)

text ‹
  Additional envelope links may retain sources, correspondence, challenges,
  residuals, or provenance.  They acquire a role only through further exact
  Factor definitions.  Their mere presence cannot change the conclusion of the
  derivation retained here.
›

end
