theory Factor_Semantics
  imports Factor_Combinator_Core
begin

section ‹Structural judgments›

text ‹
  The records in this theory are uniquely recovered metalevel projections.  No
  public judgment accepts one without the exact RRA artifact and incidence
  pattern that determine it.  Their field names carry no stored or independently
  supplied semantic force.
›

record factor_judgment_projection =
  judgment_definition :: exact_anchor
  judgment_arguments :: "exact_anchor list"

definition anchor_record_at ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒ exact_anchor list ⇒ bool" where
  "anchor_record_at ρ E root A ⟷
     (∃R.
        record_at (object_structure E) root R ∧
        length R = length A ∧
        (∀i < length R. anchored_at ρ E (R ! i) (A ! i)))"

definition anchor_record_bundle ::
  "artifact_resolver ⇒ exact_anchor ⇒ exact_anchor list ⇒ bool" where
  "anchor_record_bundle ρ a A ⟷
     (case a of
        Whole_Artifact r ⇒ False
      | Occurrence_Citation r root ⇒
          (∃E. resolves ρ r E ∧ anchor_record_at ρ E root A))"

definition raw_factor_judgment ::
  "artifact_resolver ⇒ exact_anchor ⇒ factor_judgment_projection ⇒ bool" where
  "raw_factor_judgment ρ j J ⟷
     (case j of
        Whole_Artifact r ⇒ False
      | Occurrence_Citation r root ⇒
          (∃E dr ar.
             resolves ρ r E ∧
             record_at (object_structure E) root [dr,ar] ∧
             anchored_at ρ E dr (judgment_definition J) ∧
             anchor_record_at ρ E ar (judgment_arguments J)))"

definition factor_judgment_at ::
  "artifact_resolver ⇒ exact_anchor ⇒ factor_judgment_projection ⇒ bool" where
  "factor_judgment_at ρ j J ⟷
     raw_factor_judgment ρ j J ∧
     (∀K. raw_factor_judgment ρ j K ⟶ K = J)"

definition formed_factor_judgment ::
  "artifact_resolver ⇒ exact_anchor ⇒ bool" where
  "formed_factor_judgment ρ j ⟷ (∃!J. factor_judgment_at ρ j J)"

lemma factor_judgment_unique:
  assumes "factor_judgment_at ρ j J" "factor_judgment_at ρ j K"
  shows "J = K"
  using assms by (auto simp: factor_judgment_at_def)

definition projected_judgment ::
  "artifact_resolver ⇒ exact_anchor ⇒ factor_judgment_projection" where
  "projected_judgment ρ j = (THE J. factor_judgment_at ρ j J)"

section ‹Ground structural clauses›

record factor_clause_projection =
  clause_premises :: "exact_anchor set"
  clause_conclusion :: exact_anchor

definition raw_factor_clause ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒
   factor_clause_projection ⇒ bool" where
  "raw_factor_clause ρ E c C ⟷
     (∃pr cr.
        record_at (object_structure E) c [pr,cr] ∧
        anchor_family_at ρ E pr (clause_premises C) ∧
        anchored_at ρ E cr (clause_conclusion C))"

definition factor_clause_at ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒
   factor_clause_projection ⇒ bool" where
  "factor_clause_at ρ E c C ⟷
     raw_factor_clause ρ E c C ∧
     (∀D. raw_factor_clause ρ E c D ⟶ D = C)"

lemma factor_clause_unique:
  assumes "factor_clause_at ρ E c C" "factor_clause_at ρ E c D"
  shows "C = D"
  using assms by (auto simp: factor_clause_at_def)

section ‹Exact foundations›

record factor_foundation_projection =
  foundation_primitives :: "exact_anchor set"
  foundation_seeds :: "exact_anchor set"
  foundation_clauses :: "factor_clause_projection set"
  foundation_dependencies :: "exact_anchor set"

record factor_foundation =
  foundation_reference :: artifact_reference
  foundation_root :: local_address

definition factor_foundation_artifact ::
  "artifact_resolver ⇒ factor_foundation ⇒ exact_artifact" where
  "factor_foundation_artifact ρ Φ = rel_value ρ (foundation_reference Φ)"

definition clause_family_at ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒
   factor_clause_projection set ⇒ bool" where
  "clause_family_at ρ E root C ⟷
     (∃R.
        family_at (object_structure E) root R ∧
        (∀r ∈ R. ∃!c. factor_clause_at ρ E r c) ∧
        C = {c. ∃r ∈ R. factor_clause_at ρ E r c})"

definition raw_factor_foundation_at ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒
   factor_foundation_projection ⇒ bool" where
  "raw_factor_foundation_at ρ E root F ⟷
     (∃pr sr cr dr.
        record_at (object_structure E) root [pr,sr,cr,dr] ∧
        anchor_family_at ρ E pr (foundation_primitives F) ∧
        anchor_family_at ρ E sr (foundation_seeds F) ∧
        clause_family_at ρ E cr (foundation_clauses F) ∧
        anchor_family_at ρ E dr (foundation_dependencies F))"

definition factor_foundation_at ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒
   factor_foundation_projection ⇒ bool" where
  "factor_foundation_at ρ E root F ⟷
     raw_factor_foundation_at ρ E root F ∧
     (∀G. raw_factor_foundation_at ρ E root G ⟶ G = F)"

definition factor_foundation_formed ::
  "artifact_resolver ⇒ factor_foundation ⇒ bool" where
  "factor_foundation_formed ρ Φ ⟷
     resolver_formed ρ ∧
     resolves ρ (foundation_reference Φ) (factor_foundation_artifact ρ Φ) ∧
     exact_formed (factor_foundation_artifact ρ Φ) ∧
     rooted_complete (object_structure (factor_foundation_artifact ρ Φ))
                     (foundation_root Φ) ∧
     (∃!F. factor_foundation_at ρ (factor_foundation_artifact ρ Φ)
                                    (foundation_root Φ) F) ∧
     (∀F. factor_foundation_at ρ (factor_foundation_artifact ρ Φ)
                                  (foundation_root Φ) F ⟶
        (∀p ∈ foundation_primitives F. combinator_step_definition ρ p) ∧
        (∀j ∈ foundation_seeds F. formed_factor_judgment ρ j) ∧
        (∀C ∈ foundation_clauses F.
           formed_factor_judgment ρ (clause_conclusion C) ∧
           (∀j ∈ clause_premises C. formed_factor_judgment ρ j)) ∧
        (∀d ∈ foundation_dependencies F. anchor_formed ρ d))"

definition projected_foundation ::
  "artifact_resolver ⇒ factor_foundation ⇒ factor_foundation_projection" where
  "projected_foundation ρ Φ =
     (THE F. factor_foundation_at ρ (factor_foundation_artifact ρ Φ)
                                     (foundation_root Φ) F)"

section ‹Pure combinator construction is a structural primitive›

text ‹
  The only bootstrap computational primitive is the topology-recognized SK
  relation.  A primitive judgment is accepted only when it also cites a complete
  structural assembly quote and an independently resolved output artifact.
›

definition combinator_construction_holds ::
  "artifact_resolver ⇒ factor_foundation ⇒ exact_anchor ⇒ bool" where
  "combinator_construction_holds ρ Φ j ⟷
     (∃J input_bundle input A W output t u.
        factor_judgment_at ρ j J ∧
        judgment_definition J ∈
          foundation_primitives (projected_foundation ρ Φ) ∧
        combinator_step_definition ρ (judgment_definition J) ∧
        judgment_arguments J =
          [input_bundle,structural_assembly_anchor A,output] ∧
        anchor_record_bundle ρ input_bundle [input] ∧
        structural_assembly_formed ρ A ∧
        assembly_quote_at ρ A W ∧
        anchor_formed ρ output ∧
        anchor_artifact ρ output = assembly_output W ∧
        quoted_sk_term ρ input t ∧
        quoted_sk_term ρ output u ∧
        sk_step t u)"

section ‹Least structural meaning›

inductive_set factor_closure ::
  "factor_clause_projection set ⇒ exact_anchor set ⇒ exact_anchor set"
  for C S
where
  seed[intro]: "j ∈ S ⟹ j ∈ factor_closure C S"
| consequence[intro]:
    "c ∈ C ⟹ clause_premises c ⊆ factor_closure C S ⟹
     clause_conclusion c ∈ factor_closure C S"

definition factor_holds ::
  "artifact_resolver ⇒ factor_foundation ⇒ exact_anchor ⇒ bool" where
  "factor_holds ρ Φ j ⟷
     factor_foundation_formed ρ Φ ∧
     formed_factor_judgment ρ j ∧
     (combinator_construction_holds ρ Φ j ∨
      j ∈ factor_closure
            (foundation_clauses (projected_foundation ρ Φ))
            (foundation_seeds (projected_foundation ρ Φ)))"

lemma factor_holds_is_structurally_grounded:
  assumes "factor_holds ρ Φ j"
  shows "factor_foundation_formed ρ Φ ∧ formed_factor_judgment ρ j"
  using assms by (simp add: factor_holds_def)

lemma factor_seed_holds:
  assumes formed: "factor_foundation_formed ρ Φ"
      and seed: "j ∈ foundation_seeds (projected_foundation ρ Φ)"
      and judgment: "formed_factor_judgment ρ j"
  shows "factor_holds ρ Φ j"
  using assms by (auto simp: factor_holds_def)

lemma combinator_factor_holds:
  assumes formed: "factor_foundation_formed ρ Φ"
      and judgment: "formed_factor_judgment ρ j"
      and primitive: "combinator_construction_holds ρ Φ j"
  shows "factor_holds ρ Φ j"
  using assms by (auto simp: factor_holds_def)

text ‹
  Apart from the structurally quoted universal combinator relation, meaning is
  the explicit least finite-derivation closure of exact ground clauses.  There
  is no callback selected by a predicate name and no nominal syntax tree
  accepted in place of its quotation.
›

end
