theory Foundation_Computational_Sufficiency
  imports Foundation_Genesis
begin

section ‹Factor realization of pure SK reduction›

definition sk_factor_step ::
  "artifact_resolver ⇒ factor_foundation ⇒ exact_anchor ⇒
   exact_anchor ⇒ sk_term ⇒ exact_anchor ⇒ sk_term ⇒
   exact_anchor ⇒ local_address assembly_witness ⇒ bool" where
  "sk_factor_step ρ Φ program input t output u j W ⟷
     quoted_sk_term ρ input t ∧
     quoted_sk_term ρ output u ∧
     combinator_construction_holds ρ Φ j ∧
     factor_constructs ρ Φ j W ∧
     (∃C.
        factor_construction_at ρ j C ∧
        construction_program C = program ∧
        construction_inputs C = [input] ∧
        construction_output C = output)"

definition sk_program_complete ::
  "artifact_resolver ⇒ factor_foundation ⇒ exact_anchor ⇒ bool" where
  "sk_program_complete ρ Φ program ⟷
     factor_foundation_formed ρ Φ ∧
     program ∈ foundation_primitives (projected_foundation ρ Φ) ∧
     combinator_step_definition ρ program ∧
     (∀input t output u j W.
        sk_factor_step ρ Φ program input t output u j W ⟶ sk_step t u) ∧
     (∀input t u.
        quoted_sk_term ρ input t ∧ sk_step t u ⟶
        (∃output j W.
           sk_factor_step ρ Φ program input t output u j W))"

lemma sk_factor_step_sound:
  assumes "sk_factor_step ρ Φ program input t output u j W"
  shows "sk_step t u"
  using assms
  by (auto simp: sk_factor_step_def combinator_construction_holds_def)

inductive factor_sk_reduces ::
  "artifact_resolver ⇒ factor_foundation ⇒ exact_anchor ⇒
   exact_anchor ⇒ sk_term ⇒ exact_anchor ⇒ sk_term ⇒ bool"
  for ρ Φ program
where
  factor_sk_refl:
    "quoted_sk_term ρ a t ⟹
     factor_sk_reduces ρ Φ program a t a t"
| factor_sk_trans:
    "sk_factor_step ρ Φ program a t b u j W ⟹
     factor_sk_reduces ρ Φ program b u c v ⟹
     factor_sk_reduces ρ Φ program a t c v"

lemma factor_sk_reduces_sound:
  assumes "factor_sk_reduces ρ Φ program a t b u"
  shows "sk_reduces t u"
  using assms
proof (induction rule: factor_sk_reduces.induct)
  case (factor_sk_refl a t)
  then show ?case
    by (simp add: sk_reduces_def)
next
  case (factor_sk_trans a t b u j W c v)
  then show ?case
    using sk_factor_step_sound
    unfolding sk_reduces_def
    by (meson rtranclp.rtrancl_into_rtrancl)
qed

lemma sk_program_complete_one_step:
  assumes complete: "sk_program_complete ρ Φ program"
      and input: "quoted_sk_term ρ a t"
      and step: "sk_step t u"
  shows "∃b j W. sk_factor_step ρ Φ program a t b u j W"
  using assms by (auto simp: sk_program_complete_def)

lemma sk_program_complete_finite_reduction:
  assumes complete: "sk_program_complete ρ Φ program"
      and input: "quoted_sk_term ρ a t"
      and reduction: "sk_reduces t u"
  shows "∃b. factor_sk_reduces ρ Φ program a t b u"
  using reduction input
proof (induction rule: rtranclp_induct[unfolded sk_reduces_def])
  case base
  then show ?case
    by (auto intro: factor_sk_reduces.factor_sk_refl)
next
  case (step y z)
  then obtain b where fb:
    "factor_sk_reduces ρ Φ program a t b y" by blast
  from factor_sk_reduces.cases[OF fb] have qy: "quoted_sk_term ρ b y"
    by auto
  from sk_program_complete_one_step[OF complete qy step.hyps]
  obtain c j W where one: "sk_factor_step ρ Φ program b y c z j W"
    by blast
  show ?case
    using fb one by (auto intro: factor_sk_reduces.factor_sk_trans)
qed

section ‹Computational sufficiency is an adoption condition›

text ‹
  SK combinatory reduction is a standard universal pure calculus.  The
  bootstrap does not add a machine, store, continuation, or effect semantics.
  It requires the exact genesis foundation to contain one topology-recognized
  program satisfying sk_program_complete.  The preceding theorems then transport
  every finite SK reduction into finite Factor constructions and transport every
  such construction back to the corresponding SK step.
›

definition bootstrap_computationally_sufficient ::
  "artifact_resolver ⇒ factor_foundation ⇒ bool" where
  "bootstrap_computationally_sufficient ρ Φ ⟷
     (∃program. sk_program_complete ρ Φ program)"

lemma computational_sufficiency_yields_finite_simulation:
  assumes "bootstrap_computationally_sufficient ρ Φ"
      and "quoted_sk_term ρ a t"
      and "sk_reduces t u"
  shows "∃program b.
           sk_program_complete ρ Φ program ∧
           factor_sk_reduces ρ Φ program a t b u"
  using assms sk_program_complete_finite_reduction
  by (auto simp: bootstrap_computationally_sufficient_def)

definition complete_genesis ::
  "artifact_resolver ⇒ reflection_specification ⇒ genesis_bundle ⇒ bool" where
  "complete_genesis ρ X G ⟷
     genesis_formed ρ X G ∧
     bootstrap_computationally_sufficient ρ (genesis_foundation G)"

lemma complete_genesis_has_reflection_and_computation:
  assumes "complete_genesis ρ X G"
  shows "reflection_valid ρ X (genesis_reflection_bundle G) ∧
         bootstrap_computationally_sufficient ρ (genesis_foundation G)"
  using assms by (auto simp: complete_genesis_def genesis_formed_def)

end
