theory Foundation_Genesis
  imports Foundation_Reflection
begin

section ‹The exact genesis handoff›

record genesis_bundle =
  genesis_reflection_bundle :: reflection_bundle
  genesis_trajectory :: trajectory
  genesis_generation_root :: local_address
  genesis_publication :: publication
  genesis_foundation_locus :: exact_anchor
  genesis_authority :: exact_anchor
  genesis_purpose :: exact_anchor
  genesis_current_definition :: exact_anchor
  genesis_current_judgment :: exact_anchor

definition genesis_foundation :: "genesis_bundle ⇒ factor_foundation" where
  "genesis_foundation G = reflected_foundation (genesis_reflection_bundle G)"

definition genesis_formed ::
  "artifact_resolver ⇒ reflection_specification ⇒ genesis_bundle ⇒ bool" where
  "genesis_formed ρ X G ⟷
     reflection_valid ρ X (genesis_reflection_bundle G) ∧
     (∃P.
        generation_in_trajectory ρ (genesis_trajectory G)
          (genesis_generation_root G) P ∧
        generation_locus P = genesis_foundation_locus G ∧
        generation_predecessors P = {} ∧
        generation_payload P =
          Whole_Artifact (foundation_reference (genesis_foundation G)) ∧
        evidence_envelope_anchor
          (reflection_evidence (genesis_reflection_bundle G))
          ∈ generation_evidence P) ∧
     publication_formed ρ (genesis_publication G) ∧
     (genesis_foundation_locus G,
      generation_identity (genesis_trajectory G)
                          (genesis_generation_root G))
       ∈ publication_selections
            (projected_publication ρ (genesis_publication G)) ∧
     factor_foundation_anchor (genesis_foundation G)
       ∈ publication_dependencies
            (projected_publication ρ (genesis_publication G)) ∧
     evidence_envelope_anchor
       (reflection_evidence (genesis_reflection_bundle G))
       ∈ publication_evidence
            (projected_publication ρ (genesis_publication G)) ∧
     factor_current ρ (genesis_foundation G)
       (genesis_current_definition G)
       (genesis_current_judgment G)
       (genesis_authority G)
       (genesis_publication G)
       (genesis_foundation_locus G)
       (generation_identity (genesis_trajectory G)
                            (genesis_generation_root G))
       (genesis_purpose G)"

lemma genesis_has_external_internal_agreement:
  assumes "genesis_formed ρ X G" "j ∈ reflection_domain X"
  shows "j ∈ external_truth X ⟷ factor_holds ρ (genesis_foundation G) j"
  using assms reflection_handoff
  by (auto simp: genesis_formed_def genesis_foundation_def)

lemma genesis_is_not_self_authorized:
  assumes "genesis_formed ρ X G"
  shows "reflection_valid ρ X (genesis_reflection_bundle G)"
  using assms by (simp add: genesis_formed_def)

lemma genesis_current_is_publication_relative:
  assumes "genesis_formed ρ X G"
  shows "factor_current ρ (genesis_foundation G)
           (genesis_current_definition G)
           (genesis_current_judgment G)
           (genesis_authority G)
           (genesis_publication G)
           (genesis_foundation_locus G)
           (generation_identity (genesis_trajectory G)
                                (genesis_generation_root G))
           (genesis_purpose G)"
  using assms by (simp add: genesis_formed_def)

section ‹Reflective continuation without retroactive meaning›

record foundation_successor_bundle =
  predecessor_foundation :: factor_foundation
  successor_foundation :: factor_foundation
  foundation_trajectory :: trajectory
  successor_generation_root :: local_address
  successor_judgment :: exact_anchor
  successor_derivation :: factor_derivation
  successor_evidence :: evidence_envelope
  successor_assembly :: "local_address assembly_witness"
  successor_publication :: publication

definition foundation_successor ::
  "artifact_resolver ⇒ foundation_successor_bundle ⇒ bool" where
  "foundation_successor ρ B ⟷
     factor_foundation_formed ρ (predecessor_foundation B) ∧
     factor_foundation_formed ρ (successor_foundation B) ∧
     factor_advances ρ (predecessor_foundation B)
       (foundation_trajectory B)
       (successor_generation_root B)
       (successor_judgment B)
       (successor_derivation B)
       (successor_evidence B)
       (successor_assembly B) ∧
     assembly_output (successor_assembly B) =
       factor_foundation_artifact ρ (successor_foundation B) ∧
     publication_formed ρ (successor_publication B)"

lemma successor_uses_predecessor_meaning:
  assumes "foundation_successor ρ B"
  shows "factor_certifies ρ (predecessor_foundation B)
           (successor_evidence B)
           (successor_judgment B)
           (successor_derivation B)
           (successor_assembly B)"
  using assms by (auto simp: foundation_successor_def factor_advances_def)

text ‹
  A successor foundation is a new exact artifact justified under its exact
  predecessor.  It does not alter the predecessor artifact or any judgment
  whose explicit foundation argument is that predecessor.  A change outside
  the predecessor's reflective continuation relation requires a new external
  Isabelle/HOL adequacy handoff; no foundation may grant itself new semantic
  force merely by publication.
›

end
