theory Foundation_Reflection
  imports Factor_Authority
begin

section ‹Behavioral irrelevance of faithful quotation geometry›

text ‹
  A quotation geometry is admissible only through its structural reader.  The
  behavior of quoted Factor material is therefore the behavior of the uniquely
  recovered value, never the spelling or scaffolding chosen by the geometry.
›

definition recovered_behavior ::
  "'a quotation_geometry ⇒ ('a ⇒ bool) ⇒ exact_artifact ⇒ bool" where
  "recovered_behavior Q B R ⟷
     (∃x. read_value Q R = Some x ∧ B x)"

definition behaviorally_equivalent_geometries ::
  "'a set ⇒ 'a quotation_geometry ⇒ 'a quotation_geometry ⇒ bool" where
  "behaviorally_equivalent_geometries A Q Q' ⟷
     faithful_geometry A Q ∧ faithful_geometry A Q' ∧
     (∀B x. x ∈ A ⟶
        recovered_behavior Q B (quote_value Q x) =
        recovered_behavior Q' B (quote_value Q' x))"

lemma all_faithful_geometries_behaviorally_equivalent:
  assumes "faithful_geometry A Q" "faithful_geometry A Q'"
  shows "behaviorally_equivalent_geometries A Q Q'"
  using assms
  by (auto simp: behaviorally_equivalent_geometries_def
      recovered_behavior_def faithful_geometry_def)

lemma quotation_transport_preserves_factor_reasoning:
  assumes faithful: "faithful_geometry A Q" "faithful_geometry A Q'"
      and xin: "x ∈ A"
  shows "recovered_behavior Q B (quote_value Q x) ⟷
         recovered_behavior Q' B (requote Q Q' (quote_value Q x))"
  using faithful xin
  by (auto simp: recovered_behavior_def faithful_geometry_def faithful_requote)

text ‹
  The theorem quantifies over every behavior of the recovered object, including
  Factor closure, construction, derivation, replay, and authority predicates.
  Hence a faithful alternative topology can always be requoted into another
  without changing any such behavior.  The irredundant representative is the
  reflexive geometry: an exact RRA artifact quotes itself.
›

definition bootstrap_quotation_geometry ::
  "exact_artifact quotation_geometry" where
  "bootstrap_quotation_geometry = reflexive_geometry"

lemma bootstrap_quotation_is_faithful:
  "faithful_geometry {R. exact_formed R} bootstrap_quotation_geometry"
  by (simp add: bootstrap_quotation_geometry_def reflexive_geometry_faithful)

section ‹External-to-internal adequacy›

record reflection_specification =
  reflection_domain :: "exact_anchor set"
  external_truth :: "exact_anchor set"

record reflection_bundle =
  reflected_foundation :: factor_foundation
  reflection_evidence :: evidence_envelope

definition reflected_definitions ::
  "artifact_resolver ⇒ reflection_specification ⇒ exact_anchor set" where
  "reflected_definitions ρ X =
     {d. ∃j ∈ reflection_domain X.
        ∃J. factor_judgment_at ρ j J ∧ d = judgment_definition J}"

definition reflection_specification_formed ::
  "artifact_resolver ⇒ reflection_specification ⇒ bool" where
  "reflection_specification_formed ρ X ⟷
     external_truth X ⊆ reflection_domain X ∧
     (∀j ∈ reflection_domain X. formed_factor_judgment ρ j) ∧
     finite (reflected_definitions ρ X)"

definition reflection_links ::
  "artifact_resolver ⇒ factor_foundation ⇒ reflection_specification ⇒
   (exact_anchor × exact_anchor) set" where
  "reflection_links ρ Φ X =
     {(d,factor_foundation_anchor Φ) |d.
        d ∈ reflected_definitions ρ X}"

definition reflection_valid ::
  "artifact_resolver ⇒ reflection_specification ⇒ reflection_bundle ⇒ bool" where
  "reflection_valid ρ X B ⟷
     reflection_specification_formed ρ X ∧
     factor_foundation_formed ρ (reflected_foundation B) ∧
     evidence_envelope_formed ρ (reflection_evidence B) ∧
     reflection_links ρ (reflected_foundation B) X
       ⊆ envelope_links ρ (reflection_evidence B) ∧
     (∀j ∈ reflection_domain X.
        (j ∈ external_truth X) ⟷
        factor_holds ρ (reflected_foundation B) j)"

lemma reflection_handoff:
  assumes "reflection_valid ρ X B" "j ∈ reflection_domain X"
  shows "j ∈ external_truth X ⟷ factor_holds ρ (reflected_foundation B) j"
  using assms by (simp add: reflection_valid_def)

lemma reflection_does_not_self_authorize:
  assumes "reflection_valid ρ X B"
  shows "factor_foundation_formed ρ (reflected_foundation B) ∧
         evidence_envelope_formed ρ (reflection_evidence B)"
  using assms by (simp add: reflection_valid_def)

text ‹
  reflection_domain may contain every formed finite application of the bootstrap
  definitions.  Only the finite set of definition roots must be linked in the
  exact handoff evidence.  external_truth is an Isabelle/HOL bootstrap argument,
  not an internal truth bit stored in the foundation artifact.  It disappears
  from ordinary use after the handoff theorem establishes agreement on the
  complete declared domain.  The evidence records that handoff; it does not
  prove itself.
›

end
