theory RRA_Assembly
  imports RRA_Fragment
begin

section ‹Exact piece occurrences›

record 's exact_piece_family =
  piece_graph :: "('s × exact_artifact) set"

definition piece_family_formed :: "'s exact_piece_family ⇒ bool" where
  "piece_family_formed P ⟷
     finite (piece_graph P) ∧
     single_valued (piece_graph P) ∧
     (∀s R. (s,R) ∈ piece_graph P ⟶ exact_formed R)"

definition piece_slots :: "'s exact_piece_family ⇒ 's set" where
  "piece_slots P = rel_dom (piece_graph P)"

definition piece_at :: "'s exact_piece_family ⇒ 's ⇒ exact_artifact" where
  "piece_at P s = rel_value (piece_graph P) s"

definition copied_carrier ::
  "'s exact_piece_family ⇒ ('s × local_address) set" where
  "copied_carrier P =
     {(s,a). s ∈ piece_slots P ∧
             a ∈ rra_carrier (object_structure (piece_at P s))}"

definition copied_incidence ::
  "'s exact_piece_family ⇒
   (('s × local_address) × ('s × local_address) ×
    ('s × local_address)) set" where
  "copied_incidence P =
     {((s,r),(s,p),(s,x)) |s r p x.
        s ∈ piece_slots P ∧
        (r,p,x) ∈ rra_incidence (object_structure (piece_at P s))}"

section ‹Copied data›

fun functional_component :: "(local_address,octets) rra_data ⇒
  (local_address × octets) set" where
  "functional_component (Functional_Data F) = F"
| "functional_component No_Data = {}"
| "functional_component (Bag_Data B) = {}"
| "functional_component (Node_Data N) = {}"

fun bag_component :: "(local_address,octets) rra_data ⇒
  (local_address × octets × nat) set" where
  "bag_component (Bag_Data B) = B"
| "bag_component No_Data = {}"
| "bag_component (Functional_Data F) = {}"
| "bag_component (Node_Data N) = {}"

fun node_component :: "(local_address,octets) rra_data ⇒
  (local_address × local_address × octets) set" where
  "node_component (Node_Data N) = N"
| "node_component No_Data = {}"
| "node_component (Functional_Data F) = {}"
| "node_component (Bag_Data B) = {}"

definition copied_functional ::
  "'s exact_piece_family ⇒ (('s × local_address) × octets) set" where
  "copied_functional P =
     {((s,a),v) |s a v.
        s ∈ piece_slots P ∧
        (a,v) ∈ functional_component (object_data (piece_at P s))}"

definition copied_bag ::
  "'s exact_piece_family ⇒ (('s × local_address) × octets × nat) set" where
  "copied_bag P =
     {((s,a),v,n) |s a v n.
        s ∈ piece_slots P ∧
        (a,v,n) ∈ bag_component (object_data (piece_at P s))}"

definition copied_node ::
  "'s exact_piece_family ⇒
   (('s × local_address) × ('s × local_address) × octets) set" where
  "copied_node P =
     {((s,d),(s,a),v) |s d a v.
        s ∈ piece_slots P ∧
        (d,a,v) ∈ node_component (object_data (piece_at P s))}"

definition copied_bag_values :: "'s exact_piece_family ⇒ octets set" where
  "copied_bag_values P = {v. ∃c n. (c,v,n) ∈ copied_bag P}"

definition copied_bag_count ::
  "'s exact_piece_family ⇒ ('s × local_address) ⇒ octets ⇒ nat" where
  "copied_bag_count P c v =
     (if ∃n. (c,v,n) ∈ copied_bag P
      then (THE n. (c,v,n) ∈ copied_bag P)
      else 0)"

section ‹One complete assembly account›

record 's assembly_witness =
  assembly_pieces :: "'s exact_piece_family"
  assembly_origin :: "(('s × local_address) × local_address) set"
  assembly_output :: exact_artifact

definition expected_incidence ::
  "'s exact_piece_family ⇒
   ((('s × local_address) × local_address) set) ⇒
   (local_address × local_address × local_address) set" where
  "expected_incidence P q = ternary_image q (copied_incidence P)"

definition expected_functional ::
  "'s exact_piece_family ⇒
   ((('s × local_address) × local_address) set) ⇒
   (local_address × octets) set" where
  "expected_functional P q =
     {(rel_value q c,v) |c v. (c,v) ∈ copied_functional P}"

definition expected_node ::
  "'s exact_piece_family ⇒
   ((('s × local_address) × local_address) set) ⇒
   (local_address × local_address × octets) set" where
  "expected_node P q =
     {(rel_value q d,rel_value q a,v) |d a v. (d,a,v) ∈ copied_node P}"

definition expected_bag ::
  "'s exact_piece_family ⇒
   ((('s × local_address) × local_address) set) ⇒
   (local_address × octets × nat) set" where
  "expected_bag P q =
     {(y,v,n) |y v n.
       y ∈ rel_ran q ∧ v ∈ copied_bag_values P ∧
       n = (∑c∈copied_carrier P.
              if rel_value q c = y then copied_bag_count P c v else 0) ∧
       n > 0}"

definition family_has_profile ::
  "'s exact_piece_family ⇒ data_profile_kind ⇒ bool" where
  "family_has_profile P k ⟷
     (∀s ∈ piece_slots P. profile_kind (object_data (piece_at P s)) = k)"

definition assembled_data ::
  "'s exact_piece_family ⇒
   ((('s × local_address) × local_address) set) ⇒
   (local_address,octets) rra_data ⇒ bool" where
  "assembled_data P q D ⟷
       (family_has_profile P No_Data_Profile ∧ D = No_Data)
     ∨ (family_has_profile P Functional_Profile ∧
        D = Functional_Data (expected_functional P q))
     ∨ (family_has_profile P Bag_Profile ∧
        D = Bag_Data (expected_bag P q))
     ∨ (family_has_profile P Node_Profile ∧
        D = Node_Data (expected_node P q))"

definition K2 :: "'s assembly_witness ⇒ bool" where
  "K2 W ⟷
     piece_family_formed (assembly_pieces W) ∧
     exact_formed (assembly_output W) ∧
     exact_map (copied_carrier (assembly_pieces W))
               (rra_carrier (object_structure (assembly_output W)))
               (assembly_origin W) ∧
     rra_incidence (object_structure (assembly_output W)) =
       expected_incidence (assembly_pieces W) (assembly_origin W) ∧
     assembled_data (assembly_pieces W) (assembly_origin W)
                    (object_data (assembly_output W))"

lemma K2_no_unexplained_output_atom:
  assumes "K2 W"
      and "a ∈ rra_carrier (object_structure (assembly_output W))"
  shows "∃c ∈ copied_carrier (assembly_pieces W).
           (c,a) ∈ assembly_origin W"
  using assms
  by (auto simp: K2_def exact_map_def rel_ran_def rel_dom_def)

lemma K2_origin_is_single_valued:
  assumes "K2 W"
  shows "single_valued (assembly_origin W)"
  using assms by (simp add: K2_def exact_map_def)

lemma K2_glued_iff_same_output:
  assumes "K2 W"
      and "c ∈ copied_carrier (assembly_pieces W)"
      and "d ∈ copied_carrier (assembly_pieces W)"
  shows "rel_value (assembly_origin W) c = rel_value (assembly_origin W) d ⟷
         (∃a. (c,a) ∈ assembly_origin W ∧
              (d,a) ∈ assembly_origin W)"
proof
  assume eq: "rel_value (assembly_origin W) c =
              rel_value (assembly_origin W) d"
  have ca: "(c,rel_value (assembly_origin W) c) ∈ assembly_origin W"
    using exact_map_value assms by (auto simp: K2_def)
  have da: "(d,rel_value (assembly_origin W) d) ∈ assembly_origin W"
    using exact_map_value assms by (auto simp: K2_def)
  show "∃a. (c,a) ∈ assembly_origin W ∧ (d,a) ∈ assembly_origin W"
    using ca da eq by blast
next
  assume "∃a. (c,a) ∈ assembly_origin W ∧ (d,a) ∈ assembly_origin W"
  then obtain a where ca: "(c,a) ∈ assembly_origin W"
                    and da: "(d,a) ∈ assembly_origin W" by blast
  from assms have sv: "single_valued (assembly_origin W)"
    by (simp add: K2_def exact_map_def)
  have "rel_value (assembly_origin W) c = a"
    unfolding rel_value_def
    by (rule the_equality) (use ca sv in ‹auto simp: single_valued_def›)
  moreover have "rel_value (assembly_origin W) d = a"
    unfolding rel_value_def
    by (rule the_equality) (use da sv in ‹auto simp: single_valued_def›)
  ultimately show "rel_value (assembly_origin W) c =
                   rel_value (assembly_origin W) d"
    by simp
qed

lemma K2_output_incidence_has_origin:
  assumes "K2 W"
      and "(r,p,x) ∈ rra_incidence (object_structure (assembly_output W))"
  shows "∃cr cp cx.
           (cr,cp,cx) ∈ copied_incidence (assembly_pieces W) ∧
           rel_value (assembly_origin W) cr = r ∧
           rel_value (assembly_origin W) cp = p ∧
           rel_value (assembly_origin W) cx = x"
  using assms
  by (auto simp: K2_def expected_incidence_def ternary_image_def)

text ‹
  K2 contains no semantic premise.  It verifies only exact reuse, identity
  gluing, incidence transport, and profile-preserving data transport.  Whether
  a program is permitted to select or glue the pieces is a later Factor fact.
›

section ‹Structural quotation of assembly witnesses›

record structural_assembly =
  structural_assembly_reference :: artifact_reference
  structural_assembly_root :: local_address

definition structural_assembly_artifact ::
  "artifact_resolver ⇒ structural_assembly ⇒ exact_artifact" where
  "structural_assembly_artifact ρ A =
     rel_value ρ (structural_assembly_reference A)"

definition structural_assembly_anchor ::
  "structural_assembly ⇒ exact_anchor" where
  "structural_assembly_anchor A =
     Occurrence_Citation (structural_assembly_reference A)
                         (structural_assembly_root A)"

definition quoted_piece_at ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒ exact_artifact ⇒ bool" where
  "quoted_piece_at ρ E p R ⟷
     (∃ar ref.
        record_at (object_structure E) p [ar] ∧
        anchored_at ρ E ar (Whole_Artifact ref) ∧
        resolves ρ ref R)"

definition quoted_piece_family_at ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒
   local_address exact_piece_family ⇒ bool" where
  "quoted_piece_family_at ρ E root P ⟷
     (∃R.
        family_at (object_structure E) root R ∧
        (∀p ∈ R. ∃!O. quoted_piece_at ρ E p O) ∧
        piece_graph P = {(p,O). p ∈ R ∧ quoted_piece_at ρ E p O})"

definition quoted_origin_at ::
  "artifact_resolver ⇒ structural_assembly ⇒ exact_artifact ⇒
   local_address ⇒ ((local_address × local_address) × local_address) ⇒ bool" where
  "quoted_origin_at ρ A E o cy ⟷
     (∃pr ir yr p a y.
        record_at (object_structure E) o [pr,ir,yr] ∧
        anchored_at ρ E pr
          (Occurrence_Citation (structural_assembly_reference A) p) ∧
        functional_payload E ir a ∧
        functional_payload E yr y ∧
        cy = ((p,a),y))"

definition quoted_origin_family_at ::
  "artifact_resolver ⇒ structural_assembly ⇒ exact_artifact ⇒
   local_address ⇒ (((local_address × local_address) × local_address) set) ⇒ bool" where
  "quoted_origin_family_at ρ A E root q ⟷
     (∃R.
        family_at (object_structure E) root R ∧
        (∀o ∈ R. ∃!cy. quoted_origin_at ρ A E o cy) ∧
        q = {cy. ∃o ∈ R. quoted_origin_at ρ A E o cy})"

definition raw_assembly_quote_at ::
  "artifact_resolver ⇒ structural_assembly ⇒
   local_address assembly_witness ⇒ bool" where
  "raw_assembly_quote_at ρ A W ⟷
     (let E = structural_assembly_artifact ρ A in
      ∃pr qr yr ref.
        record_at (object_structure E) (structural_assembly_root A)
                  [pr,qr,yr] ∧
        quoted_piece_family_at ρ E pr (assembly_pieces W) ∧
        quoted_origin_family_at ρ A E qr (assembly_origin W) ∧
        anchored_at ρ E yr (Whole_Artifact ref) ∧
        resolves ρ ref (assembly_output W))"

definition assembly_quote_at ::
  "artifact_resolver ⇒ structural_assembly ⇒
   local_address assembly_witness ⇒ bool" where
  "assembly_quote_at ρ A W ⟷
     raw_assembly_quote_at ρ A W ∧
     (∀V. raw_assembly_quote_at ρ A V ⟶ V = W)"

definition structural_assembly_formed ::
  "artifact_resolver ⇒ structural_assembly ⇒ bool" where
  "structural_assembly_formed ρ A ⟷
     resolver_formed ρ ∧
     resolves ρ (structural_assembly_reference A)
                (structural_assembly_artifact ρ A) ∧
     exact_formed (structural_assembly_artifact ρ A) ∧
     rooted_complete (object_structure (structural_assembly_artifact ρ A))
                     (structural_assembly_root A) ∧
     (∃!W. assembly_quote_at ρ A W ∧ K2 W)"

lemma assembly_quote_unique:
  assumes "assembly_quote_at ρ A W" "assembly_quote_at ρ A V"
  shows "W = V"
  using assms by (auto simp: assembly_quote_at_def)

lemma structural_assembly_quote_K2:
  assumes "structural_assembly_formed ρ A" "assembly_quote_at ρ A W"
  shows "K2 W"
proof -
  from assms(1) obtain V where av: "assembly_quote_at ρ A V" and kv: "K2 V"
    by (auto simp: structural_assembly_formed_def)
  have "V = W"
    using assembly_quote_unique[OF av assms(2)] .
  with kv show ?thesis by simp
qed

text ‹
  This quotation stores no second construction map.  Its origin-entry family is
  precisely the graph used by K2, and the output anchor resolves to precisely
  the output value used by K2.
›

end
