theory RRA_Core
  imports Bootstrap_Relations
begin

section ‹The sole structural universe›

record 'a rra_structure =
  rra_carrier :: "'a set"
  rra_incidence :: "('a × 'a × 'a) set"

definition rra_formed :: "'a rra_structure ⇒ bool" where
  "rra_formed S ⟷
     finite (rra_carrier S) ∧
     finite (rra_incidence S) ∧
     (∀r p x. (r,p,x) ∈ rra_incidence S ⟶
        r ∈ rra_carrier S ∧ p ∈ rra_carrier S ∧ x ∈ rra_carrier S)"

definition relation_occurrences :: "'a rra_structure ⇒ 'a set" where
  "relation_occurrences S = {r. ∃p x. (r,p,x) ∈ rra_incidence S}"

definition participation_occurrences :: "'a rra_structure ⇒ 'a set" where
  "participation_occurrences S = {p. ∃r x. (r,p,x) ∈ rra_incidence S}"

definition reached_occurrences :: "'a rra_structure ⇒ 'a set" where
  "reached_occurrences S = {x. ∃r p. (r,p,x) ∈ rra_incidence S}"

text ‹
  These three sets are projections of tuple positions.  They are not sorts and
  need not be disjoint.  An occurrence may occupy any combination of positions.
›

lemma role_occurrences_in_carrier:
  assumes "rra_formed S"
  shows "relation_occurrences S ⊆ rra_carrier S"
    and "participation_occurrences S ⊆ rra_carrier S"
    and "reached_occurrences S ⊆ rra_carrier S"
  using assms
  by (auto simp: rra_formed_def relation_occurrences_def
      participation_occurrences_def reached_occurrences_def)

definition touching_incidence ::
  "'a rra_structure ⇒ 'a set ⇒ ('a × 'a × 'a) set" where
  "touching_incidence S A =
     {(r,p,x) ∈ rra_incidence S. r ∈ A ∨ p ∈ A ∨ x ∈ A}"

definition internal_incidence ::
  "'a rra_structure ⇒ 'a set ⇒ ('a × 'a × 'a) set" where
  "internal_incidence S A =
     {(r,p,x) ∈ rra_incidence S. r ∈ A ∧ p ∈ A ∧ x ∈ A}"

definition crossing_incidence ::
  "'a rra_structure ⇒ 'a set ⇒ ('a × 'a × 'a) set" where
  "crossing_incidence S A = touching_incidence S A - internal_incidence S A"

definition restrict_structure :: "'a rra_structure ⇒ 'a set ⇒ 'a rra_structure" where
  "restrict_structure S A =
     ⦇ rra_carrier = rra_carrier S ∩ A,
       rra_incidence = internal_incidence S (rra_carrier S ∩ A) ⦈"

lemma restrict_structure_formed:
  assumes "rra_formed S"
  shows "rra_formed (restrict_structure S A)"
  using assms
  by (auto simp: rra_formed_def restrict_structure_def internal_incidence_def)

section ‹Renaming›

definition push_structure :: "('a ⇒ 'b) ⇒ 'a rra_structure ⇒ 'b rra_structure" where
  "push_structure f S =
     ⦇ rra_carrier = f ` rra_carrier S,
       rra_incidence =
         {(f r,f p,f x) |r p x. (r,p,x) ∈ rra_incidence S} ⦈"

definition rra_isomorphism ::
  "('a ⇒ 'b) ⇒ 'a rra_structure ⇒ 'b rra_structure ⇒ bool" where
  "rra_isomorphism f S T ⟷
     bij_betw f (rra_carrier S) (rra_carrier T) ∧
     push_structure f S = T"

definition rra_isomorphic :: "'a rra_structure ⇒ 'b rra_structure ⇒ bool" where
  "rra_isomorphic S T ⟷ (∃f. rra_isomorphism f S T)"

lemma push_structure_formed:
  assumes "rra_formed S"
  shows "rra_formed (push_structure f S)"
  using assms by (auto simp: rra_formed_def push_structure_def)

lemma push_structure_iso:
  assumes "inj_on f (rra_carrier S)"
  shows "rra_isomorphism f S (push_structure f S)"
  using assms
  by (auto simp: rra_isomorphism_def push_structure_def bij_betw_def inj_on_def)

lemma rra_isomorphic_refl:
  "rra_isomorphic S S"
  unfolding rra_isomorphic_def rra_isomorphism_def bij_betw_def
  by (rule exI[of _ id]) auto

section ‹Externally bounded views›

record ('k,'a) bounded_view =
  bounded_structure :: "'a rra_structure"
  boundary_graph :: "('k × 'a) set"

definition boundary_formed :: "('k,'a) bounded_view ⇒ bool" where
  "boundary_formed V ⟷
     rra_formed (bounded_structure V) ∧
     finite (boundary_graph V) ∧
     single_valued (boundary_graph V) ∧
     rel_ran (boundary_graph V) ⊆ rra_carrier (bounded_structure V)"

definition bounded_isomorphism ::
  "('a ⇒ 'b) ⇒ ('k,'a) bounded_view ⇒ ('k,'b) bounded_view ⇒ bool" where
  "bounded_isomorphism f V W ⟷
     rra_isomorphism f (bounded_structure V) (bounded_structure W) ∧
     rel_dom (boundary_graph V) = rel_dom (boundary_graph W) ∧
     boundary_graph W = {(k,f a) |k a. (k,a) ∈ boundary_graph V}"

lemma bounded_isomorphism_preserves_keys:
  assumes "bounded_isomorphism f V W"
  shows "rel_dom (boundary_graph V) = rel_dom (boundary_graph W)"
  using assms by (simp add: bounded_isomorphism_def)

lemma boundary_does_not_change_structure:
  assumes "bounded_structure V = bounded_structure W"
  shows "rra_incidence (bounded_structure V) = rra_incidence (bounded_structure W)"
  using assms by simp

text ‹
  A boundary key belongs to the supplied view.  No predicate in this theory
  turns a key into a property, kind, or stored name of the reached occurrence.
›

section ‹Rooted structural completeness›

definition incidence_step ::
  "'a rra_structure ⇒ ('a × 'a) set" where
  "incidence_step S =
     {(a,b). ∃r p x.
        (r,p,x) ∈ rra_incidence S ∧
        a ∈ {r,p,x} ∧ b ∈ {r,p,x} ∧ a ≠ b}"

definition rooted_complete :: "'a rra_structure ⇒ 'a ⇒ bool" where
  "rooted_complete S root ⟷
     root ∈ rra_carrier S ∧
     rra_carrier S = {root} ∪ {x. (root,x) ∈ (incidence_step S)⁺}"

end
