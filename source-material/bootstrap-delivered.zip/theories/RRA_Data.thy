theory RRA_Data
  imports RRA_Core
begin

section ‹Opaque finite payloads›

type_synonym octets = "nat list"

definition octets_formed :: "octets ⇒ bool" where
  "octets_formed xs ⟷ (∀x ∈ set xs. x < 256)"

datatype ('a,'v) rra_data =
    No_Data
  | Functional_Data "('a × 'v) set"
  | Bag_Data "('a × 'v × nat) set"
  | Node_Data "('a × 'a × 'v) set"

datatype data_profile_kind =
    No_Data_Profile
  | Functional_Profile
  | Bag_Profile
  | Node_Profile

fun profile_kind :: "('a,'v) rra_data ⇒ data_profile_kind" where
  "profile_kind No_Data = No_Data_Profile"
| "profile_kind (Functional_Data F) = Functional_Profile"
| "profile_kind (Bag_Data B) = Bag_Profile"
| "profile_kind (Node_Data N) = Node_Profile"

definition pair_functional :: "('a × 'b) set ⇒ bool" where
  "pair_functional F ⟷ (∀a x y. (a,x) ∈ F ⟶ (a,y) ∈ F ⟶ x = y)"

definition bag_functional :: "('a × 'b × nat) set ⇒ bool" where
  "bag_functional B ⟷
     (∀a v m n. (a,v,m) ∈ B ⟶ (a,v,n) ∈ B ⟶ m = n)"

definition node_functional :: "('a × 'a × 'b) set ⇒ bool" where
  "node_functional N ⟷
     (∀d a v b w. (d,a,v) ∈ N ⟶ (d,b,w) ∈ N ⟶ a = b ∧ v = w)"

fun data_formed :: "'a set ⇒ ('a,'v) rra_data ⇒ bool" where
  "data_formed U No_Data = True"
| "data_formed U (Functional_Data F) =
     (finite F ∧ pair_functional F ∧ (∀a v. (a,v) ∈ F ⟶ a ∈ U))"
| "data_formed U (Bag_Data B) =
     (finite B ∧ bag_functional B ∧
      (∀a v n. (a,v,n) ∈ B ⟶ a ∈ U ∧ n > 0))"
| "data_formed U (Node_Data N) =
     (finite N ∧ node_functional N ∧
      (∀d a v. (d,a,v) ∈ N ⟶ d ∈ U ∧ a ∈ U))"

record ('a,'v) structured_object =
  object_structure :: "'a rra_structure"
  object_data :: "('a,'v) rra_data"

definition object_formed :: "('a,'v) structured_object ⇒ bool" where
  "object_formed O ⟷
     rra_formed (object_structure O) ∧
     data_formed (rra_carrier (object_structure O)) (object_data O)"

fun restrict_data :: "'a set ⇒ ('a,'v) rra_data ⇒ ('a,'v) rra_data" where
  "restrict_data A No_Data = No_Data"
| "restrict_data A (Functional_Data F) =
     Functional_Data {(a,v) ∈ F. a ∈ A}"
| "restrict_data A (Bag_Data B) =
     Bag_Data {(a,v,n) ∈ B. a ∈ A}"
| "restrict_data A (Node_Data N) =
     Node_Data {(d,a,v) ∈ N. d ∈ A ∧ a ∈ A}"

definition restrict_object ::
  "('a,'v) structured_object ⇒ 'a set ⇒ ('a,'v) structured_object" where
  "restrict_object O A =
     ⦇ object_structure = restrict_structure (object_structure O) A,
       object_data = restrict_data (rra_carrier (object_structure O) ∩ A)
                                   (object_data O) ⦈"

lemma restrict_data_formed:
  assumes "data_formed U D"
  shows "data_formed (U ∩ A) (restrict_data (U ∩ A) D)"
  using assms
  by (cases D) (auto simp: pair_functional_def bag_functional_def node_functional_def)

lemma restrict_object_formed:
  assumes "object_formed O"
  shows "object_formed (restrict_object O A)"
  using assms restrict_structure_formed
  by (auto simp: object_formed_def restrict_object_def)

fun push_data :: "('a ⇒ 'b) ⇒ ('a,'v) rra_data ⇒ ('b,'v) rra_data" where
  "push_data f No_Data = No_Data"
| "push_data f (Functional_Data F) =
     Functional_Data {(f a,v) |a v. (a,v) ∈ F}"
| "push_data f (Bag_Data B) =
     Bag_Data {(f a,v,n) |a v n. (a,v,n) ∈ B}"
| "push_data f (Node_Data N) =
     Node_Data {(f d,f a,v) |d a v. (d,a,v) ∈ N}"

definition push_object ::
  "('a ⇒ 'b) ⇒ ('a,'v) structured_object ⇒ ('b,'v) structured_object" where
  "push_object f O =
     ⦇ object_structure = push_structure f (object_structure O),
       object_data = push_data f (object_data O) ⦈"

text ‹
  The data profile records exact payload association only.  No operation in this
  theory interprets a payload as text, number, program, address, authority, or
  proposition.  Such readings require an explicit later Factor definition.
›

end
