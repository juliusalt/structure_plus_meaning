theory RRA_Evidence
  imports RRA_Assembly
begin

section ‹Semantically inert exact envelopes›

record evidence_envelope =
  envelope_reference :: artifact_reference
  envelope_root :: local_address

definition evidence_artifact ::
  "artifact_resolver ⇒ evidence_envelope ⇒ exact_artifact" where
  "evidence_artifact ρ E = rel_value ρ (envelope_reference E)"

definition envelope_link_at ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒
   exact_anchor ⇒ exact_anchor ⇒ bool" where
  "envelope_link_at ρ E l a b ⟷
     (∃ar br.
        record_at (object_structure E) l [ar,br] ∧
        anchored_at ρ E ar a ∧
        anchored_at ρ E br b)"

definition raw_envelope_projection ::
  "artifact_resolver ⇒ evidence_envelope ⇒
   local_address set ⇒ bool" where
  "raw_envelope_projection ρ E L ⟷
     resolves ρ (envelope_reference E) (evidence_artifact ρ E) ∧
     exact_formed (evidence_artifact ρ E) ∧
     rooted_complete (object_structure (evidence_artifact ρ E))
                     (envelope_root E) ∧
     family_at (object_structure (evidence_artifact ρ E))
               (envelope_root E) L ∧
     (∀l ∈ L. ∃!ab. envelope_link_at ρ (evidence_artifact ρ E) l
                                      (fst ab) (snd ab))"

definition evidence_envelope_formed ::
  "artifact_resolver ⇒ evidence_envelope ⇒ bool" where
  "evidence_envelope_formed ρ E ⟷
     resolver_formed ρ ∧
     (∃!L. raw_envelope_projection ρ E L)"

definition envelope_link_roots ::
  "artifact_resolver ⇒ evidence_envelope ⇒ local_address set" where
  "envelope_link_roots ρ E =
     (THE L. raw_envelope_projection ρ E L)"

definition envelope_links ::
  "artifact_resolver ⇒ evidence_envelope ⇒
   (exact_anchor × exact_anchor) set" where
  "envelope_links ρ E =
     {(a,b). ∃l ∈ envelope_link_roots ρ E.
        envelope_link_at ρ (evidence_artifact ρ E) l a b}"

definition evidence_envelope_anchor ::
  "evidence_envelope ⇒ exact_anchor" where
  "evidence_envelope_anchor E =
     Occurrence_Citation (envelope_reference E) (envelope_root E)"

lemma evidence_envelope_exact:
  assumes "evidence_envelope_formed ρ E"
  shows "exact_formed (evidence_artifact ρ E)"
proof -
  from assms obtain L where "raw_envelope_projection ρ E L"
    by (auto simp: evidence_envelope_formed_def)
  then show ?thesis
    by (simp add: raw_envelope_projection_def)
qed

text ‹
  This theory assigns no evidential role to either endpoint of a link.  It does
  not distinguish claims, premises, results, checkers, provenance, trust, or
  residuals.  Those are Factor-recognized structural patterns over this one
  envelope substrate.  Formation alone has no truth, proof, or authority
  consequence.
›

end
