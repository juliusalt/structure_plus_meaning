theory RRA_Exact
  imports RRA_Data
begin

section ‹Exact addressed artifacts›

type_synonym local_address = octets
type_synonym exact_artifact = "(local_address,octets) structured_object"
type_synonym artifact_reference = octets

fun data_values :: "('a,'v) rra_data ⇒ 'v set" where
  "data_values No_Data = {}"
| "data_values (Functional_Data F) = {v. ∃a. (a,v) ∈ F}"
| "data_values (Bag_Data B) = {v. ∃a n. (a,v,n) ∈ B}"
| "data_values (Node_Data N) = {v. ∃d a. (d,a,v) ∈ N}"

definition exact_formed :: "exact_artifact ⇒ bool" where
  "exact_formed R ⟷
     object_formed R ∧
     (∀a ∈ rra_carrier (object_structure R). octets_formed a) ∧
     (∀v ∈ data_values (object_data R). octets_formed v)"

text ‹
  Exact artifact identity is ordinary equality of the complete mathematical
  record.  A digest or reference may identify that value externally, but is not
  substituted for it here.
›

lemma exact_identity_iff:
  "R = R' ⟷
   object_structure R = object_structure R' ∧ object_data R = object_data R'"
  by (cases R; cases R') auto

section ‹Reference environments and occurrence citations›

type_synonym artifact_resolver =
  "(artifact_reference × exact_artifact) set"

definition resolver_formed :: "artifact_resolver ⇒ bool" where
  "resolver_formed ρ ⟷
     finite ρ ∧ single_valued ρ ∧
     (∀r R. (r,R) ∈ ρ ⟶ octets_formed r ∧ exact_formed R)"

definition resolves ::
  "artifact_resolver ⇒ artifact_reference ⇒ exact_artifact ⇒ bool" where
  "resolves ρ r R ⟷ (r,R) ∈ ρ"

lemma resolver_non_rebinding:
  assumes "resolver_formed ρ" "resolves ρ r R" "resolves ρ r R'"
  shows "R = R'"
  using assms by (auto simp: resolver_formed_def resolves_def single_valued_def)

text ‹
  The following sum is a metalevel projection used by the bootstrap.  Later
  theories define an RRA topology from which its two alternatives are uniquely
  recovered.  The constructor names are not stored semantic tags.
›

datatype exact_anchor =
    Whole_Artifact artifact_reference
  | Occurrence_Citation artifact_reference local_address

definition anchor_formed :: "artifact_resolver ⇒ exact_anchor ⇒ bool" where
  "anchor_formed ρ a ⟷
     (case a of
        Whole_Artifact r ⇒ (∃R. resolves ρ r R)
      | Occurrence_Citation r x ⇒
          (∃R. resolves ρ r R ∧ x ∈ rra_carrier (object_structure R)))"

definition anchor_artifact ::
  "artifact_resolver ⇒ exact_anchor ⇒ exact_artifact" where
  "anchor_artifact ρ a =
     (case a of
        Whole_Artifact r ⇒ rel_value ρ r
      | Occurrence_Citation r x ⇒ rel_value ρ r)"

definition anchor_occurrence :: "exact_anchor ⇒ local_address option" where
  "anchor_occurrence a =
     (case a of Whole_Artifact r ⇒ None
      | Occurrence_Citation r x ⇒ Some x)"

section ‹Concrete local-address realizations›

fun unary_address :: "nat ⇒ local_address" where
  "unary_address n = replicate n 0 @ [1]"

lemma unary_address_formed:
  "octets_formed (unary_address n)"
  by (auto simp: octets_formed_def)

lemma unary_address_length:
  "length (unary_address n) = Suc n"
  by simp

lemma unary_address_inj:
  "inj unary_address"
proof (rule injI)
  fix m n
  assume "unary_address m = unary_address n"
  then have "length (unary_address m) = length (unary_address n)"
    by simp
  then show "m = n"
    by simp
qed

lemma unary_address_eq_iff [simp]:
  "unary_address m = unary_address n ⟷ m = n"
  using unary_address_inj by (auto simp: inj_def)

definition finite_addressing :: "'a set ⇒ ('a ⇒ local_address) ⇒ bool" where
  "finite_addressing U f ⟷
     inj_on f U ∧ (∀x ∈ U. octets_formed (f x))"

lemma finite_addressing_exists:
  assumes "finite U"
  shows "∃f. finite_addressing U f"
proof -
  obtain g :: "'a ⇒ nat" where g: "inj_on g U"
    using finite_imp_inj_to_nat[OF assms] by blast
  have i: "inj_on (unary_address ∘ g) U"
    using g unary_address_inj
    by (auto simp: inj_on_def inj_def)
  have o: "∀x ∈ U. octets_formed ((unary_address ∘ g) x)"
    using unary_address_formed by auto
  show ?thesis
    using i o by (auto simp: finite_addressing_def)
qed

definition exact_realization ::
  "('a ⇒ local_address) ⇒ ('a,octets) structured_object ⇒ exact_artifact ⇒ bool" where
  "exact_realization f O R ⟷
     object_formed O ∧ exact_formed R ∧
     finite_addressing (rra_carrier (object_structure O)) f ∧
     object_structure R = push_structure f (object_structure O) ∧
     object_data R = push_data f (object_data O)"

lemma exact_realization_structure_iso:
  assumes "exact_realization f O R"
  shows "rra_isomorphism f (object_structure O) (object_structure R)"
proof -
  from assms have inj: "inj_on f (rra_carrier (object_structure O))"
    and eq: "object_structure R = push_structure f (object_structure O)"
    by (auto simp: exact_realization_def finite_addressing_def)
  have "rra_isomorphism f (object_structure O)
          (push_structure f (object_structure O))"
    using push_structure_iso[OF inj] .
  with eq show ?thesis by simp
qed

text ‹
  The spelling of a local address belongs to exact artifact identity, but has no
  structural meaning.  Any semantic invariance under exact re-addressing must
  be established through the isomorphism just exposed, never by treating two
  exact artifacts as literally equal.
›

end
