theory RRA_Fragment
  imports RRA_Structural_Syntax
begin

section ‹Boundary-complete structural selection›

text ‹
  A fragment is not a copied subobject carrying a second source of truth.  It is
  an exact source artifact together with an exact selected carrier.  Its
  material, crossing boundary, and omitted remainder are derived projections.
›

record exact_fragment =
  fragment_source :: exact_artifact
  fragment_selection :: "local_address set"

definition fragment_formed :: "exact_fragment ⇒ bool" where
  "fragment_formed F ⟷
     exact_formed (fragment_source F) ∧
     finite (fragment_selection F) ∧
     fragment_selection F ⊆
       rra_carrier (object_structure (fragment_source F))"

definition fragment_material :: "exact_fragment ⇒ exact_artifact" where
  "fragment_material F =
     restrict_object (fragment_source F) (fragment_selection F)"

definition fragment_boundary ::
  "exact_fragment ⇒ (local_address × local_address × local_address) set" where
  "fragment_boundary F =
     crossing_incidence (object_structure (fragment_source F))
                        (fragment_selection F)"

definition fragment_omission :: "exact_fragment ⇒ local_address set" where
  "fragment_omission F =
     rra_carrier (object_structure (fragment_source F)) - fragment_selection F"

lemma fragment_material_formed:
  assumes "fragment_formed F"
  shows "exact_formed (fragment_material F)"
  using assms restrict_object_formed
  by (auto simp: fragment_formed_def fragment_material_def exact_formed_def
      restrict_object_def restrict_structure_def internal_incidence_def)

lemma fragment_incidence_partition:
  assumes "fragment_formed F"
  defines "S ≡ object_structure (fragment_source F)"
      and "A ≡ fragment_selection F"
  shows "rra_incidence S =
           internal_incidence S A ∪
           internal_incidence S (rra_carrier S - A) ∪
           crossing_incidence S A"
proof
  show "rra_incidence S ⊆
        internal_incidence S A ∪
        internal_incidence S (rra_carrier S - A) ∪
        crossing_incidence S A"
  proof
    fix t
    assume t: "t ∈ rra_incidence S"
    obtain r p x where teq: "t = (r,p,x)"
      by (cases t) auto
    from assms t teq have members:
      "r ∈ rra_carrier S" "p ∈ rra_carrier S" "x ∈ rra_carrier S"
      by (auto simp: fragment_formed_def exact_formed_def object_formed_def
          rra_formed_def S_def)
    show "t ∈ internal_incidence S A ∪
              internal_incidence S (rra_carrier S - A) ∪
              crossing_incidence S A"
      using t teq members
      by (auto simp: internal_incidence_def crossing_incidence_def
          touching_incidence_def)
  qed
  show "internal_incidence S A ∪
        internal_incidence S (rra_carrier S - A) ∪
        crossing_incidence S A ⊆ rra_incidence S"
    by (auto simp: internal_incidence_def crossing_incidence_def
        touching_incidence_def)
qed

lemma fragment_boundary_complete:
  "fragment_boundary F =
   touching_incidence (object_structure (fragment_source F))
                      (fragment_selection F) -
   rra_incidence (object_structure (fragment_material F))"
  by (auto simp: fragment_boundary_def fragment_material_def
      crossing_incidence_def restrict_object_def restrict_structure_def
      internal_incidence_def)

text ‹
  Nonselection is not destruction.  The source, selected material, exact
  crossing boundary, and omitted carrier are simultaneously recoverable from
  the one fragment witness.
›

end
