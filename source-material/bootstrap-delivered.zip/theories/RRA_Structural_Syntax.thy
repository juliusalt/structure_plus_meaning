theory RRA_Structural_Syntax
  imports RRA_Exact
begin

section ‹Incidence-only record geometry›

text ‹
  The following geometry gives finite records a recoverable field order without
  storing names, tags, ordinals, or a second successor relation.  A field
  participation is accompanied by an isolated incidence chain whose length is
  its structural rank.  All incidence touching that chain is accounted for.
›

fun code_edges :: "'a list ⇒ ('a × 'a × 'a) set" where
  "code_edges [] = {}"
| "code_edges [a] = {(a,a,a)}"
| "code_edges (a # b # xs) = insert (a,a,b) (code_edges (b # xs))"

definition field_code ::
  "'a rra_structure ⇒ 'a ⇒ 'a ⇒ 'a ⇒ nat ⇒ bool" where
  "field_code S r p x n ⟷
     (∃cs.
        length cs = Suc n ∧ hd cs = p ∧ distinct cs ∧
        r ∉ set cs ∧ x ∉ set cs ∧
        touching_incidence S (set cs) =
          insert (r,p,x) (code_edges cs))"

definition headed_incidence ::
  "'a rra_structure ⇒ 'a ⇒ ('a × 'a) set" where
  "headed_incidence S r = {(p,x). (r,p,x) ∈ rra_incidence S}"

definition raw_record_at ::
  "'a rra_structure ⇒ 'a ⇒ 'a list ⇒ bool" where
  "raw_record_at S r xs ⟷
     (∃ps.
        length ps = length xs ∧ distinct ps ∧
        (∀i < length xs. field_code S r (ps ! i) (xs ! i) i) ∧
        headed_incidence S r =
          {(ps ! i, xs ! i) |i. i < length xs})"

definition record_at ::
  "'a rra_structure ⇒ 'a ⇒ 'a list ⇒ bool" where
  "record_at S r xs ⟷
     raw_record_at S r xs ∧
     (∀ys. raw_record_at S r ys ⟶ ys = xs)"

definition record_root :: "'a rra_structure ⇒ 'a ⇒ bool" where
  "record_root S r ⟷ (∃xs. record_at S r xs)"

lemma record_at_unique:
  assumes "record_at S r xs" "record_at S r ys"
  shows "xs = ys"
  using assms by (auto simp: record_at_def)

section ‹Unordered structural families›

text ‹
  Families use indistinguishable member positions.  Their semantic projection is
  the exact endpoint set, so no enumeration order acquires force.
›

definition family_member_at ::
  "'a rra_structure ⇒ 'a ⇒ 'a ⇒ 'a ⇒ bool" where
  "family_member_at S r p x ⟷ field_code S r p x 0"

definition raw_family_at ::
  "'a rra_structure ⇒ 'a ⇒ 'a set ⇒ bool" where
  "raw_family_at S r X ⟷
     finite X ∧
     (∃P.
        finite P ∧
        (∀p ∈ P. ∃!x. x ∈ X ∧ family_member_at S r p x) ∧
        (∀x ∈ X. ∃!p. p ∈ P ∧ family_member_at S r p x) ∧
        headed_incidence S r =
          {(p,x). p ∈ P ∧ x ∈ X ∧ family_member_at S r p x})"

definition family_at ::
  "'a rra_structure ⇒ 'a ⇒ 'a set ⇒ bool" where
  "family_at S r X ⟷
     raw_family_at S r X ∧
     (∀Y. raw_family_at S r Y ⟶ Y = X)"

lemma family_at_unique:
  assumes "family_at S r X" "family_at S r Y"
  shows "X = Y"
  using assms by (auto simp: family_at_def)

section ‹Structurally recovered exact anchors›

fun functional_pairs ::
  "('a,'v) rra_data ⇒ ('a × 'v) set" where
  "functional_pairs (Functional_Data F) = F"
| "functional_pairs No_Data = {}"
| "functional_pairs (Bag_Data B) = {}"
| "functional_pairs (Node_Data N) = {}"

definition functional_payload ::
  "('a,'v) structured_object ⇒ 'a ⇒ 'v ⇒ bool" where
  "functional_payload O a v ⟷
     profile_kind (object_data O) = Functional_Profile ∧
     (a,v) ∈ functional_pairs (object_data O)"

definition raw_anchor_shape ::
  "exact_artifact ⇒ local_address ⇒ exact_anchor ⇒ bool" where
  "raw_anchor_shape E root a ⟷
     (case a of
        Whole_Artifact ref ⇒
          (∃rnode.
             record_at (object_structure E) root [rnode] ∧
             functional_payload E rnode ref)
      | Occurrence_Citation ref addr ⇒
          (∃rnode anode.
             record_at (object_structure E) root [rnode,anode] ∧
             functional_payload E rnode ref ∧
             functional_payload E anode addr))"

definition anchor_shape ::
  "exact_artifact ⇒ local_address ⇒ exact_anchor ⇒ bool" where
  "anchor_shape E root a ⟷
     exact_formed E ∧ raw_anchor_shape E root a ∧
     (∀b. raw_anchor_shape E root b ⟶ b = a)"

definition anchored_at ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒ exact_anchor ⇒ bool" where
  "anchored_at ρ E root a ⟷ anchor_shape E root a ∧ anchor_formed ρ a"

lemma anchor_shape_unique:
  assumes "anchor_shape E r a" "anchor_shape E r b"
  shows "a = b"
  using assms by (auto simp: anchor_shape_def)

lemma anchored_at_unique:
  assumes "anchored_at ρ E r a" "anchored_at ρ E r b"
  shows "a = b"
  using assms anchor_shape_unique by (auto simp: anchored_at_def)

section ‹Quotation geometry and irrelevance of representation choice›

record 's quotation_geometry =
  quote_value :: "'s ⇒ exact_artifact"
  read_value :: "exact_artifact ⇒ 's option"

definition faithful_geometry ::
  "'s set ⇒ 's quotation_geometry ⇒ bool" where
  "faithful_geometry A Q ⟷
     (∀x ∈ A.
        exact_formed (quote_value Q x) ∧
        read_value Q (quote_value Q x) = Some x) ∧
     (∀R x. read_value Q R = Some x ⟶ x ∈ A)"

definition requote ::
  "'s quotation_geometry ⇒ 's quotation_geometry ⇒ exact_artifact ⇒ exact_artifact" where
  "requote Q Q' R = quote_value Q' (the (read_value Q R))"

lemma faithful_requote:
  assumes "faithful_geometry A Q" "faithful_geometry A Q'" "x ∈ A"
  shows "requote Q Q' (quote_value Q x) = quote_value Q' x"
  using assms by (simp add: faithful_geometry_def requote_def)

lemma faithful_requote_round_trip:
  assumes "faithful_geometry A Q" "faithful_geometry A Q'" "x ∈ A"
  shows "requote Q' Q (requote Q Q' (quote_value Q x)) = quote_value Q x"
  using assms by (simp add: faithful_requote)

lemma faithful_behavior_transport:
  assumes "faithful_geometry A Q" "faithful_geometry A Q'" "x ∈ A"
  shows "P (the (read_value Q (quote_value Q x))) ⟷
         P (the (read_value Q' (requote Q Q' (quote_value Q x))))"
  using assms by (simp add: faithful_geometry_def faithful_requote)

text ‹
  Reflexive quotation needs no extra representational layer: an exact RRA
  artifact quotes itself.  Any alternative faithful geometry can be transported
  through its structural reader, and the preceding lemmas show that every
  behavior depending only on the recovered value is invariant under transport.
›

definition reflexive_geometry :: "exact_artifact quotation_geometry" where
  "reflexive_geometry =
     ⦇ quote_value = id,
       read_value = (λR. if exact_formed R then Some R else None) ⦈"

lemma reflexive_geometry_faithful:
  "faithful_geometry {R. exact_formed R} reflexive_geometry"
  by (auto simp: faithful_geometry_def reflexive_geometry_def)

end
