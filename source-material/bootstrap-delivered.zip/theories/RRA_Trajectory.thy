theory RRA_Trajectory
  imports RRA_Evidence
begin

section ‹Immutable structurally recovered generations›

record generation_projection =
  generation_locus :: exact_anchor
  generation_predecessors :: "exact_anchor set"
  generation_payload :: exact_anchor
  generation_dependencies :: "exact_anchor set"
  generation_evidence :: "exact_anchor set"

definition anchor_family_at ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒ exact_anchor set ⇒ bool" where
  "anchor_family_at ρ E root A ⟷
     (∃R.
        family_at (object_structure E) root R ∧
        (∀r ∈ R. ∃!a. anchored_at ρ E r a) ∧
        A = {a. ∃r ∈ R. anchored_at ρ E r a})"

definition raw_generation_at ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒
   generation_projection ⇒ bool" where
  "raw_generation_at ρ E g G ⟷
     (∃lr pr yr dr er.
        record_at (object_structure E) g [lr,pr,yr,dr,er] ∧
        anchored_at ρ E lr (generation_locus G) ∧
        anchor_family_at ρ E pr (generation_predecessors G) ∧
        anchored_at ρ E yr (generation_payload G) ∧
        anchor_family_at ρ E dr (generation_dependencies G) ∧
        anchor_family_at ρ E er (generation_evidence G))"

definition generation_at ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒
   generation_projection ⇒ bool" where
  "generation_at ρ E g G ⟷
     raw_generation_at ρ E g G ∧
     (∀H. raw_generation_at ρ E g H ⟶ H = G)"

lemma generation_at_unique:
  assumes "generation_at ρ E g G" "generation_at ρ E g H"
  shows "G = H"
  using assms by (auto simp: generation_at_def)

record trajectory =
  trajectory_reference :: artifact_reference
  trajectory_root :: local_address

definition trajectory_artifact ::
  "artifact_resolver ⇒ trajectory ⇒ exact_artifact" where
  "trajectory_artifact ρ T = rel_value ρ (trajectory_reference T)"

definition raw_trajectory_roots ::
  "artifact_resolver ⇒ trajectory ⇒ local_address set ⇒ bool" where
  "raw_trajectory_roots ρ T G ⟷
     resolves ρ (trajectory_reference T) (trajectory_artifact ρ T) ∧
     family_at (object_structure (trajectory_artifact ρ T))
               (trajectory_root T) G"

definition trajectory_generation_roots ::
  "artifact_resolver ⇒ trajectory ⇒ local_address set" where
  "trajectory_generation_roots ρ T =
     (THE G. raw_trajectory_roots ρ T G)"

definition generation_identity ::
  "trajectory ⇒ local_address ⇒ exact_anchor" where
  "generation_identity T g =
     Occurrence_Citation (trajectory_reference T) g"

definition trajectory_predecessor_edges ::
  "artifact_resolver ⇒ trajectory ⇒ (exact_anchor × exact_anchor) set" where
  "trajectory_predecessor_edges ρ T =
     {(p,generation_identity T g) |p g G.
        g ∈ trajectory_generation_roots ρ T ∧
        generation_at ρ (trajectory_artifact ρ T) g G ∧
        p ∈ generation_predecessors G}"

definition trajectory_formed ::
  "artifact_resolver ⇒ trajectory ⇒ bool" where
  "trajectory_formed ρ T ⟷
     resolver_formed ρ ∧
     resolves ρ (trajectory_reference T) (trajectory_artifact ρ T) ∧
     exact_formed (trajectory_artifact ρ T) ∧
     rooted_complete (object_structure (trajectory_artifact ρ T))
                     (trajectory_root T) ∧
     (∃!G. raw_trajectory_roots ρ T G) ∧
     (∀g ∈ trajectory_generation_roots ρ T.
        ∃!G. generation_at ρ (trajectory_artifact ρ T) g G) ∧
     acyclic_edges (trajectory_predecessor_edges ρ T)"

lemma trajectory_generation_identity_is_citation:
  "generation_identity T g =
   Occurrence_Citation (trajectory_reference T) g"
  by (simp add: generation_identity_def)

lemma trajectory_has_no_stored_transitive_ancestry:
  "strict_ancestor (trajectory_predecessor_edges ρ T) a b ⟷
   (a,b) ∈ (trajectory_predecessor_edges ρ T)⁺"
  by (simp add: strict_ancestor_def)

section ‹Exact publications›

record publication_projection =
  publication_selections :: "(exact_anchor × exact_anchor) set"
  publication_dependencies :: "exact_anchor set"
  publication_evidence :: "exact_anchor set"

record publication =
  publication_reference :: artifact_reference
  publication_root :: local_address

definition publication_artifact ::
  "artifact_resolver ⇒ publication ⇒ exact_artifact" where
  "publication_artifact ρ P = rel_value ρ (publication_reference P)"

definition selection_at ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒
   exact_anchor ⇒ exact_anchor ⇒ bool" where
  "selection_at ρ E s locus generation ⟷
     (∃lr gr.
        record_at (object_structure E) s [lr,gr] ∧
        anchored_at ρ E lr locus ∧
        anchored_at ρ E gr generation)"

definition selection_family_at ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒
   (exact_anchor × exact_anchor) set ⇒ bool" where
  "selection_family_at ρ E root S ⟷
     (∃R.
        family_at (object_structure E) root R ∧
        (∀r ∈ R. ∃!lg. selection_at ρ E r (fst lg) (snd lg)) ∧
        S = {(l,g). ∃r ∈ R. selection_at ρ E r l g})"

definition raw_publication_at ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒
   publication_projection ⇒ bool" where
  "raw_publication_at ρ E p P ⟷
     (∃sr dr er.
        record_at (object_structure E) p [sr,dr,er] ∧
        selection_family_at ρ E sr (publication_selections P) ∧
        anchor_family_at ρ E dr (publication_dependencies P) ∧
        anchor_family_at ρ E er (publication_evidence P))"

definition publication_at ::
  "artifact_resolver ⇒ exact_artifact ⇒ local_address ⇒
   publication_projection ⇒ bool" where
  "publication_at ρ E p P ⟷
     raw_publication_at ρ E p P ∧
     (∀Q. raw_publication_at ρ E p Q ⟶ Q = P)"

definition publication_formed ::
  "artifact_resolver ⇒ publication ⇒ bool" where
  "publication_formed ρ P ⟷
     resolver_formed ρ ∧
     resolves ρ (publication_reference P) (publication_artifact ρ P) ∧
     exact_formed (publication_artifact ρ P) ∧
     rooted_complete (object_structure (publication_artifact ρ P))
                     (publication_root P) ∧
     (∃!Q. publication_at ρ (publication_artifact ρ P)
                               (publication_root P) Q)"

lemma publication_projection_unique:
  assumes "publication_at ρ E p P" "publication_at ρ E p Q"
  shows "P = Q"
  using assms by (auto simp: publication_at_def)

text ‹
  No current-generation function and no mutation operation is defined.  A
  publication is an immutable structural selection.  Whether any authority
  recognizes a selection as current is a later Factor judgment relative to an
  exact foundation and exact authority frame.
›

definition projected_publication ::
  "artifact_resolver ⇒ publication ⇒ publication_projection" where
  "projected_publication ρ P =
     (THE Q. publication_at ρ (publication_artifact ρ P)
                              (publication_root P) Q)"

end
