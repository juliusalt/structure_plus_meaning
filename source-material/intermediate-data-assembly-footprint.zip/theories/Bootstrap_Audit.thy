theory Bootstrap_Audit
  imports Foundation_Genesis
begin

section \<open>Machine-visible constitutional consequences\<close>

lemma audit_reference_never_rebinds:
  assumes "resolver_formed \<rho>" "resolves \<rho> r R" "resolves \<rho> r R'"
  shows "R = R'"
  using assms resolver_non_rebinding by blast

lemma audit_factor_requires_exact_structure:
  assumes "factor_holds \<rho> \<Phi> j"
  shows "factor_foundation_formed \<rho> \<Phi> \<and> formed_factor_judgment \<rho> j"
  using assms factor_holds_is_structurally_grounded by blast

lemma audit_construction_has_one_origin_graph:
  assumes "factor_constructs \<rho> \<Phi> j W"
  shows "K2 W \<and> single_valued (assembly_origin W)"
  using assms factor_constructs_has_one_K2_account K2_origin_is_single_valued
  by blast

lemma audit_no_output_occurrence_without_origin:
  assumes "factor_constructs \<rho> \<Phi> j W"
      and "a \<in> rra_carrier (object_structure (assembly_output W))"
  shows "\<exists>c \<in> copied_carrier (assembly_pieces W).
           (c,a) \<in> assembly_origin W"
  using assms factor_constructs_no_unexplained_output by blast

lemma audit_evidence_formation_is_only_formation:
  assumes "evidence_envelope_formed \<rho> E"
  shows "exact_formed (evidence_artifact \<rho> E)"
  using assms evidence_envelope_exact by blast

lemma audit_certification_keeps_questions_distinct:
  assumes "factor_certifies \<rho> \<Phi> E j D W"
  shows "evidence_envelope_formed \<rho> E \<and>
         factor_derives \<rho> \<Phi> D j \<and>
         factor_constructs \<rho> \<Phi> j W \<and>
         K2 W"
  using assms factor_certifies_sound
  by (auto simp: factor_certifies_def)

lemma audit_currentness_has_no_ambient_form:
  assumes "factor_current \<rho> \<Phi> d j A P l g purpose"
  shows "publication_formed \<rho> P \<and>
         (l,g) \<in> publication_selections (projected_publication \<rho> P) \<and>
         factor_holds \<rho> \<Phi> j"
  using assms by (simp add: factor_current_def)

lemma audit_advancement_is_not_mutation:
  assumes "factor_advances \<rho> \<Phi> T g j D E W"
  shows "trajectory_formed \<rho> T \<and>
         factor_certifies \<rho> \<Phi> E j D W \<and> K2 W"
  using assms factor_advances_is_certified_construction[OF assms]
  by (auto simp: factor_advances_def generation_in_trajectory_def)

lemma audit_quotation_choice_is_behaviorally_irrelevant:
  assumes "faithful_geometry A Q" "faithful_geometry A Q'"
  shows "behaviorally_equivalent_geometries A Q Q'"
  using assms all_faithful_geometries_behaviorally_equivalent by blast

lemma audit_reflection_is_external_internal_agreement:
  assumes "reflection_valid \<rho> X B" "j \<in> reflection_domain X"
  shows "j \<in> external_truth X \<longleftrightarrow> factor_holds \<rho> (reflected_foundation B) j"
  using assms reflection_handoff by blast

lemma audit_complete_genesis_has_no_unstated_computation_layer:
  assumes "complete_genesis \<rho> X G"
  shows "genesis_formed \<rho> X G \<and>
         (\<exists>program. sk_program_complete \<rho> (genesis_foundation G) program)"
  using assms
  by (auto simp: complete_genesis_def bootstrap_computationally_sufficient_def)

text \<open>
  The theory graph contains no semantic transition system over mutable machine
  states, no effect datatype, no ambient current-head map, no second Factor
  carrier, and no second construction-origin relation.  These absences are also
  checked textually by the nonnormative delivery audit; the lemmas above expose
  the positive mathematical boundaries on which that audit relies.
\<close>

end
