theory Factor_Authority
  imports Factor_Semantics RRA_Trajectory
begin

section \<open>Exact authority applications\<close>

definition factor_application_exact ::
  "artifact_resolver \<Rightarrow> exact_anchor \<Rightarrow> exact_anchor \<Rightarrow> exact_anchor list \<Rightarrow> bool" where
  "factor_application_exact \<rho> j definition arguments \<longleftrightarrow>
     (\<exists>J. factor_judgment_at \<rho> j J \<and>
          judgment_definition J = definition \<and>
          judgment_arguments J = arguments)"

definition factor_adopts ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow>
   exact_anchor \<Rightarrow> exact_anchor \<Rightarrow> exact_anchor \<Rightarrow> exact_anchor \<Rightarrow>
   exact_anchor \<Rightarrow> exact_anchor \<Rightarrow> bool" where
  "factor_adopts \<rho> \<Phi> adoption_definition judgment authority subject purpose basis \<longleftrightarrow>
     factor_application_exact \<rho> judgment adoption_definition
       [authority,subject,purpose,basis] \<and>
     factor_holds \<rho> \<Phi> judgment"

text \<open>
  Adoption is an exact Factor judgment.  It neither proves its subject nor
  changes the subject's structure.  Different authority, purpose, basis, or
  foundation arguments produce different judgments.
\<close>

section \<open>Publication-relative currentness\<close>

definition publication_anchor :: "publication \<Rightarrow> exact_anchor" where
  "publication_anchor P =
     Occurrence_Citation (publication_reference P) (publication_root P)"

definition factor_current ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> exact_anchor \<Rightarrow> exact_anchor \<Rightarrow>
   exact_anchor \<Rightarrow> publication \<Rightarrow> exact_anchor \<Rightarrow> exact_anchor \<Rightarrow> exact_anchor \<Rightarrow> bool" where
  "factor_current \<rho> \<Phi> current_definition judgment authority P locus generation purpose \<longleftrightarrow>
     publication_formed \<rho> P \<and>
     (locus,generation) \<in>
       publication_selections (projected_publication \<rho> P) \<and>
     factor_application_exact \<rho> judgment current_definition
       [authority,publication_anchor P,locus,generation,purpose] \<and>
     factor_holds \<rho> \<Phi> judgment"

lemma factor_current_has_exact_publication:
  assumes "factor_current \<rho> \<Phi> d j A P l g purpose"
  shows "publication_formed \<rho> P \<and>
         (l,g) \<in> publication_selections (projected_publication \<rho> P)"
  using assms by (simp add: factor_current_def)

text \<open>
  There is intentionally no unqualified current predicate.  Removing any of
  foundation, authority, publication, locus, generation, or purpose changes the
  question rather than abbreviating it.
\<close>

end
