theory Factor_Continuation
  imports Factor_Evidence RRA_Trajectory
begin

section \<open>Certified immutable advancement\<close>

definition generation_in_trajectory ::
  "artifact_resolver \<Rightarrow> trajectory \<Rightarrow> local_address \<Rightarrow>
   generation_projection \<Rightarrow> bool" where
  "generation_in_trajectory \<rho> T g G \<longleftrightarrow>
     trajectory_formed \<rho> T \<and>
     g \<in> trajectory_generation_roots \<rho> T \<and>
     generation_at \<rho> (trajectory_artifact \<rho> T) g G"

definition factor_advances ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> trajectory \<Rightarrow> local_address \<Rightarrow>
   exact_anchor \<Rightarrow> factor_derivation \<Rightarrow> evidence_envelope \<Rightarrow>
   local_address assembly_witness \<Rightarrow> bool" where
  "factor_advances \<rho> \<Phi> T g' j D E W \<longleftrightarrow>
     (\<exists>G C out_ref.
        generation_in_trajectory \<rho> T g' G \<and>
        factor_construction_at \<rho> j C \<and>
        factor_certifies \<rho> \<Phi> E j D W \<and>
        generation_payload G = Whole_Artifact out_ref \<and>
        resolves \<rho> out_ref (assembly_output W) \<and>
        generation_predecessors G \<union> generation_dependencies G =
          set (construction_inputs C) \<and>
        evidence_envelope_anchor E \<in> generation_evidence G)"

lemma factor_advances_is_certified_construction:
  assumes "factor_advances \<rho> \<Phi> T g j D E W"
  shows "factor_certifies \<rho> \<Phi> E j D W \<and> K2 W"
  using assms factor_certifies_sound
  by (auto simp: factor_advances_def)

lemma factor_advances_payload_is_output:
  assumes "factor_advances \<rho> \<Phi> T g j D E W"
  shows "\<exists>G out_ref.
           generation_in_trajectory \<rho> T g G \<and>
           generation_payload G = Whole_Artifact out_ref \<and>
           resolves \<rho> out_ref (assembly_output W)"
  using assms by (auto simp: factor_advances_def)

text \<open>
  Advancement relates immutable structures.  Branches are multiple generations
  with a common predecessor; a merge is a later certified construction whose
  predecessor set contains the merged generations.  No transaction, lock,
  compare-and-swap, clock, or mutable head belongs to this semantics.
\<close>

end
