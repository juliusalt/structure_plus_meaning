theory Factor_Derivation
  imports Factor_Semantics
begin

section \<open>Structurally retained finite derivations\<close>

record factor_derivation =
  derivation_reference :: artifact_reference
  derivation_root :: local_address

definition factor_derivation_artifact ::
  "artifact_resolver \<Rightarrow> factor_derivation \<Rightarrow> exact_artifact" where
  "factor_derivation_artifact \<rho> D = rel_value \<rho> (derivation_reference D)"

definition seed_node_shape ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow> exact_anchor \<Rightarrow> bool" where
  "seed_node_shape \<rho> E n j \<longleftrightarrow>
     (\<exists>jr. record_at (object_structure E) n [jr] \<and> anchored_at \<rho> E jr j)"

definition primitive_node_shape ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow>
   exact_anchor \<Rightarrow> exact_anchor \<Rightarrow> bool" where
  "primitive_node_shape \<rho> E n j d \<longleftrightarrow>
     (\<exists>jr dr.
        record_at (object_structure E) n [jr,dr] \<and>
        anchored_at \<rho> E jr j \<and> anchored_at \<rho> E dr d)"

definition consequence_node_shape ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow>
   exact_anchor \<Rightarrow> exact_anchor \<Rightarrow> local_address set \<Rightarrow> bool" where
  "consequence_node_shape \<rho> E n j c N \<longleftrightarrow>
     (\<exists>jr cr pr.
        record_at (object_structure E) n [jr,cr,pr] \<and>
        anchored_at \<rho> E jr j \<and>
        anchored_at \<rho> E cr c \<and>
        family_at (object_structure E) pr N)"

definition derivation_node_conclusion ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow> exact_anchor \<Rightarrow> bool" where
  "derivation_node_conclusion \<rho> E n j \<longleftrightarrow>
     (seed_node_shape \<rho> E n j \<or>
      (\<exists>d. primitive_node_shape \<rho> E n j d) \<or>
      (\<exists>c N. consequence_node_shape \<rho> E n j c N)) \<and>
     (\<forall>k.
       (seed_node_shape \<rho> E n k \<or>
        (\<exists>d. primitive_node_shape \<rho> E n k d) \<or>
        (\<exists>c N. consequence_node_shape \<rho> E n k c N)) \<longrightarrow> k = j)"

inductive derivation_shape_node ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow> bool"
  for \<rho> E
where
  shape_seed:
    "seed_node_shape \<rho> E n j \<Longrightarrow> derivation_shape_node \<rho> E n"
| shape_primitive:
    "primitive_node_shape \<rho> E n j d \<Longrightarrow> derivation_shape_node \<rho> E n"
| shape_consequence:
    "consequence_node_shape \<rho> E n j c N \<Longrightarrow>
     (\<And>m. m \<in> N \<Longrightarrow> derivation_shape_node \<rho> E m) \<Longrightarrow>
     derivation_shape_node \<rho> E n"

definition factor_derivation_formed ::
  "artifact_resolver \<Rightarrow> factor_derivation \<Rightarrow> bool" where
  "factor_derivation_formed \<rho> D \<longleftrightarrow>
     resolver_formed \<rho> \<and>
     resolves \<rho> (derivation_reference D) (factor_derivation_artifact \<rho> D) \<and>
     exact_formed (factor_derivation_artifact \<rho> D) \<and>
     rooted_connected (object_structure (factor_derivation_artifact \<rho> D))
                     (derivation_root D) \<and>
     derivation_shape_node \<rho> (factor_derivation_artifact \<rho> D)
                           (derivation_root D)"

section \<open>Clause citations\<close>

definition foundation_clause_citation ::
  "factor_foundation \<Rightarrow> local_address \<Rightarrow> exact_anchor" where
  "foundation_clause_citation \<Phi> c =
     Occurrence_Citation (foundation_reference \<Phi>) c"

definition foundation_clause_at_anchor ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> exact_anchor \<Rightarrow>
   factor_clause_projection \<Rightarrow> bool" where
  "foundation_clause_at_anchor \<rho> \<Phi> a C \<longleftrightarrow>
     (\<exists>c.
        a = foundation_clause_citation \<Phi> c \<and>
        factor_clause_at \<rho> (factor_foundation_artifact \<rho> \<Phi>) c C \<and>
        C \<in> foundation_clauses (projected_foundation \<rho> \<Phi>))"

section \<open>Validity follows the retained tree\<close>

inductive derives_node ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> exact_artifact \<Rightarrow>
   local_address \<Rightarrow> exact_anchor \<Rightarrow> bool"
  for \<rho> \<Phi> E
where
  derives_seed:
    "factor_foundation_formed \<rho> \<Phi> \<Longrightarrow>
     seed_node_shape \<rho> E n j \<Longrightarrow>
     formed_factor_judgment \<rho> j \<Longrightarrow>
     j \<in> foundation_seeds (projected_foundation \<rho> \<Phi>) \<Longrightarrow>
     derives_node \<rho> \<Phi> E n j"
| derives_primitive:
    "factor_foundation_formed \<rho> \<Phi> \<Longrightarrow>
     primitive_node_shape \<rho> E n j d \<Longrightarrow>
     formed_factor_judgment \<rho> j \<Longrightarrow>
     d = judgment_definition (projected_judgment \<rho> j) \<Longrightarrow>
     combinator_construction_holds \<rho> \<Phi> j \<Longrightarrow>
     derives_node \<rho> \<Phi> E n j"
| derives_consequence:
    "factor_foundation_formed \<rho> \<Phi> \<Longrightarrow>
     consequence_node_shape \<rho> E n j ca N \<Longrightarrow>
     foundation_clause_at_anchor \<rho> \<Phi> ca C \<Longrightarrow>
     clause_conclusion C = j \<Longrightarrow>
     formed_factor_judgment \<rho> j \<Longrightarrow>
     (\<And>m. m \<in> N \<Longrightarrow> \<exists>k. derivation_node_conclusion \<rho> E m k \<and>
                           derives_node \<rho> \<Phi> E m k) \<Longrightarrow>
     {k. \<exists>m \<in> N. derivation_node_conclusion \<rho> E m k} =
       clause_premises C \<Longrightarrow>
     (\<forall>k \<in> clause_premises C.
        \<exists>!m. m \<in> N \<and> derivation_node_conclusion \<rho> E m k) \<Longrightarrow>
     derives_node \<rho> \<Phi> E n j"

definition factor_derives ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> factor_derivation \<Rightarrow>
   exact_anchor \<Rightarrow> bool" where
  "factor_derives \<rho> \<Phi> D j \<longleftrightarrow>
     factor_derivation_formed \<rho> D \<and>
     derives_node \<rho> \<Phi> (factor_derivation_artifact \<rho> D)
                       (derivation_root D) j"

lemma derivation_node_conclusion_unique:
  assumes "derivation_node_conclusion \<rho> E n j" "derivation_node_conclusion \<rho> E n k"
  shows "j = k"
  using assms by (auto simp: derivation_node_conclusion_def)

lemma derives_node_sound:
  assumes "derives_node \<rho> \<Phi> E n j"
  shows "factor_holds \<rho> \<Phi> j"
  using assms
proof (induction rule: derives_node.induct)
  case (derives_seed n j)
  then show ?case by (auto simp: factor_holds_def)
next
  case (derives_primitive n j d)
  then show ?case by (auto simp: factor_holds_def)
next
  case (derives_consequence n j ca N C)
  let ?Cs = "foundation_clauses (projected_foundation \<rho> \<Phi>)"
  let ?Ss = "foundation_seeds (projected_foundation \<rho> \<Phi>) \<union>
    {k. combinator_construction_holds \<rho> \<Phi> k}"
  have cin: "C \<in> ?Cs"
    using derives_consequence.hyps by (auto simp: foundation_clause_at_anchor_def)
  have psound: "\<And>k. k \<in> clause_premises C \<Longrightarrow> k \<in> factor_closure ?Cs ?Ss"
  proof -
    fix k assume "k \<in> clause_premises C"
    then obtain m where min: "m \<in> N" and mk: "derivation_node_conclusion \<rho> E m k"
      using derives_consequence.hyps(7) by blast
    from derives_consequence.IH[OF min] obtain k' where
      mk': "derivation_node_conclusion \<rho> E m k'" and hk': "factor_holds \<rho> \<Phi> k'"
      by blast
    have "k' = k" by (rule derivation_node_conclusion_unique[OF mk' mk])
    with hk' show "k \<in> factor_closure ?Cs ?Ss" by (simp add: factor_holds_def)
  qed
  have "clause_conclusion C \<in> factor_closure ?Cs ?Ss"
    by (rule factor_closure.consequence[OF cin psound])
  with derives_consequence.hyps show ?case by (auto simp: factor_holds_def)
qed

lemma factor_derives_sound:
  assumes "factor_derives \<rho> \<Phi> D j"
  shows "factor_holds \<rho> \<Phi> j"
  using assms derives_node_sound
  by (auto simp: factor_derives_def)

text \<open>
  A derivation is evidence for an already meaningful judgment.  Seed,
  structural primitive, and clause-consequence nodes have disjoint arities.
  Every premise occurrence remains explicit and no layout node creates a
  semantic fact.
\<close>

end
