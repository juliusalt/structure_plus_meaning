theory Foundation_Reflection
  imports Factor_Authority Factor_Evidence
begin

section \<open>Behavioral irrelevance of faithful quotation geometry\<close>

text \<open>
  A quotation geometry is admissible only through its structural reader.  The
  behavior of quoted Factor material is therefore the behavior of the uniquely
  recovered value, never the spelling or scaffolding chosen by the geometry.
\<close>

definition recovered_behavior ::
  "'a quotation_geometry \<Rightarrow> ('a \<Rightarrow> bool) \<Rightarrow> exact_artifact \<Rightarrow> bool" where
  "recovered_behavior Q B R \<longleftrightarrow>
     (\<exists>x. read_value Q R = Some x \<and> B x)"

definition behaviorally_equivalent_geometries ::
  "'a set \<Rightarrow> 'a quotation_geometry \<Rightarrow> 'a quotation_geometry \<Rightarrow> bool" where
  "behaviorally_equivalent_geometries A Q Q' \<longleftrightarrow>
     faithful_geometry A Q \<and> faithful_geometry A Q' \<and>
     (\<forall>B x. x \<in> A \<longrightarrow>
        recovered_behavior Q B (quote_value Q x) =
        recovered_behavior Q' B (quote_value Q' x))"

lemma all_faithful_geometries_behaviorally_equivalent:
  assumes "faithful_geometry A Q" "faithful_geometry A Q'"
  shows "behaviorally_equivalent_geometries A Q Q'"
  using assms
  by (auto simp: behaviorally_equivalent_geometries_def
      recovered_behavior_def faithful_geometry_def)

lemma quotation_transport_preserves_factor_reasoning:
  assumes faithful: "faithful_geometry A Q" "faithful_geometry A Q'"
      and xin: "x \<in> A"
  shows "recovered_behavior Q B (quote_value Q x) \<longleftrightarrow>
         recovered_behavior Q' B (requote Q Q' (quote_value Q x))"
  using faithful xin
  by (auto simp: recovered_behavior_def faithful_geometry_def faithful_requote)

text \<open>
  The theorem quantifies over every behavior of the recovered object, including
  Factor closure, construction, derivation, replay, and authority predicates.
  Hence a faithful alternative topology can always be requoted into another
  without changing any such behavior.  The irredundant representative is the
  reflexive geometry: an exact RRA artifact quotes itself.
\<close>

definition bootstrap_quotation_geometry ::
  "exact_artifact quotation_geometry" where
  "bootstrap_quotation_geometry = reflexive_geometry"

lemma bootstrap_quotation_is_faithful:
  "faithful_geometry {R. exact_formed R} bootstrap_quotation_geometry"
  by (simp add: bootstrap_quotation_geometry_def reflexive_geometry_faithful)

section \<open>External-to-internal adequacy\<close>

record reflection_specification =
  reflection_domain :: "exact_anchor set"
  external_truth :: "exact_anchor set"

record reflection_bundle =
  reflected_foundation :: factor_foundation
  reflection_evidence :: evidence_envelope

definition reflected_definitions ::
  "artifact_resolver \<Rightarrow> reflection_specification \<Rightarrow> exact_anchor set" where
  "reflected_definitions \<rho> X =
     {d. \<exists>j \<in> reflection_domain X.
        \<exists>J. factor_judgment_at \<rho> j J \<and> d = judgment_definition J}"

definition reflection_specification_formed ::
  "artifact_resolver \<Rightarrow> reflection_specification \<Rightarrow> bool" where
  "reflection_specification_formed \<rho> X \<longleftrightarrow>
     external_truth X \<subseteq> reflection_domain X \<and>
     (\<forall>j \<in> reflection_domain X. formed_factor_judgment \<rho> j) \<and>
     finite (reflected_definitions \<rho> X)"

definition reflection_links ::
  "artifact_resolver \<Rightarrow> factor_foundation \<Rightarrow> reflection_specification \<Rightarrow>
   (exact_anchor \<times> exact_anchor) set" where
  "reflection_links \<rho> \<Phi> X =
     {(d,factor_foundation_anchor \<Phi>) |d.
        d \<in> reflected_definitions \<rho> X}"

definition reflection_valid ::
  "artifact_resolver \<Rightarrow> reflection_specification \<Rightarrow> reflection_bundle \<Rightarrow> bool" where
  "reflection_valid \<rho> X B \<longleftrightarrow>
     reflection_specification_formed \<rho> X \<and>
     factor_foundation_formed \<rho> (reflected_foundation B) \<and>
     evidence_envelope_formed \<rho> (reflection_evidence B) \<and>
     reflection_links \<rho> (reflected_foundation B) X
       \<subseteq> envelope_links \<rho> (reflection_evidence B) \<and>
     (\<forall>j \<in> reflection_domain X.
        (j \<in> external_truth X) \<longleftrightarrow>
        factor_holds \<rho> (reflected_foundation B) j)"

lemma reflection_handoff:
  assumes "reflection_valid \<rho> X B" "j \<in> reflection_domain X"
  shows "j \<in> external_truth X \<longleftrightarrow> factor_holds \<rho> (reflected_foundation B) j"
  using assms by (simp add: reflection_valid_def)

lemma reflection_does_not_self_authorize:
  assumes "reflection_valid \<rho> X B"
  shows "factor_foundation_formed \<rho> (reflected_foundation B) \<and>
         evidence_envelope_formed \<rho> (reflection_evidence B)"
  using assms by (simp add: reflection_valid_def)

text \<open>
  reflection_domain may contain every formed finite application of the bootstrap
  definitions.  Only the finite set of definition roots must be linked in the
  exact handoff evidence.  external_truth is an Isabelle/HOL bootstrap argument,
  not an internal truth bit stored in the foundation artifact.  It disappears
  from ordinary use after the handoff theorem establishes agreement on the
  complete declared domain.  The evidence records that handoff; it does not
  prove itself.
\<close>

end
