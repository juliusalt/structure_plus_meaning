theory RRA_Evidence
  imports RRA_Structural_Syntax
begin

section \<open>Semantically inert exact envelopes\<close>

record evidence_envelope =
  envelope_reference :: artifact_reference
  envelope_root :: local_address

definition evidence_artifact ::
  "artifact_resolver \<Rightarrow> evidence_envelope \<Rightarrow> exact_artifact" where
  "evidence_artifact \<rho> E = rel_value \<rho> (envelope_reference E)"

definition envelope_link_at ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow>
   exact_anchor \<Rightarrow> exact_anchor \<Rightarrow> bool" where
  "envelope_link_at \<rho> E l a b \<longleftrightarrow>
     (\<exists>ar br.
        record_at (object_structure E) l [ar,br] \<and>
        anchored_at \<rho> E ar a \<and>
        anchored_at \<rho> E br b)"

definition raw_envelope_projection ::
  "artifact_resolver \<Rightarrow> evidence_envelope \<Rightarrow>
   local_address set \<Rightarrow> bool" where
  "raw_envelope_projection \<rho> E L \<longleftrightarrow>
     resolves \<rho> (envelope_reference E) (evidence_artifact \<rho> E) \<and>
     exact_formed (evidence_artifact \<rho> E) \<and>
     rooted_connected (object_structure (evidence_artifact \<rho> E))
                     (envelope_root E) \<and>
     family_at (object_structure (evidence_artifact \<rho> E))
               (envelope_root E) L \<and>
     (\<forall>l \<in> L. \<exists>!ab. envelope_link_at \<rho> (evidence_artifact \<rho> E) l
                                      (fst ab) (snd ab))"

definition evidence_envelope_formed ::
  "artifact_resolver \<Rightarrow> evidence_envelope \<Rightarrow> bool" where
  "evidence_envelope_formed \<rho> E \<longleftrightarrow>
     resolver_formed \<rho> \<and>
     (\<exists>!L. raw_envelope_projection \<rho> E L)"

definition envelope_link_roots ::
  "artifact_resolver \<Rightarrow> evidence_envelope \<Rightarrow> local_address set" where
  "envelope_link_roots \<rho> E =
     (THE L. raw_envelope_projection \<rho> E L)"

definition envelope_links ::
  "artifact_resolver \<Rightarrow> evidence_envelope \<Rightarrow>
   (exact_anchor \<times> exact_anchor) set" where
  "envelope_links \<rho> E =
     {(a,b). \<exists>l \<in> envelope_link_roots \<rho> E.
        envelope_link_at \<rho> (evidence_artifact \<rho> E) l a b}"

definition evidence_envelope_anchor ::
  "evidence_envelope \<Rightarrow> exact_anchor" where
  "evidence_envelope_anchor E =
     Occurrence_Citation (envelope_reference E) (envelope_root E)"

lemma evidence_envelope_exact:
  assumes "evidence_envelope_formed \<rho> E"
  shows "exact_formed (evidence_artifact \<rho> E)"
proof -
  from assms obtain L where "raw_envelope_projection \<rho> E L"
    by (auto simp: evidence_envelope_formed_def)
  then show ?thesis
    by (simp add: raw_envelope_projection_def)
qed

text \<open>
  This theory assigns no evidential role to either endpoint of a link.  It does
  not distinguish claims, premises, results, checkers, provenance, trust, or
  residuals.  Those are Factor-recognized structural patterns over this one
  envelope substrate.  Formation alone has no truth, proof, or authority
  consequence.
\<close>

end
