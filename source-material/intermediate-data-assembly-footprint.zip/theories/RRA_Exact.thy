theory RRA_Exact
  imports RRA_Footprint
begin

section \<open>Exact addressed artifacts\<close>

type_synonym local_address = octets
type_synonym exact_artifact = "(local_address,octets) structured_object"
type_synonym artifact_reference = octets

lemma basis_values_restrictD:
  assumes "v \<in> basis_values (restrict_basis A D)"
  shows "v \<in> basis_values D"
  using assms basis_values_restrict[of A D] by blast

definition exact_formed :: "exact_artifact \<Rightarrow> bool" where
  "exact_formed R \<longleftrightarrow>
     object_formed R \<and>
     (\<forall>a \<in> rra_carrier (object_structure R). octets_formed a) \<and>
     (\<forall>v \<in> basis_values (object_data R). octets_formed v)"

text \<open>
  Exact artifact identity is ordinary equality of the complete mathematical
  record.  A digest or reference may identify that value externally, but is not
  substituted for it here.
\<close>

lemma exact_identity_iff:
  fixes R R' :: exact_artifact
  shows "R = R' \<longleftrightarrow>
   object_structure R = object_structure R' \<and> object_data R = object_data R'"
  by (cases R; cases R') auto

lemma local_star_does_not_determine_exact_identity:
  "\<exists>R S :: exact_artifact. exact_formed R \<and> exact_formed S \<and>
    footprint_of R {[]} = footprint_of S {[]} \<and>
    [] \<in> rra_carrier (object_structure R) \<and>
    [] \<in> rra_carrier (object_structure S) \<and>
    R \<noteq> S \<and> (R,[]) \<noteq> (S,[])"
proof -
  let ?R = "\<lparr>object_structure = \<lparr>rra_carrier = {[]}, rra_incidence = {}\<rparr>,
    object_data = empty_basis\<rparr> :: exact_artifact"
  let ?S = "\<lparr>object_structure = \<lparr>rra_carrier = {[],[0]}, rra_incidence = {}\<rparr>,
    object_data = empty_basis\<rparr> :: exact_artifact"
  show ?thesis
    by (rule exI[of _ ?R], rule exI[of _ ?S])
       (auto simp: exact_formed_def object_formed_def rra_formed_def octets_formed_def
         basis_values_def basis_formed_def single_valued_def bag_support_def empty_basis_def footprint_of_def Let_def
         touching_incidence_def exact_identity_iff rra_identity)
qed

section \<open>Reference environments and occurrence citations\<close>

type_synonym artifact_resolver =
  "(artifact_reference \<times> exact_artifact) set"

definition resolver_formed :: "artifact_resolver \<Rightarrow> bool" where
  "resolver_formed \<rho> \<longleftrightarrow>
     finite \<rho> \<and> single_valued \<rho> \<and>
     (\<forall>r R. (r,R) \<in> \<rho> \<longrightarrow> octets_formed r \<and> exact_formed R)"

definition resolves ::
  "artifact_resolver \<Rightarrow> artifact_reference \<Rightarrow> exact_artifact \<Rightarrow> bool" where
  "resolves \<rho> r R \<longleftrightarrow> (r,R) \<in> \<rho>"

lemma resolver_non_rebinding:
  assumes "resolver_formed \<rho>" "resolves \<rho> r R" "resolves \<rho> r R'"
  shows "R = R'"
  using assms by (auto simp: resolver_formed_def resolves_def single_valued_def)

text \<open>
  The following sum is a metalevel projection used by the bootstrap.  Later
  theories define an RRA topology from which its two alternatives are uniquely
  recovered.  The constructor names are not stored semantic tags.
\<close>

datatype exact_anchor =
    Whole_Artifact artifact_reference
  | Occurrence_Citation artifact_reference local_address

definition anchor_formed :: "artifact_resolver \<Rightarrow> exact_anchor \<Rightarrow> bool" where
  "anchor_formed \<rho> a \<longleftrightarrow>
     (case a of
        Whole_Artifact r \<Rightarrow> (\<exists>R. resolves \<rho> r R)
      | Occurrence_Citation r x \<Rightarrow>
          (\<exists>R. resolves \<rho> r R \<and> x \<in> rra_carrier (object_structure R)))"

definition anchor_artifact ::
  "artifact_resolver \<Rightarrow> exact_anchor \<Rightarrow> exact_artifact" where
  "anchor_artifact \<rho> a =
     (case a of
        Whole_Artifact r \<Rightarrow> rel_value \<rho> r
      | Occurrence_Citation r x \<Rightarrow> rel_value \<rho> r)"

definition anchor_occurrence :: "exact_anchor \<Rightarrow> local_address option" where
  "anchor_occurrence a =
     (case a of Whole_Artifact r \<Rightarrow> None
      | Occurrence_Citation r x \<Rightarrow> Some x)"

section \<open>Concrete local-address realizations\<close>

fun unary_address :: "nat \<Rightarrow> local_address" where
  "unary_address n = replicate n 0 @ [1]"

lemma unary_address_formed:
  "octets_formed (unary_address n)"
  by (auto simp: octets_formed_def)

lemma unary_address_length:
  "length (unary_address n) = Suc n"
  by simp

lemma unary_address_inj:
  "inj unary_address"
proof (rule injI)
  fix m n
  assume "unary_address m = unary_address n"
  then have "length (unary_address m) = length (unary_address n)"
    by simp
  then show "m = n"
    by simp
qed

lemma unary_address_eq_iff [simp]:
  "unary_address m = unary_address n \<longleftrightarrow> m = n"
  using unary_address_inj by (auto simp: inj_def)

definition finite_addressing :: "'a set \<Rightarrow> ('a \<Rightarrow> local_address) \<Rightarrow> bool" where
  "finite_addressing U f \<longleftrightarrow>
     inj_on f U \<and> (\<forall>x \<in> U. octets_formed (f x))"

lemma finite_addressing_exists:
  assumes "finite U"
  shows "\<exists>f. finite_addressing U f"
proof -
  obtain g :: "'a \<Rightarrow> nat" where g: "inj_on g U"
    using finite_imp_inj_to_nat_seg[OF assms] by blast
  have i: "inj_on (unary_address \<circ> g) U"
    using g unary_address_inj
    by (auto simp: inj_on_def inj_def)
  have entry: "\<forall>x \<in> U. octets_formed ((unary_address \<circ> g) x)"
    using unary_address_formed by auto
  show ?thesis
    using i entry by (auto simp: finite_addressing_def)
qed

definition exact_realization ::
  "('a \<Rightarrow> local_address) \<Rightarrow> ('a,octets) structured_object \<Rightarrow> exact_artifact \<Rightarrow> bool" where
  "exact_realization f obj R \<longleftrightarrow>
     object_formed obj \<and> exact_formed R \<and>
     finite_addressing (rra_carrier (object_structure obj)) f \<and>
     object_structure R = push_structure f (object_structure obj) \<and>
     object_data R = push_basis (rra_carrier (object_structure obj)) f (object_data obj)"

lemma exact_realization_structure_iso:
  assumes "exact_realization f obj R"
  shows "rra_isomorphism f (object_structure obj) (object_structure R)"
proof -
  from assms have inj: "inj_on f (rra_carrier (object_structure obj))"
    and eq: "object_structure R = push_structure f (object_structure obj)"
    by (auto simp: exact_realization_def finite_addressing_def)
  have "rra_isomorphism f (object_structure obj)
          (push_structure f (object_structure obj))"
    using push_structure_iso[OF inj] .
  with eq show ?thesis by simp
qed

text \<open>
  The spelling of a local address belongs to exact artifact identity, but has no
  structural meaning.  Any semantic invariance under exact re-addressing must
  be established through the isomorphism just exposed, never by treating two
  exact artifacts as literally equal.
\<close>

end
