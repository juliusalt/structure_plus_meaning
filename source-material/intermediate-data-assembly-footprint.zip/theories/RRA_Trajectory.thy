theory RRA_Trajectory
  imports RRA_Structural_Syntax
begin

section \<open>Immutable structurally recovered generations\<close>

record generation_projection =
  generation_locus :: exact_anchor
  generation_predecessors :: "exact_anchor set"
  generation_payload :: exact_anchor
  generation_dependencies :: "exact_anchor set"
  generation_evidence :: "exact_anchor set"


definition raw_generation_at ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow>
   generation_projection \<Rightarrow> bool" where
  "raw_generation_at \<rho> E g G \<longleftrightarrow>
     (\<exists>lr pr yr dr er.
        record_at (object_structure E) g [lr,pr,yr,dr,er] \<and>
        anchored_at \<rho> E lr (generation_locus G) \<and>
        anchor_family_at \<rho> E pr (generation_predecessors G) \<and>
        anchored_at \<rho> E yr (generation_payload G) \<and>
        anchor_family_at \<rho> E dr (generation_dependencies G) \<and>
        anchor_family_at \<rho> E er (generation_evidence G))"

definition generation_at ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow>
   generation_projection \<Rightarrow> bool" where
  "generation_at \<rho> E g G \<longleftrightarrow>
     raw_generation_at \<rho> E g G \<and>
     (\<forall>H. raw_generation_at \<rho> E g H \<longrightarrow> H = G)"

lemma generation_at_unique:
  assumes "generation_at \<rho> E g G" "generation_at \<rho> E g H"
  shows "G = H"
  using assms by (auto simp: generation_at_def)

record trajectory =
  trajectory_reference :: artifact_reference
  trajectory_root :: local_address

definition trajectory_artifact ::
  "artifact_resolver \<Rightarrow> trajectory \<Rightarrow> exact_artifact" where
  "trajectory_artifact \<rho> T = rel_value \<rho> (trajectory_reference T)"

definition raw_trajectory_roots ::
  "artifact_resolver \<Rightarrow> trajectory \<Rightarrow> local_address set \<Rightarrow> bool" where
  "raw_trajectory_roots \<rho> T G \<longleftrightarrow>
     resolves \<rho> (trajectory_reference T) (trajectory_artifact \<rho> T) \<and>
     family_at (object_structure (trajectory_artifact \<rho> T))
               (trajectory_root T) G"

definition trajectory_generation_roots ::
  "artifact_resolver \<Rightarrow> trajectory \<Rightarrow> local_address set" where
  "trajectory_generation_roots \<rho> T =
     (THE G. raw_trajectory_roots \<rho> T G)"

definition generation_identity ::
  "trajectory \<Rightarrow> local_address \<Rightarrow> exact_anchor" where
  "generation_identity T g =
     Occurrence_Citation (trajectory_reference T) g"

definition trajectory_predecessor_edges ::
  "artifact_resolver \<Rightarrow> trajectory \<Rightarrow> (exact_anchor \<times> exact_anchor) set" where
  "trajectory_predecessor_edges \<rho> T =
     {(p,generation_identity T g) |p g G.
        g \<in> trajectory_generation_roots \<rho> T \<and>
        generation_at \<rho> (trajectory_artifact \<rho> T) g G \<and>
        p \<in> generation_predecessors G}"

definition trajectory_formed ::
  "artifact_resolver \<Rightarrow> trajectory \<Rightarrow> bool" where
  "trajectory_formed \<rho> T \<longleftrightarrow>
     resolver_formed \<rho> \<and>
     resolves \<rho> (trajectory_reference T) (trajectory_artifact \<rho> T) \<and>
     exact_formed (trajectory_artifact \<rho> T) \<and>
     rooted_connected (object_structure (trajectory_artifact \<rho> T))
                     (trajectory_root T) \<and>
     (\<exists>!G. raw_trajectory_roots \<rho> T G) \<and>
     (\<forall>g \<in> trajectory_generation_roots \<rho> T.
        \<exists>!G. generation_at \<rho> (trajectory_artifact \<rho> T) g G) \<and>
     acyclic_edges (trajectory_predecessor_edges \<rho> T)"

lemma trajectory_generation_identity_is_citation:
  "generation_identity T g =
   Occurrence_Citation (trajectory_reference T) g"
  by (simp add: generation_identity_def)

lemma trajectory_has_no_stored_transitive_ancestry:
  "strict_ancestor (trajectory_predecessor_edges \<rho> T) a b \<longleftrightarrow>
   (a,b) \<in> (trajectory_predecessor_edges \<rho> T)\<^sup>+"
  by (simp add: strict_ancestor_def)

section \<open>Exact publications\<close>

record publication_projection =
  publication_selections :: "(exact_anchor \<times> exact_anchor) set"
  publication_dependencies :: "exact_anchor set"
  publication_evidence :: "exact_anchor set"

record publication =
  publication_reference :: artifact_reference
  publication_root :: local_address

definition publication_artifact ::
  "artifact_resolver \<Rightarrow> publication \<Rightarrow> exact_artifact" where
  "publication_artifact \<rho> P = rel_value \<rho> (publication_reference P)"

definition selection_at ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow>
   exact_anchor \<Rightarrow> exact_anchor \<Rightarrow> bool" where
  "selection_at \<rho> E s locus generation \<longleftrightarrow>
     (\<exists>lr gr.
        record_at (object_structure E) s [lr,gr] \<and>
        anchored_at \<rho> E lr locus \<and>
        anchored_at \<rho> E gr generation)"

definition selection_family_at ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow>
   (exact_anchor \<times> exact_anchor) set \<Rightarrow> bool" where
  "selection_family_at \<rho> E root S \<longleftrightarrow>
     (\<exists>R.
        family_at (object_structure E) root R \<and>
        (\<forall>r \<in> R. \<exists>!lg. selection_at \<rho> E r (fst lg) (snd lg)) \<and>
        S = {(l,g). \<exists>r \<in> R. selection_at \<rho> E r l g})"

definition raw_publication_at ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow>
   publication_projection \<Rightarrow> bool" where
  "raw_publication_at \<rho> E p P \<longleftrightarrow>
     (\<exists>sr dr er.
        record_at (object_structure E) p [sr,dr,er] \<and>
        selection_family_at \<rho> E sr (publication_selections P) \<and>
        anchor_family_at \<rho> E dr (publication_dependencies P) \<and>
        anchor_family_at \<rho> E er (publication_evidence P))"

definition publication_at ::
  "artifact_resolver \<Rightarrow> exact_artifact \<Rightarrow> local_address \<Rightarrow>
   publication_projection \<Rightarrow> bool" where
  "publication_at \<rho> E p P \<longleftrightarrow>
     raw_publication_at \<rho> E p P \<and>
     (\<forall>Q. raw_publication_at \<rho> E p Q \<longrightarrow> Q = P)"

definition publication_formed ::
  "artifact_resolver \<Rightarrow> publication \<Rightarrow> bool" where
  "publication_formed \<rho> P \<longleftrightarrow>
     resolver_formed \<rho> \<and>
     resolves \<rho> (publication_reference P) (publication_artifact \<rho> P) \<and>
     exact_formed (publication_artifact \<rho> P) \<and>
     rooted_connected (object_structure (publication_artifact \<rho> P))
                     (publication_root P) \<and>
     (\<exists>!Q. publication_at \<rho> (publication_artifact \<rho> P)
                               (publication_root P) Q)"

lemma publication_projection_unique:
  assumes "publication_at \<rho> E p P" "publication_at \<rho> E p Q"
  shows "P = Q"
  using assms by (auto simp: publication_at_def)

text \<open>
  No current-generation function and no mutation operation is defined.  A
  publication is an immutable structural selection.  Whether any authority
  recognizes a selection as current is a later Factor judgment relative to an
  exact foundation and exact authority frame.
\<close>

definition projected_publication ::
  "artifact_resolver \<Rightarrow> publication \<Rightarrow> publication_projection" where
  "projected_publication \<rho> P =
     (THE Q. publication_at \<rho> (publication_artifact \<rho> P)
                              (publication_root P) Q)"

end
