theory Bootstrap_Relations
  imports Main
begin

section \<open>Finite extensional relations\<close>

text \<open>
  These definitions are mathematical conveniences only.  They introduce no
  stored map object and no procedural reading.  Whenever a relation is used as
  a map, its exact graph is the fact being supplied.
\<close>

definition rel_dom :: "('a \<times> 'b) set \<Rightarrow> 'a set" where
  "rel_dom R = {x. \<exists>y. (x,y) \<in> R}"

definition rel_ran :: "('a \<times> 'b) set \<Rightarrow> 'b set" where
  "rel_ran R = {y. \<exists>x. (x,y) \<in> R}"

lemma rel_domI [intro]:
  "(x,y) \<in> R \<Longrightarrow> x \<in> rel_dom R"
  unfolding rel_dom_def by blast

lemma rel_ranI [intro]:
  "(x,y) \<in> R \<Longrightarrow> y \<in> rel_ran R"
  unfolding rel_ran_def by blast

lemma rel_dom_image:
  "rel_dom R = fst ` R"
  by (auto simp: rel_dom_def intro: rev_image_eqI)

lemma rel_ran_image:
  "rel_ran R = snd ` R"
  by (auto simp: rel_ran_def intro: rev_image_eqI)

lemma finite_rel_dom:
  assumes "finite R"
  shows "finite (rel_dom R)"
  using assms by (simp add: rel_dom_image)

lemma finite_rel_ran:
  assumes "finite R"
  shows "finite (rel_ran R)"
  using assms by (simp add: rel_ran_image)

lemma rel_dom_eq_empty [simp]:
  "rel_dom R = {} \<longleftrightarrow> R = {}"
  by (auto simp: rel_dom_def)

definition single_valued :: "('a \<times> 'b) set \<Rightarrow> bool" where
  "single_valued R \<longleftrightarrow> (\<forall>x y z. (x,y) \<in> R \<longrightarrow> (x,z) \<in> R \<longrightarrow> y = z)"

lemma single_valued_outputs:
  assumes "single_valued R" "(x,y) \<in> R" "(x,z) \<in> R"
  shows "y = z"
  using assms by (auto simp: single_valued_def)

lemma complete_socket_reading_unique:
  assumes qsv: "single_valued Q" and qdom: "rel_dom Q = rel_dom M"
    and qread: "\<forall>s a. (s,a) \<in> M \<longrightarrow> (\<exists>x. (s,x) \<in> Q \<and> reads a x)"
    and wsv: "single_valued W" and wdom: "rel_dom W = rel_dom M"
    and wread: "\<forall>s a. (s,a) \<in> M \<longrightarrow> (\<exists>x. (s,x) \<in> W \<and> reads a x)"
    and unique: "\<And>a x y. reads a x \<Longrightarrow> reads a y \<Longrightarrow> x = y"
  shows "Q = W"
proof -
  have compare: "\<And>A B. single_valued A \<Longrightarrow> rel_dom A = rel_dom M \<Longrightarrow>
    (\<forall>s a. (s,a) \<in> M \<longrightarrow> (\<exists>x. (s,x) \<in> A \<and> reads a x)) \<Longrightarrow>
    (\<forall>s a. (s,a) \<in> M \<longrightarrow> (\<exists>x. (s,x) \<in> B \<and> reads a x)) \<Longrightarrow> A \<subseteq> B"
  proof -
    fix A B assume sv: "single_valued A" and domain: "rel_dom A = rel_dom M"
      and left: "\<forall>s a. (s,a) \<in> M \<longrightarrow> (\<exists>x. (s,x) \<in> A \<and> reads a x)"
      and right: "\<forall>s a. (s,a) \<in> M \<longrightarrow> (\<exists>x. (s,x) \<in> B \<and> reads a x)"
    show "A \<subseteq> B"
    proof
      fix entry assume member: "entry \<in> A"
      obtain s x where shape: "entry = (s,x)" by (cases entry) auto
      have entry: "(s,x) \<in> A" using member shape by simp
      have key: "s \<in> rel_dom M" using rel_domI[OF entry] domain by simp
      obtain a where field: "(s,a) \<in> M" using key by (auto simp: rel_dom_def)
      obtain y where first: "(s,y) \<in> A" "reads a y" using left field by blast
      obtain z where second: "(s,z) \<in> B" "reads a z" using right field by blast
      have xy: "x = y" by (rule single_valued_outputs[OF sv entry first(1)])
      have yz: "y = z" by (rule unique[OF first(2) second(2)])
      show "entry \<in> B" using shape xy yz second(1) by simp
    qed
  qed
  show ?thesis using compare[OF qsv qdom qread wread] compare[OF wsv wdom wread qread] by blast
qed

definition total_on :: "'a set \<Rightarrow> ('a \<times> 'b) set \<Rightarrow> bool" where
  "total_on A R \<longleftrightarrow> rel_dom R = A"

definition graph_map :: "'a set \<Rightarrow> ('a \<Rightarrow> 'b) \<Rightarrow> ('a \<times> 'b) set" where
  "graph_map A f = {(x,f x) |x. x \<in> A}"

definition rel_value :: "('a \<times> 'b) set \<Rightarrow> 'a \<Rightarrow> 'b" where
  "rel_value R x = (THE y. (x,y) \<in> R)"

definition exact_map :: "'a set \<Rightarrow> 'b set \<Rightarrow> ('a \<times> 'b) set \<Rightarrow> bool" where
  "exact_map A B R \<longleftrightarrow>
     finite A \<and> finite B \<and> finite R \<and>
     single_valued R \<and> rel_dom R = A \<and> rel_ran R = B"

lemma single_valued_union_iff:
  assumes "single_valued R" "single_valued S"
  shows "single_valued (R \<union> S) \<longleftrightarrow>
    (\<forall>x y z. (x,y) \<in> R \<longrightarrow> (x,z) \<in> S \<longrightarrow> y = z)"
  using assms by (auto simp: single_valued_def; blast)

lemma single_valued_fibre:
  assumes "single_valued R" "(x,y) \<in> R"
  shows "{z. (x,z) \<in> R} = {y}"
  using assms by (auto simp: single_valued_def)

lemma single_valued_zip:
  assumes "distinct xs"
  shows "single_valued (set (zip xs ys))"
  using assms
proof (induction xs arbitrary: ys)
  case Nil
  then show ?case by (simp add: single_valued_def)
next
  case (Cons x xs)
  then show ?case
    by (cases ys) (auto simp: single_valued_def dest: set_zip_leftD)
qed

lemma graph_map_single_valued:
  "single_valued (graph_map A f)"
  by (auto simp: single_valued_def graph_map_def)

lemma graph_map_empty [simp]: "graph_map {} f = {}"
  by (simp add: graph_map_def)

lemma graph_map_insert [simp]:
  "graph_map (insert x A) f = insert (x,f x) (graph_map A f)"
  by (auto simp: graph_map_def)

lemma graph_map_dom:
  "rel_dom (graph_map A f) = A"
  by (auto simp: rel_dom_def graph_map_def)

lemma graph_map_ran:
  "rel_ran (graph_map A f) = f ` A"
  by (auto simp: rel_ran_def graph_map_def)

lemma rel_value_graph_map:
  assumes "x \<in> A"
  shows "rel_value (graph_map A f) x = f x"
  using assms by (simp add: rel_value_def graph_map_def)

lemma rel_value_eq:
  assumes "single_valued R" "(x,y) \<in> R"
  shows "rel_value R x = y"
  unfolding rel_value_def
  by (rule the_equality) (use assms in \<open>auto simp: single_valued_def\<close>)

lemma single_valued_graph:
  assumes "single_valued R"
  shows "R = graph_map (rel_dom R) (rel_value R)"
  using rel_value_eq[OF assms]
  by (auto simp: graph_map_def rel_dom_def)

lemma finite_single_valued:
  fixes R :: "('a \<times> 'b) set"
  assumes "finite (rel_dom R)" "single_valued R"
  shows "finite R"
proof -
  have graph: "R = (\<lambda>x. (x,rel_value R x)) ` rel_dom R"
    using single_valued_graph[OF assms(2)] by (auto simp: graph_map_def)
  show ?thesis by (subst graph) (rule finite_imageI[OF assms(1)])
qed

lemma exact_map_value:
  assumes "exact_map A B R" "x \<in> A"
  shows "(x, rel_value R x) \<in> R"
proof -
  from assms have "x \<in> rel_dom R"
    by (simp add: exact_map_def)
  then obtain y where xy: "(x,y) \<in> R"
    by (auto simp: rel_dom_def)
  from assms have sv: "single_valued R"
    by (simp add: exact_map_def)
  have "(THE z. (x,z) \<in> R) = y"
    by (rule the_equality) (use xy sv in \<open>auto simp: single_valued_def\<close>)
  with xy show ?thesis
    by (simp add: rel_value_def)
qed

lemma exact_map_value_in_ran:
  assumes "exact_map A B R" "x \<in> A"
  shows "rel_value R x \<in> B"
  using exact_map_value[OF assms] assms
  by (auto simp: exact_map_def rel_ran_def)

lemma exact_map_surjective:
  assumes "exact_map A B R" "y \<in> B"
  shows "\<exists>x \<in> A. (x,y) \<in> R"
  using assms unfolding exact_map_def rel_dom_def rel_ran_def by blast

lemma exact_map_value_image:
  assumes "exact_map A B R"
  shows "rel_value R ` A = B"
proof
  show "rel_value R ` A \<subseteq> B"
    using exact_map_value_in_ran[OF assms] by blast
  show "B \<subseteq> rel_value R ` A"
  proof
    fix y assume "y \<in> B"
    then obtain x where "x \<in> A" "(x,y) \<in> R"
      using exact_map_surjective[OF assms] by blast
    moreover have "single_valued R"
      using assms by (simp add: exact_map_def)
    ultimately show "y \<in> rel_value R ` A"
      using rel_value_eq[of R x y] by blast
  qed
qed

lemma graph_map_exact:
  assumes "finite A"
  shows "exact_map A (f ` A) (graph_map A f)"
proof -
  have "graph_map A f = (\<lambda>x. (x,f x)) ` A"
    by (auto simp: graph_map_def)
  with assms have "finite (graph_map A f)" by simp
  with assms show ?thesis
    by (simp add: exact_map_def graph_map_single_valued graph_map_dom graph_map_ran)
qed

definition relation_image ::
  "('a \<times> 'b) set \<Rightarrow> ('a \<times> 'a) set \<Rightarrow> ('b \<times> 'b) set" where
  "relation_image f R =
     {(rel_value f x, rel_value f y) |x y. (x,y) \<in> R}"

definition ternary_image ::
  "('a \<times> 'b) set \<Rightarrow> ('a \<times> 'a \<times> 'a) set \<Rightarrow> ('b \<times> 'b \<times> 'b) set" where
  "ternary_image f R =
     {(rel_value f r, rel_value f p, rel_value f x) |r p x.
        (r,p,x) \<in> R}"

lemma pair_image_cong:
  assumes "R \<subseteq> U \<times> U" "\<And>a. a \<in> U \<Longrightarrow> f a = g a"
  shows "(\<lambda>(a,b). (f a,f b)) ` R = (\<lambda>(a,b). (g a,g b)) ` R"
  by (rule image_cong[OF refl]) (use assms in auto)

lemma pair_image_domain:
  "rel_dom ((\<lambda>(a,b). (f a,g b)) ` R) = f ` rel_dom R"
  by (auto simp: rel_dom_def intro: rev_image_eqI)

lemma pair_image_range:
  "rel_ran ((\<lambda>(a,b). (f a,g b)) ` R) = g ` rel_ran R"
  by (auto simp: rel_ran_def intro: rev_image_eqI)

lemma single_valued_pair_image:
  assumes "single_valued R" "inj_on f (rel_dom R)"
  shows "single_valued ((\<lambda>(a,b). (f a,g b)) ` R)"
  using assms by (auto simp: single_valued_def inj_on_def rel_dom_def; blast)

lemma pair_image_snd_injective:
  fixes R :: "('a \<times> 'b) set" and f :: "'a \<Rightarrow> 'c" and g :: "'b \<Rightarrow> 'd"
  assumes source: "inj_on snd R" and target: "inj_on g (rel_ran R)"
  shows "inj_on snd ((\<lambda>(a,b). (f a,g b)) ` R)"
proof (rule inj_onI)
  fix x y :: "'c \<times> 'd"
  assume xm: "x \<in> (\<lambda>(a,b). (f a,g b)) ` R"
    and ym: "y \<in> (\<lambda>(a,b). (f a,g b)) ` R" and eq: "snd x = snd y"
  obtain a b where ab: "(a,b) \<in> R" and xp: "x = (f a,g b)" using xm by auto
  obtain c d where cd: "(c,d) \<in> R" and yp: "y = (f c,g d)" using ym by auto
  have br: "b \<in> rel_ran R" and dr: "d \<in> rel_ran R" using ab cd by (auto simp: rel_ran_def)
  have images: "g b = g d" using eq xp yp by simp
  have same: "b = d" by (rule inj_onD[OF target images br dr])
  have pairs: "(a,b) = (c,d)" by (rule inj_onD[OF source _ ab cd]) (use same in simp)
  show "x = y" using pairs xp yp by simp
qed

section \<open>Finite ancestry\<close>

text \<open>Only direct edges are stored.  Transitive ancestry is always derived.\<close>

definition strict_ancestor :: "('a \<times> 'a) set \<Rightarrow> 'a \<Rightarrow> 'a \<Rightarrow> bool" where
  "strict_ancestor E x y \<longleftrightarrow> (x,y) \<in> E\<^sup>+"

definition acyclic_edges :: "('a \<times> 'a) set \<Rightarrow> bool" where
  "acyclic_edges E \<longleftrightarrow> (\<forall>x. (x,x) \<notin> E\<^sup>+)"

lemma strict_ancestor_irrefl:
  assumes "acyclic_edges E"
  shows "\<not> strict_ancestor E x x"
  using assms by (simp add: acyclic_edges_def strict_ancestor_def)

lemma strict_ancestor_trans:
  assumes "strict_ancestor E x y" "strict_ancestor E y z"
  shows "strict_ancestor E x z"
  using assms unfolding strict_ancestor_def by (meson trancl_trans)

end
