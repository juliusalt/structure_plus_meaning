theory Factor_Native_Equality
  imports Factor_Native_Meaning Factor_Application_Encoding
begin

section \<open>A finite native program with an unbounded argument domain\<close>

definition equality_artifact :: exact_artifact where
  "equality_artifact =
    \<lparr>object_structure = \<lparr>rra_carrier = (\<lambda>n. [n]) ` {..<26},
      rra_incidence = {([0],[16],[15]),
        ([15],[15],[Suc 0]),
        ([Suc 0],[17],[2]),
        ([Suc 0],[18],[6]),
        ([17],[17],[18]),
        ([2],[19],[3]),
        ([2],[20],[5]),
        ([19],[19],[20]),
        ([3],[4],[4]),
        ([5],[5],[4]),
        ([6],[7],[8]),
        ([8],[21],[9]),
        ([8],[22],[11]),
        ([8],[23],[14]),
        ([21],[21],[22]),
        ([22],[22],[23]),
        ([9],[10],[10]),
        ([11],[24],[12]),
        ([11],[25],[13]),
        ([24],[24],[25]),
        ([12],[12],[10]),
        ([13],[13],[10])}\<rparr>,
      object_data = empty_basis\<rparr>"

lemma equality_artifact_carrier [simp]:
  "[n] \<in> rra_carrier (object_structure equality_artifact) \<longleftrightarrow> n < 26"
  by (auto simp: equality_artifact_def)

lemma equality_artifact_data [simp]:
  "object_data equality_artifact = empty_basis"
  by (simp add: equality_artifact_def)

lemma equality_object_formed:
  "object_formed equality_artifact"
  by (auto simp: equality_artifact_def object_formed_def rra_formed_def intro: rev_image_eqI)

lemma equality_artifact_formed:
  "exact_formed equality_artifact"
  using equality_object_formed
  by (auto simp: exact_formed_def equality_artifact_def octets_formed_def)

definition equality_environment :: "local_address option artifact_environment" where
  "equality_environment = literal_environment equality_artifact {}"

lemma equality_environment_formed [simp]:
  "environment_formed equality_environment"
  unfolding equality_environment_def
  by (rule literal_environment_formed[OF equality_artifact_formed])
     (auto simp: single_valued_def rel_dom_def)

lemma equality_environment_artifact [simp]:
  "artifact_at equality_environment None R \<longleftrightarrow> R = equality_artifact"
  by (simp add: equality_environment_def)

lemma equality_environment_no_bindings [simp]:
  "environment_bindings equality_environment = {}"
  by (simp add: equality_environment_def literal_environment_def rel_dom_def)

lemma equality_heads [simp]:
  "headed_incidence (object_structure equality_artifact) [0] = {([16],[15])}"
  "headed_incidence (object_structure equality_artifact) [Suc 0] = {([17],[2]),([18],[6])}"
  "headed_incidence (object_structure equality_artifact) [2] = {([19],[3]),([20],[5])}"
  "headed_incidence (object_structure equality_artifact) [3] = {([4],[4])}"
  "headed_incidence (object_structure equality_artifact) [4] = {}"
  "headed_incidence (object_structure equality_artifact) [5] = {([5],[4])}"
  "headed_incidence (object_structure equality_artifact) [6] = {([7],[8])}"
  "headed_incidence (object_structure equality_artifact) [7] = {}"
  "headed_incidence (object_structure equality_artifact) [8] = {([21],[9]),([22],[11]),([23],[14])}"
  "headed_incidence (object_structure equality_artifact) [9] = {([10],[10])}"
  "headed_incidence (object_structure equality_artifact) [10] = {}"
  "headed_incidence (object_structure equality_artifact) [11] = {([24],[12]),([25],[13])}"
  "headed_incidence (object_structure equality_artifact) [12] = {([12],[10])}"
  "headed_incidence (object_structure equality_artifact) [13] = {([13],[10])}"
  "headed_incidence (object_structure equality_artifact) [14] = {}"
  "headed_incidence (object_structure equality_artifact) [15] = {([15],[Suc 0])}"
  "headed_incidence (object_structure equality_artifact) [16] = {}"
  "headed_incidence (object_structure equality_artifact) [17] = {([17],[18])}"
  "headed_incidence (object_structure equality_artifact) [18] = {}"
  "headed_incidence (object_structure equality_artifact) [19] = {([19],[20])}"
  "headed_incidence (object_structure equality_artifact) [20] = {}"
  "headed_incidence (object_structure equality_artifact) [21] = {([21],[22])}"
  "headed_incidence (object_structure equality_artifact) [22] = {([22],[23])}"
  "headed_incidence (object_structure equality_artifact) [23] = {}"
  "headed_incidence (object_structure equality_artifact) [24] = {([24],[25])}"
  "headed_incidence (object_structure equality_artifact) [25] = {}"
  by (auto simp: equality_artifact_def headed_incidence_def)

lemma equality_records:
  assumes "(r,ps,xs) \<in> {
    ([Suc 0],[[17],[18]],[[2],[6]]),
    ([2],[[19],[20]],[[3],[5]]),
    ([8],[[21],[22],[23]],[[9],[11],[14]]),
    ([11],[[24],[25]],[[12],[13]])}"
  shows "record_at equality_artifact r ps xs"
proof -
  have template: "record_at (record_object r ps xs :: exact_artifact) r ps xs"
    using assms by (auto intro!: record_object_recovers)
  have reads: "object_reads_agree (record_object r ps xs :: exact_artifact)
    equality_artifact (insert r (set ps))"
    using assms by (auto simp only: insert_iff singleton_iff prod.inject;
        auto simp: object_reads_agree_def record_object_def record_structure_def;
        auto simp: headed_incidence_def equality_artifact_def)
  show ?thesis by (rule record_at_read_transport[OF template equality_object_formed reads]) simp
qed

lemma equality_families:
  assumes "(r,M) \<in> {
    ([0],{([16],[15])}), ([3],{([4],[4])}), ([6],{([7],[8])}),
    ([9],{([10],[10])}), ([14],{})}"
  shows "family_at equality_artifact r M"
  using assms equality_object_formed
  by (auto simp: family_at_def single_valued_def rel_dom_def)

lemma equality_local_citations:
  assumes "(r,a) \<in> {([5],[4]),([12],[10]),([13],[10]),([15],[Suc 0])}"
  shows "citation_at equality_artifact r (Local a) {r}"
proof -
  have head: "headed_incidence (object_structure equality_artifact) r = {(r,a)}"
    using assms by auto
  have raw: "raw_citation_at equality_artifact r (Local a) {r}" by (rule raw_citation_at.local[OF head])
  show ?thesis using assms raw equality_artifact_formed by (auto simp: citation_at_def)
qed


definition native_equality_schema :: "local_address option native_schema" where
  "native_equality_schema =
    \<lparr>schema_conclusion = Pattern_Pair (Pattern_Variable [10]) (Pattern_Variable [10]),
      schema_premises = {}\<rparr>"

definition native_equality_program :: "local_address option native_system" where
  "native_equality_program =
    \<lparr>system_interfaces = {((None,[Suc 0]),Pattern_Variable [4])},
      system_clauses = {(((None,[Suc 0]),[7]),native_equality_schema)}\<rparr>"

lemma equality_variable_patterns:
  assumes "(r,a) \<in> {([5],[4]),([12],[10]),([13],[10])}"
  shows "pattern_quoted_at equality_environment None {a} r (Pattern_Variable a) {r} {}"
proof -
  have cite: "citation_at equality_artifact r (Local a) {r}"
    by (rule equality_local_citations) (use assms in auto)
  have art: "artifact_at equality_environment None equality_artifact" by simp
  show ?thesis by (rule pattern_quoted_at.variable[OF equality_environment_formed art cite])
    (use assms in auto)
qed

lemma equality_scoped_interface:
  "scoped_pattern_at equality_environment None [2] (Pattern_Variable [4]) {[2],[19],[20],[3],[4],[5]} {}"
proof -
  have rec: "record_at equality_artifact [2] [[19],[20]] [[3],[5]]"
    by (rule equality_records) simp
  have family: "family_at equality_artifact [3] {([4],[4])}" by (rule equality_families) simp
  have scope: "binder_scope_at equality_artifact [3] {[4]}" using family by (simp add: binder_scope_at_def)
  have quote: "pattern_quoted_at equality_environment None {[4]} [5] (Pattern_Variable [4]) {[5]} {}"
    by (rule equality_variable_patterns) simp
  show ?thesis unfolding scoped_pattern_at_def
    by (rule conjI[OF equality_environment_formed], rule exI[of _ equality_artifact],
        rule exI[of _ "[[19],[20]]"], rule exI[of _ "[3]"], rule exI[of _ "[5]"],
        rule exI[of _ "{[4]}"], rule exI[of _ "{[5]}"])
       (use rec scope quote in auto)
qed

lemma equality_conclusion:
  "pattern_quoted_at equality_environment None {[10]} [11]
    (Pattern_Pair (Pattern_Variable [10]) (Pattern_Variable [10])) {[11],[24],[25],[12],[13]} {}"
proof -
  have rec: "record_at equality_artifact [11] [[24],[25]] [[12],[13]]" by (rule equality_records) simp
  have left: "pattern_quoted_at equality_environment None {[10]} [12] (Pattern_Variable [10]) {[12]} {}"
    by (rule equality_variable_patterns) simp
  have right: "pattern_quoted_at equality_environment None {[10]} [13] (Pattern_Variable [10]) {[13]} {}"
    by (rule equality_variable_patterns) simp
  have art: "artifact_at equality_environment None equality_artifact" by simp
  have quote: "pattern_quoted_at equality_environment None {[10]} [11]
    (Pattern_Pair (Pattern_Variable [10]) (Pattern_Variable [10]))
    (insert [11] (set [[24],[25]] \<union> {[12]} \<union> {[13]})) ({} \<union> {})"
    by (rule pattern_quoted_at.pair[OF equality_environment_formed art rec left right]) auto
  show ?thesis using quote by (simp add: insert_commute)
qed

lemma equality_schema_at:
  "native_schema_at equality_environment None [8] native_equality_schema"
proof -
  have rec: "record_at equality_artifact [8] [[21],[22],[23]] [[9],[11],[14]]" by (rule equality_records) simp
  have family: "family_at equality_artifact [9] {([10],[10])}" by (rule equality_families) simp
  have scope: "binder_scope_at equality_artifact [9] {[10]}" using family by (simp add: binder_scope_at_def)
  have empty: "family_at equality_artifact [14] {}" by (rule equality_families) simp
  have body: "prospective_family_at equality_environment None {[10]} [14] {}"
    unfolding prospective_family_at_def
    by (rule conjI[OF equality_environment_formed], rule exI[of _ equality_artifact], rule exI[of _ "{}"])
       (use empty in \<open>auto simp: single_valued_def rel_dom_def\<close>)
  have head: "pattern_quoted_at equality_environment None {[10]} [11]
    (schema_conclusion native_equality_schema) {[11],[24],[25],[12],[13]} {}"
    using equality_conclusion by (simp add: native_equality_schema_def)
  show ?thesis unfolding native_schema_at_def
    by (rule conjI[OF equality_environment_formed], rule exI[of _ equality_artifact],
        rule exI[of _ "[[21],[22],[23]]"], rule exI[of _ "[9]"], rule exI[of _ "[11]"],
        rule exI[of _ "[14]"], rule exI[of _ "{[10]}"],
        rule exI[of _ "{[11],[24],[25],[12],[13]}"], rule exI[of _ "{}"])
       (use rec scope head body in \<open>auto simp: native_equality_schema_def schema_variables_def\<close>)
qed

lemma equality_definition_at:
  "native_definition_at equality_environment None [Suc 0] (Pattern_Variable [4]) {([7],native_equality_schema)}"
proof -
  have rec: "record_at equality_artifact [Suc 0] [[17],[18]] [[2],[6]]" by (rule equality_records) simp
  have family: "family_at equality_artifact [6] {([7],[8])}" by (rule equality_families) simp
  have clauses: "native_schema_family_at equality_environment None [6] {([7],native_equality_schema)}"
    unfolding native_schema_family_at_def
    by (rule conjI[OF equality_environment_formed], rule exI[of _ equality_artifact], rule exI[of _ "{([7],[8])}"])
       (use family equality_schema_at in \<open>auto simp: single_valued_def rel_dom_def\<close>)
  show ?thesis unfolding native_definition_at_def
    by (rule conjI[OF equality_environment_formed], rule exI[of _ equality_artifact],
        rule exI[of _ "[[17],[18]]"], rule exI[of _ "[2]"], rule exI[of _ "[6]"],
        rule exI[of _ "{[2],[19],[20],[3],[4],[5]}"], rule exI[of _ "{}"])
       (use rec equality_scoped_interface clauses in auto)
qed


lemma equality_root_family:
  "native_root_family_at equality_environment None [0] {([16],None,[Suc 0])}"
proof -
  have family: "family_at equality_artifact [0] {([16],[15])}" by (rule equality_families) simp
  have cite: "citation_at equality_artifact [15] (Local [Suc 0]) {[15]}" by (rule equality_local_citations) simp
  have location: "citation_location equality_environment None (Local [Suc 0]) None [Suc 0]"
    using equality_artifact_formed by (auto simp: anchor_formed_def)
  have art: "artifact_at equality_environment None equality_artifact" by simp
  have loc: "located_at equality_environment None [15] None [Suc 0]"
    using art cite location unfolding located_at_def by blast
  show ?thesis unfolding native_root_family_at_def
    by (rule conjI[OF equality_environment_formed], rule exI[of _ equality_artifact], rule exI[of _ "{([16],[15])}"])
       (use family loc in \<open>auto simp: single_valued_def rel_dom_def\<close>)
qed

lemma equality_definition_no_dependencies:
  "((None,[Suc 0]),e) \<notin> native_definition_edges equality_environment"
proof
  assume edge: "((None,[Suc 0]),e) \<in> native_definition_edges equality_environment"
  obtain p C c S where parts: "native_definition_at equality_environment None [Suc 0] p C"
    "(c,S) \<in> C" "e \<in> schema_dependencies S"
    using edge by (auto simp: native_definition_edges_def)
  have same: "p = Pattern_Variable [4] \<and> C = {([7],native_equality_schema)}"
    by (rule native_definition_unique[OF parts(1) equality_definition_at])
  have schema: "S = native_equality_schema" using same parts(2) by simp
  show False using parts(3) schema
    by (simp add: schema_dependencies_def native_equality_schema_def rel_ran_def)
qed

lemma equality_definition_sites:
  "native_definition_sites equality_environment {(None,[Suc 0])} = {(None,[Suc 0])}"
proof -
  have upper: "native_definition_sites equality_environment {(None,[Suc 0])} \<subseteq> {(None,[Suc 0])}"
    by (rule native_definition_sites_least[OF subset_refl])
       (use equality_definition_no_dependencies in auto)
  have lower: "{(None,[Suc 0])} \<subseteq> native_definition_sites equality_environment {(None,[Suc 0])}" by (rule native_definition_roots)
  show ?thesis using upper lower by blast
qed

lemma equality_package_formed:
  "native_package_formed equality_environment {(None,[Suc 0])}"
  using equality_environment_formed equality_definition_at
  by (auto simp: native_package_formed_def equality_definition_sites; blast)

lemma equality_program_projection:
  "native_program equality_environment {(None,[Suc 0])} = native_equality_program"
proof -
  have exact: "\<And>p C. native_definition_at equality_environment None [Suc 0] p C \<longleftrightarrow>
    p = Pattern_Variable [4] \<and> C = {([7],native_equality_schema)}"
  proof -
    fix p C
    show "native_definition_at equality_environment None [Suc 0] p C \<longleftrightarrow>
      p = Pattern_Variable [4] \<and> C = {([7],native_equality_schema)}"
      using native_definition_unique[OF _ equality_definition_at] equality_definition_at by blast
  qed
  have graph: "native_definition_graph equality_environment {(None,[Suc 0])} =
    {((None,[Suc 0]),Pattern_Variable [4],{([7],native_equality_schema)})}"
    by (auto simp: native_definition_graph_def equality_definition_sites exact)
  show ?thesis by (auto simp: native_program_def graph native_equality_program_def)
qed

theorem native_equality_package:
  "native_package_at equality_environment None [0] native_equality_program"
  unfolding native_package_at_def
  by (rule exI[of _ "{([16],None,[Suc 0])}"])
     (use equality_root_family equality_package_formed equality_program_projection in \<open>auto simp: rel_ran_def\<close>)

theorem native_equality_closed:
  "closed_native_package_at equality_environment None [0] native_equality_program"
proof -
  have boundary: "read_boundary_formed equality_environment (native_package_sources equality_environment None [0])
    (native_package_demands equality_environment None [0])"
    by (rule native_package_read_boundary[OF native_equality_package])
  have demands: "native_package_demands equality_environment None [0] = {}"
    using boundary by (auto simp: read_boundary_formed_def rel_dom_def)
  have closed: "environment_closed equality_environment {None} {}"
    using literal_environment_closed[of equality_artifact "{}"] equality_environment_formed
    by (simp add: equality_environment_def rel_dom_def)
  show ?thesis using native_equality_package closed demands by (simp add: closed_native_package_at_def)
qed


lemma native_equality_system_formed [simp]:
  "schema_system_formed native_equality_program"
  by (rule native_package_system_formed[OF native_equality_package])

lemma native_equality_schema_instance:
  assumes "term_formed t"
  shows "schema_instance native_equality_schema {([10],t)} (Pair_Term t t) {}"
  using assms
  by (auto simp: schema_instance_def native_equality_schema_def schema_formed_def schema_variables_def
      schema_premise_instance_def term_bindings_formed_def single_valued_def rel_dom_def)

theorem native_equality_holds:
  assumes "term_formed t"
  shows "((None,[Suc 0]),Pair_Term t t) \<in> positive_meaning native_equality_program"
proof -
  have call: "schema_call_formed native_equality_program (None,[Suc 0]) (Pair_Term t t)"
    using assms native_equality_system_formed by (simp add: schema_call_formed_def native_equality_program_def)
  have inst: "admitted_schema_instance native_equality_program (None,[Suc 0]) [7] {([10],t)} (Pair_Term t t) {}"
    using call native_equality_schema_instance[OF assms]
    by (auto simp: admitted_schema_instance_def native_equality_program_def)
  show ?thesis by (rule positive_meaning_step[OF inst]) simp
qed

lemma native_equality_instance_diagonal:
  assumes "schema_instance native_equality_schema V t Q"
  shows "\<exists>x. term_formed x \<and> t = Pair_Term x x \<and> Q = {}"
proof -
  have head: "pattern_instance V (Pattern_Pair (Pattern_Variable [10]) (Pattern_Variable [10])) t"
    and bindings: "term_bindings_formed (schema_variables native_equality_schema) V"
    and domain: "rel_dom Q = {}"
    using assms by (auto simp: schema_instance_def native_equality_schema_def schema_premise_instance_def rel_dom_def)
  obtain x y where shape: "t = Pair_Term x y" "([10],x) \<in> V" "([10],y) \<in> V" using head by auto
  have same: "x = y" and formed: "term_formed x"
    using bindings shape(2,3) by (auto simp: term_bindings_formed_def single_valued_def)
  have empty: "Q = {}" using domain by simp
  show ?thesis using shape same formed empty by blast
qed

theorem native_equality_exact:
  "((None,[Suc 0]),t) \<in> positive_meaning native_equality_program \<longleftrightarrow>
    (\<exists>x. term_formed x \<and> t = Pair_Term x x)"
proof
  assume holds: "((None,[Suc 0]),t) \<in> positive_meaning native_equality_program"
  obtain c V Q where inst: "admitted_schema_instance native_equality_program (None,[Suc 0]) c V t Q"
    using holds by (subst (asm) positive_meaning_unfold) (auto simp: schema_consequences_def)
  have schema: "schema_instance native_equality_schema V t Q"
    using inst by (auto simp: admitted_schema_instance_def native_equality_program_def)
  show "\<exists>x. term_formed x \<and> t = Pair_Term x x" using native_equality_instance_diagonal[OF schema] by blast
next
  assume "\<exists>x. term_formed x \<and> t = Pair_Term x x"
  then obtain x where formed: "term_formed x" and shape: "t = Pair_Term x x" by blast
  show "((None,[Suc 0]),t) \<in> positive_meaning native_equality_program" using native_equality_holds[OF formed] shape by simp
qed

theorem native_equality_has_infinite_meaning:
  "infinite {t. ((None,[Suc 0]),t) \<in> positive_meaning native_equality_program}"
proof
  assume finite: "finite {t. ((None,[Suc 0]),t) \<in> positive_meaning native_equality_program}"
  let ?f = "\<lambda>t. Pair_Term t t"
  have subset: "?f ` {t. term_formed t} \<subseteq> {t. ((None,[Suc 0]),t) \<in> positive_meaning native_equality_program}"
    using native_equality_holds by auto
  have image_finite: "finite (?f ` {t. term_formed t})" by (rule finite_subset[OF subset finite])
  have injective: "inj_on ?f {t. term_formed t}" by (auto simp: inj_on_def)
  have "finite {t. term_formed t}" by (rule finite_imageD[OF image_finite injective])
  then show False using future_term_domain_is_infinite by blast
qed


section \<open>The same fixed program receives future native calls\<close>

definition equality_query_environment ::
  "factor_term \<Rightarrow> local_address option artifact_environment" where
  "equality_query_environment t = call_environment equality_artifact [Suc 0] t"

lemma equality_definition_anchor:
  "anchor_formed (equality_artifact,[Suc 0])"
  using equality_artifact_formed by (simp add: anchor_formed_def)

lemma equality_query_environment_formed:
  assumes "term_formed t"
  shows "environment_formed (equality_query_environment t)"
  unfolding equality_query_environment_def
  by (rule call_environment_formed[OF equality_definition_anchor assms])

lemma equality_query_includes_program:
  "environment_included equality_environment (equality_query_environment t)"
  unfolding equality_environment_def equality_query_environment_def by (rule call_environment_extends_target)

lemma equality_query_program:
  assumes "term_formed t"
  shows "native_package_at (equality_query_environment t) None [0] native_equality_program"
  by (rule native_package_included[OF native_equality_package equality_query_includes_program
        equality_query_environment_formed[OF assms]])

lemma equality_query_application:
  assumes "term_formed t"
  shows "\<exists>I K. native_application_at (equality_query_environment t) (Some []) [] (None,[Suc 0]) t I K"
  using native_application_representation[OF equality_definition_anchor assms]
  unfolding equality_query_environment_def by blast

theorem native_equality_future_application_formed:
  assumes formed: "term_formed t"
  shows "native_application_formed (equality_query_environment t) None [0] (Some []) []"
proof -
  have package: "native_package_at (equality_query_environment t) None [0] native_equality_program"
    by (rule equality_query_program[OF formed])
  obtain I K where app: "native_application_at (equality_query_environment t) (Some []) [] (None,[Suc 0]) t I K"
    using equality_query_application[OF formed] by blast
  have call: "schema_call_formed native_equality_program (None,[Suc 0]) t"
    using formed native_equality_system_formed by (simp add: schema_call_formed_def native_equality_program_def)
  show ?thesis using package app call unfolding native_application_formed_def by blast
qed

theorem native_equality_future_truth:
  assumes formed: "term_formed t"
  shows "native_positive_holds (equality_query_environment t) None [0] (Some []) [] \<longleftrightarrow>
    (\<exists>x. term_formed x \<and> t = Pair_Term x x)"
proof -
  have package: "native_package_at (equality_query_environment t) None [0] native_equality_program"
    by (rule equality_query_program[OF formed])
  obtain I K where app: "native_application_at (equality_query_environment t) (Some []) [] (None,[Suc 0]) t I K"
    using equality_query_application[OF formed] by blast
  show ?thesis by (simp only: native_positive_holds_with_reads[OF package app] native_equality_exact)
qed

corollary native_equality_of_future_terms:
  assumes "term_formed x" "term_formed y"
  shows "native_positive_holds (equality_query_environment (Pair_Term x y)) None [0] (Some []) [] \<longleftrightarrow> x = y"
proof -
  have formed: "term_formed (Pair_Term x y)" using assms by simp
  show ?thesis using native_equality_future_truth[OF formed] assms by auto
qed

lemma equality_future_calls_injective:
  assumes tf: "term_formed t" and sf: "term_formed s"
    and same: "equality_query_environment t = equality_query_environment s"
  shows "t = s"
proof -
  obtain I K where left: "native_application_at (equality_query_environment t) (Some []) [] (None,[Suc 0]) t I K"
    using equality_query_application[OF tf] by blast
  obtain J W where right: "native_application_at (equality_query_environment s) (Some []) [] (None,[Suc 0]) s J W"
    using equality_query_application[OF sf] by blast
  have other: "native_application_at (equality_query_environment t) (Some []) [] (None,[Suc 0]) s J W"
    using right same by simp
  show ?thesis using native_application_unique[OF left other] by blast
qed


theorem equality_future_program_environment_unchanged:
  assumes formed: "term_formed t"
  shows "native_package_environment (equality_query_environment t) None [0] = equality_environment"
proof -
  let ?F = "equality_query_environment t"
  let ?P = "native_package_environment ?F None [0]"
  have package: "native_package_at ?F None [0] native_equality_program" by (rule equality_query_program[OF formed])
  have upper: "environment_included ?P equality_environment"
    by (rule native_package_dependency_material_required[OF package native_equality_package equality_query_includes_program])
  have source: "None \<in> native_package_sources ?F None [0]" by (simp add: native_package_sources_def)
  have art: "artifact_at ?F None equality_artifact" unfolding equality_query_environment_def by (rule call_environment_target)
  have retained: "artifact_at ?P None equality_artifact"
    using art by (simp only: native_package_environment_sources[OF source])
  have lower: "environment_included equality_environment ?P"
    using retained by (auto simp: equality_environment_def literal_environment_def rel_dom_def
        environment_included_def artifact_at_def)
  show ?thesis by (rule environment_included_antisym[OF upper lower])
qed

theorem native_equality_has_infinite_future_calls:
  "infinite (equality_query_environment ` {t. term_formed t})"
proof
  assume finite: "finite (equality_query_environment ` {t. term_formed t})"
  have injective: "inj_on equality_query_environment {t. term_formed t}"
    by (rule inj_onI) (auto intro: equality_future_calls_injective)
  have "finite {t. term_formed t}" by (rule finite_imageD[OF finite injective])
  then show False using future_term_domain_is_infinite by blast
qed

text \<open>
  The small addresses in this construction select witness coordinates. No
  reader tests their bytes. The root family cites one definition with a scoped
  variable interface and a one-clause family. Its clause declares one binder,
  uses it twice in the conclusion pair, and has an empty premise family.
\<close>

end
