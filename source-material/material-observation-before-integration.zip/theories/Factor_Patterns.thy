theory Factor_Patterns
  imports Factor_Term_Encoding
begin

section \<open>Binder occurrences declared by a complete family\<close>

definition binder_scope_at :: "exact_artifact \<Rightarrow> local_address \<Rightarrow> local_address set \<Rightarrow> bool" where
  "binder_scope_at R b V \<longleftrightarrow> family_at R b ((\<lambda>a. (a,a)) ` V)"

lemma binder_scope_unique:
  assumes "binder_scope_at R b V" "binder_scope_at R b W"
  shows "V = W"
proof -
  have first: "family_at R b ((\<lambda>a. (a,a)) ` V)"
    and second: "family_at R b ((\<lambda>a. (a,a)) ` W)"
    using assms by (simp_all add: binder_scope_at_def)
  have same: "(\<lambda>a. (a,a)) ` V = (\<lambda>a. (a,a)) ` W"
    by (rule family_at_unique[OF first second])
  show ?thesis using same by auto
qed

lemma binder_scope_properties:
  assumes "binder_scope_at R b V"
  shows "finite V" "V \<subseteq> rra_carrier (object_structure R)" "b \<notin> V"
    "\<forall>a\<in>V. headed_incidence (object_structure R) a = {}"
    "restrict_basis (insert b V) (object_data R) = empty_basis"
proof -
  have family: "family_at R b ((\<lambda>a. (a,a)) ` V)"
    using assms by (simp add: binder_scope_at_def)
  have dom: "rel_dom ((\<lambda>a. (a,a)) ` V) = V" by (auto simp: rel_dom_def)
  show "finite V" using finite_rel_dom[OF family_socket_graph_finite[OF family]] dom by simp
  have sf: "rra_formed (object_structure R)"
    using family by (simp add: family_at_def object_formed_def)
  have range: "snd ` headed_incidence (object_structure R) b = V"
    using family by (auto simp: family_at_def image_image)
  show "V \<subseteq> rra_carrier (object_structure R)"
    using headed_targets_in_carrier[OF sf, of b] range by simp
  show "b \<notin> V" "\<forall>a\<in>V. headed_incidence (object_structure R) a = {}"
    "restrict_basis (insert b V) (object_data R) = empty_basis"
    using family dom by (auto simp: family_at_def)
qed

lemma binder_scope_push:
  assumes "binder_scope_at R b V" "inj_on f (rra_carrier (object_structure R))"
  shows "binder_scope_at (push_object f R) (f b) (f ` V)"
proof -
  have source: "family_at R b ((\<lambda>a. (a,a)) ` V)" using assms(1) by (simp add: binder_scope_at_def)
  have target: "family_at (push_object f R) (f b)
    ((\<lambda>(p,x). (f p,f x)) ` ((\<lambda>a. (a,a)) ` V))"
    by (rule family_at_push[OF source assms(2)])
  show ?thesis using target by (simp add: binder_scope_at_def image_image)
qed

section \<open>Pattern quotation relative to a declared binder scope\<close>

inductive pattern_quoted_at ::
  "'u artifact_environment \<Rightarrow> 'u \<Rightarrow> local_address set \<Rightarrow> local_address \<Rightarrow>
    local_address term_pattern \<Rightarrow> local_address set \<Rightarrow> local_address set \<Rightarrow> bool"
  for E u V where
  variable:
    "environment_formed E \<Longrightarrow> artifact_at E u R \<Longrightarrow>
     citation_at R r (Local a) I \<Longrightarrow> a \<in> V \<Longrightarrow> I \<inter> V = {} \<Longrightarrow>
     pattern_quoted_at E u V r (Pattern_Variable a) I {}"
| target:
    "term_quoted_at E u r (Target_Term t) I K \<Longrightarrow> I \<inter> V = {} \<Longrightarrow>
     pattern_quoted_at E u V r (Pattern_Target t) I K"
| pair:
    "environment_formed E \<Longrightarrow> artifact_at E u R \<Longrightarrow>
     record_at R r ps [l,q] \<Longrightarrow>
     pattern_quoted_at E u V l p L A \<Longrightarrow> pattern_quoted_at E u V q s Q B \<Longrightarrow>
     insert r (set ps) \<inter> (L \<union> Q) = {} \<Longrightarrow> L \<inter> Q = {} \<Longrightarrow>
     insert r (set ps \<union> L \<union> Q) \<inter> (A \<union> B \<union> V) = {} \<Longrightarrow>
     pattern_quoted_at E u V r (Pattern_Pair p s) (insert r (set ps \<union> L \<union> Q)) (A \<union> B)"
| payload:
    "term_quoted_at E u r (Payload_Term v) I K \<Longrightarrow> I \<inter> V = {} \<Longrightarrow>
     pattern_quoted_at E u V r (Pattern_Payload v) I K"

lemma pattern_quoted_formed:
  assumes "pattern_quoted_at E u V r p I K"
  shows "environment_formed E \<and> pattern_formed p \<and> pattern_variables p \<subseteq> V"
  using assms by (induction rule: pattern_quoted_at.induct)
    (auto dest: term_quoted_environment_formed term_quoted_formed)

lemma pattern_quoted_boundary:
  assumes "pattern_quoted_at E u V r p I K"
  shows "r \<in> I \<and> finite I \<and> finite K \<and> I \<inter> (K \<union> V) = {}"
  using assms
  by (induction rule: pattern_quoted_at.induct)
     (auto simp: citation_at_def dest: raw_citation_interior term_quoted_root_interior
       term_quoted_finite term_quoted_slots_outside)

lemma pattern_quoted_carrier:
  assumes quote: "pattern_quoted_at E u V r p I K" and art: "artifact_at E u R"
  shows "I \<union> K \<union> pattern_variables p \<subseteq> rra_carrier (object_structure R)"
  using quote art
proof (induction rule: pattern_quoted_at.induct)
  case (variable S r a I)
  have same: "S = R" by (rule environment_artifact_unique[OF variable.hyps(1,2) variable.prems])
  have interior: "I \<subseteq> rra_carrier (object_structure R)"
    using citation_interior_in_carrier[OF variable.hyps(3)] same by simp
  have raw: "raw_citation_at R r (Local a) I" and sf: "rra_formed (object_structure R)"
    using variable.hyps(3) same
    by (auto simp: citation_at_def exact_formed_def object_formed_def)
  have head: "headed_incidence (object_structure R) r = {(r,a)}"
    using raw by (cases rule: raw_citation_at.cases) auto
  have target: "a \<in> rra_carrier (object_structure R)"
    using headed_targets_in_carrier[OF sf, of r] head by simp
  show ?case using interior target by simp
next
  case (target r t I K)
  show ?case using term_quoted_carrier[OF target.hyps(1) target.prems] by simp
next
  case (pair S r ps l q p L A s Q B)
  have same: "S = R" by (rule environment_artifact_unique[OF pair.hyps(1,2) pair.prems])
  have rec: "insert r (set ps) \<subseteq> rra_carrier (object_structure R)"
    using record_interior_in_carrier[OF pair.hyps(3)] same by simp
  have left: "L \<union> A \<union> pattern_variables p \<subseteq> rra_carrier (object_structure R)"
    by (rule pair.IH(1)[OF pair.prems])
  have right: "Q \<union> B \<union> pattern_variables s \<subseteq> rra_carrier (object_structure R)"
    by (rule pair.IH(2)[OF pair.prems])
  show ?case using rec left right by auto
next
  case (payload r v I K)
  show ?case using term_quoted_carrier[OF payload.hyps(1) payload.prems] by simp
qed

lemma target_quotation_has_external_citation:
  assumes quote: "term_quoted_at E u r (Target_Term t) I K" and art: "artifact_at E u R"
  shows "\<exists>c. citation_at R r c I \<and> citation_slots c = K \<and> K \<noteq> {} \<and> interpret_citation E u c t"
proof -
  have ef: "environment_formed E" by (rule term_quoted_environment_formed[OF quote])
  have same: "\<And>S. artifact_at E u S \<Longrightarrow> S = R"
    by (rule environment_artifact_unique[OF ef _ art])
  show ?thesis using quote by (cases rule: term_quoted_at.cases) (auto dest!: same)
qed

lemma pattern_with_local_citation:
  assumes ef: "environment_formed E" and art: "artifact_at E u R"
    and cite: "citation_at R r (Local a) C" and quote: "pattern_quoted_at E u V r p I K"
  shows "p = Pattern_Variable a \<and> I = C \<and> K = {}"
proof -
  have same_artifact: "\<And>S. artifact_at E u S \<Longrightarrow> S = R"
    by (rule environment_artifact_unique[OF ef _ art])
  have same_citation: "\<And>b J. citation_at R r (Local b) J \<Longrightarrow> b = a \<and> J = C"
    using citation_at_unique[OF _ cite] by auto
  have no_target: "\<And>t J W. term_quoted_at E u r (Target_Term t) J W \<Longrightarrow> False"
    using term_quoted_with_citation[OF ef art cite] by auto
  have no_payload: "\<And>v J W. term_quoted_at E u r (Payload_Term v) J W \<Longrightarrow> False"
    using term_quoted_with_citation[OF ef art cite] by auto
  have no_pair: "\<And>ps l q. record_at R r ps [l,q] \<Longrightarrow> False"
    by (rule citation_pair_record_disjoint[OF cite])
  show ?thesis using quote by (cases rule: pattern_quoted_at.cases)
    (auto dest!: same_artifact same_citation no_target no_pair no_payload)
qed

lemma pattern_with_external_citation:
  assumes ef: "environment_formed E" and art: "artifact_at E u R"
    and cite: "citation_at R r c C" and external: "citation_slots c \<noteq> {}"
    and quote: "pattern_quoted_at E u V r p I K"
  shows "\<exists>t. p = Pattern_Target t \<and> I = C \<and> K = citation_slots c \<and> interpret_citation E u c t"
proof -
  have same_artifact: "\<And>S. artifact_at E u S \<Longrightarrow> S = R"
    by (rule environment_artifact_unique[OF ef _ art])
  have no_variable: "\<And>a J. citation_at R r (Local a) J \<Longrightarrow> False"
    using citation_at_unique(1)[OF _ cite] external by force
  have no_pair: "\<And>ps l q. record_at R r ps [l,q] \<Longrightarrow> False"
    by (rule citation_pair_record_disjoint[OF cite])
  have no_payload: "\<And>v J W. term_quoted_at E u r (Payload_Term v) J W \<Longrightarrow> False"
    using term_quoted_with_citation[OF ef art cite] by auto
  have leaf: "\<And>t J W. term_quoted_at E u r (Target_Term t) J W \<Longrightarrow>
    J = C \<and> W = citation_slots c \<and> interpret_citation E u c t"
    using term_quoted_with_citation[OF ef art cite] by auto
  show ?thesis using quote by (cases rule: pattern_quoted_at.cases)
    (auto dest!: same_artifact no_variable no_pair no_payload leaf)
qed

lemma pattern_with_pair_record:
  assumes ef: "environment_formed E" and art: "artifact_at E u R"
    and rec: "record_at R r ps [l,q]" and quote: "pattern_quoted_at E u V r p I K"
  shows "\<exists>x y L A Q B. p = Pattern_Pair x y \<and>
    pattern_quoted_at E u V l x L A \<and> pattern_quoted_at E u V q y Q B \<and>
    I = insert r (set ps \<union> L \<union> Q) \<and> K = A \<union> B"
proof -
  have same_artifact: "\<And>S. artifact_at E u S \<Longrightarrow> S = R"
    by (rule environment_artifact_unique[OF ef _ art])
  have same_record: "\<And>qs a b. record_at R r qs [a,b] \<Longrightarrow> qs = ps \<and> a = l \<and> b = q"
    using record_at_unique[OF _ rec] by auto
  have no_citation: "\<And>c C. citation_at R r c C \<Longrightarrow> False"
    by (rule citation_pair_record_disjoint[OF _ rec])
  have no_target: "\<And>t J W. term_quoted_at E u r (Target_Term t) J W \<Longrightarrow> False"
    using term_quoted_with_pair_record[OF ef art rec] by auto
  have no_payload: "\<And>v J W. term_quoted_at E u r (Payload_Term v) J W \<Longrightarrow> False"
    using term_quoted_with_pair_record[OF ef art rec] by auto
  show ?thesis using quote by (cases rule: pattern_quoted_at.cases)
    (auto dest!: same_artifact same_record no_citation no_target no_payload)
qed

lemma pattern_with_payload:
  assumes ef: "environment_formed E" and art: "artifact_at E u R"
    and leaf: "payload_leaf_at R r v" and quote: "pattern_quoted_at E u V r p I K"
  shows "p = Pattern_Payload v \<and> I = {r} \<and> K = {}"
proof -
  have same_artifact: "\<And>S. artifact_at E u S \<Longrightarrow> S = R"
    by (rule environment_artifact_unique[OF ef _ art])
  have no_citation: "\<And>c C. citation_at R r c C \<Longrightarrow> False"
    by (rule payload_leaf_citation_disjoint[OF leaf])
  have no_record: "\<And>ps xs. record_at R r ps xs \<Longrightarrow> False"
    by (rule payload_leaf_record_disjoint[OF leaf])
  have terms: "\<And>t J W. term_quoted_at E u r t J W \<Longrightarrow> t = Payload_Term v \<and> J = {r} \<and> W = {}"
    by (rule term_quoted_with_payload[OF ef art leaf])
  show ?thesis using quote by (cases rule: pattern_quoted_at.cases)
    (auto dest!: same_artifact no_citation no_record terms)
qed

theorem pattern_quoted_unique:
  assumes first: "pattern_quoted_at E u V r p I K" and second: "pattern_quoted_at E u V r q J W"
  shows "p = q \<and> I = J \<and> K = W"
  using first second
proof (induction arbitrary: q J W rule: pattern_quoted_at.induct)
  case (variable R r a I)
  show ?case using pattern_with_local_citation[OF variable.hyps(1-3) variable.prems] by auto
next
  case (target r t I K)
  have ef: "environment_formed E" by (rule term_quoted_environment_formed[OF target.hyps(1)])
  obtain R where art: "artifact_at E u R" using term_quoted_has_artifact[OF target.hyps(1)] by blast
  obtain c where cite: "citation_at R r c I" and slots: "citation_slots c = K" "K \<noteq> {}"
    and interpreted: "interpret_citation E u c t"
    using target_quotation_has_external_citation[OF target.hyps(1) art] by blast
  have external: "citation_slots c \<noteq> {}" using slots by simp
  obtain s where other: "q = Pattern_Target s" "J = I" "W = citation_slots c"
    "interpret_citation E u c s"
    using pattern_with_external_citation[OF ef art cite external target.prems] by blast
  have same: "t = s" by (rule citation_interpretation_functional[OF ef interpreted other(4)])
  show ?case using same other slots by simp
next
  case (pair R r ps l a p L A s Q B)
  obtain x y L' A' Q' B' where other: "q = Pattern_Pair x y"
    "J = insert r (set ps \<union> L' \<union> Q')" "W = A' \<union> B'"
    and left: "pattern_quoted_at E u V l x L' A'" and right: "pattern_quoted_at E u V a y Q' B'"
    using pattern_with_pair_record[OF pair.hyps(1-3) pair.prems] by blast
  have first: "p = x \<and> L = L' \<and> A = A'" by (rule pair.IH(1)[OF left])
  have second: "s = y \<and> Q = Q' \<and> B = B'" by (rule pair.IH(2)[OF right])
  show ?case using first second other by simp
next
  case (payload r v I K)
  have ef: "environment_formed E" by (rule term_quoted_environment_formed[OF payload.hyps(1)])
  obtain R where art: "artifact_at E u R" using term_quoted_has_artifact[OF payload.hyps(1)] by blast
  have leaf: "payload_leaf_at R r v" and boundary: "I = {r}" "K = {}"
    using payload_quotation_has_leaf[OF payload.hyps(1) art] by auto
  show ?case using pattern_with_payload[OF ef art leaf payload.prems] boundary by auto
qed

theorem pattern_quotation_transport:
  assumes quote: "pattern_quoted_at E u V r p I K" and source: "artifact_at E u R"
    and addressing: "finite_addressing (rra_carrier (object_structure R)) f"
    and reads: "object_reads_agree (push_object f R) S (f ` I)"
    and slots: "\<forall>k\<in>K. external_slot_values E u k = external_slot_values F w (f k)"
    and injective: "inj f" and ff: "environment_formed F" and destination: "artifact_at F w S"
  shows "pattern_quoted_at F w (f ` V) (f r) (rename_pattern f p) (f ` I) (f ` K)"
  using quote source addressing reads slots
proof (induction arbitrary: R rule: pattern_quoted_at.induct)
  case (variable T r a I)
  have same: "T = R" by (rule environment_artifact_unique[OF variable.hyps(1,2) variable.prems(1)])
  have cite: "citation_at R r (Local a) I" using variable.hyps(3) same by simp
  have copied: "citation_at (push_object f R) (f r) (Local (f a)) (f ` I)"
    using citation_at_push[OF cite variable.prems(2)] by simp
  have formed: "exact_formed S" using ff destination unfolding environment_formed_def by blast
  have recovered: "citation_at S (f r) (Local (f a)) (f ` I)"
    by (rule citation_at_read_transport[OF copied formed variable.prems(3)])
  have member: "f a \<in> f ` V" using variable.hyps(4) by simp
  have separate: "f ` I \<inter> f ` V = {}" using image_Int[OF injective, of I V] variable.hyps(5) by simp
  have "pattern_quoted_at F w (f ` V) (f r) (Pattern_Variable (f a)) (f ` I) {}"
    by (rule pattern_quoted_at.variable[OF ff destination recovered member separate])
  then show ?case by (simp add: rename_pattern_def)
next
  case (target r t I K)
  have copied: "term_quoted_at F w (f r) (Target_Term t) (f ` I) (f ` K)"
    by (rule term_quotation_transport[OF target.hyps(1) target.prems ff destination])
  have separate: "f ` I \<inter> f ` V = {}" using image_Int[OF injective, of I V] target.hyps(2) by simp
  have "pattern_quoted_at F w (f ` V) (f r) (Pattern_Target t) (f ` I) (f ` K)"
    by (rule pattern_quoted_at.target[OF copied separate])
  then show ?case by (simp add: rename_pattern_def)
next
  case (pair T r ps l q p L A s Q B)
  let ?J = "insert r (set ps \<union> L \<union> Q)"
  have same: "T = R" by (rule environment_artifact_unique[OF pair.hyps(1,2) pair.prems(1)])
  have rec: "record_at R r ps [l,q]" using pair.hyps(3) same by simp
  have local_inj: "inj_on f (rra_carrier (object_structure R))" using injective by (auto simp: inj_on_def)
  have copied: "record_at (push_object f R) (f r) (map f ps) [f l,f q]"
    using record_at_push[OF rec local_inj] by simp
  have formed: "object_formed S"
    using ff destination by (auto simp: environment_formed_def exact_formed_def)
  have recovered: "record_at S (f r) (map f ps) [f l,f q]"
    by (rule record_at_read_transport[OF copied formed pair.prems(3)]) auto
  have left_reads: "object_reads_agree (push_object f R) S (f ` L)"
    by (rule object_reads_agree_mono[OF pair.prems(3)]) blast
  have right_reads: "object_reads_agree (push_object f R) S (f ` Q)"
    by (rule object_reads_agree_mono[OF pair.prems(3)]) blast
  have left_slots: "\<forall>k\<in>A. external_slot_values E u k = external_slot_values F w (f k)"
    using pair.prems(4) by blast
  have right_slots: "\<forall>k\<in>B. external_slot_values E u k = external_slot_values F w (f k)"
    using pair.prems(4) by blast
  have left: "pattern_quoted_at F w (f ` V) (f l) (rename_pattern f p) (f ` L) (f ` A)"
    by (rule pair.IH(1)[OF pair.prems(1,2) left_reads left_slots])
  have right: "pattern_quoted_at F w (f ` V) (f q) (rename_pattern f s) (f ` Q) (f ` B)"
    by (rule pair.IH(2)[OF pair.prems(1,2) right_reads right_slots])
  have rec_children: "f ` insert r (set ps) \<inter> f ` (L \<union> Q) = {}"
    using image_Int[OF injective, of "insert r (set ps)" "L \<union> Q"] pair.hyps(6) by simp
  have children: "f ` L \<inter> f ` Q = {}"
    using image_Int[OF injective, of L Q] pair.hyps(7) by simp
  have boundary: "f ` ?J \<inter> f ` (A \<union> B \<union> V) = {}"
    using image_Int[OF injective, of ?J "A \<union> B \<union> V"] pair.hyps(8) by simp
  have "pattern_quoted_at F w (f ` V) (f r) (Pattern_Pair (rename_pattern f p) (rename_pattern f s))
    (insert (f r) (set (map f ps) \<union> f ` L \<union> f ` Q)) (f ` A \<union> f ` B)"
    by (rule pattern_quoted_at.pair[OF ff destination recovered left right])
       (use rec_children children boundary in \<open>simp_all add: image_Un\<close>)
  then show ?case by (simp add: rename_pattern_def image_Un)
next
  case (payload r v I K)
  have copied: "term_quoted_at F w (f r) (Payload_Term v) (f ` I) (f ` K)"
    by (rule term_quotation_transport[OF payload.hyps(1) payload.prems ff destination])
  have separate: "f ` I \<inter> f ` V = {}"
    using image_Int[OF injective, of I V] payload.hyps(2) by simp
  have "pattern_quoted_at F w (f ` V) (f r) (Pattern_Payload v) (f ` I) (f ` K)"
    by (rule pattern_quoted_at.payload[OF copied separate])
  then show ?case by simp
qed

lemma pattern_quotation_embedding:
  assumes quote: "pattern_quoted_at E u V r p I K" and source: "artifact_at E u R"
    and reads: "object_reads_agree R S I"
    and slots: "\<forall>k\<in>K. external_slot_values E u k = external_slot_values F w k"
    and ff: "environment_formed F" and destination: "artifact_at F w S"
  shows "pattern_quoted_at F w V r p I K"
proof -
  have ef: "environment_formed E" using pattern_quoted_formed[OF quote] by blast
  have rf: "exact_formed R" using ef source unfolding environment_formed_def by blast
  have oformed: "object_formed R" using rf by (simp add: exact_formed_def)
  have address: "finite_addressing (rra_carrier (object_structure R)) id"
    using rf by (auto simp: exact_formed_def finite_addressing_def inj_on_def)
  have copied: "object_reads_agree (push_object id R) S (id ` I)"
    using reads push_object_identity[OF oformed] by simp
  have agreement: "\<forall>k\<in>K. external_slot_values E u k = external_slot_values F w (id k)"
    using slots by simp
  have inj: "inj id" by simp
  have result: "pattern_quoted_at F w (id ` V) (id r) (rename_pattern id p) (id ` I) (id ` K)"
    by (rule pattern_quotation_transport[OF quote source address copied agreement inj ff destination])
  show ?thesis using result by (simp add: rename_pattern_def)
qed

text \<open>
  Local citation endpoints identify declared binder occurrences. External
  citations supply exact target constants, and payload leaves supply opaque
  constants from the data basis. Ordered records pair patterns. The scope
  is an explicit family whose binder occurrences have no headed incidence or
  data; the syntax interior is disjoint from those occurrences.

  These relations recover patterns and their variable use. An enclosing schema
  must recover its scope root and require that its complete fields use exactly
  that scope. This relative reader does not supply such a schema implicitly.
\<close>

end
