theory Factor_Positive_Locality
  imports Factor_Positive_Meaning
begin

section \<open>Agreement on a complete definition dependency boundary\<close>

definition systems_agree_on ::
  "('a,'s,'d,'c) schema_system \<Rightarrow> ('a,'s,'d,'c) schema_system \<Rightarrow> 'd set \<Rightarrow> bool" where
  "systems_agree_on P T U \<longleftrightarrow>
    (\<forall>d\<in>U. \<forall>p. (d,p) \<in> system_interfaces P \<longleftrightarrow> (d,p) \<in> system_interfaces T) \<and>
    (\<forall>d\<in>U. \<forall>c S. ((d,c),S) \<in> system_clauses P \<longleftrightarrow> ((d,c),S) \<in> system_clauses T)"

definition system_dependency_closed ::
  "('a,'s,'d,'c) schema_system \<Rightarrow> 'd set \<Rightarrow> bool" where
  "system_dependency_closed P U \<longleftrightarrow>
    (\<forall>d\<in>U. \<forall>e. (d,e) \<in> system_dependency_edges P \<longrightarrow> e \<in> U)"

lemma systems_agree_on_sym:
  assumes "systems_agree_on P T U"
  shows "systems_agree_on T P U"
  using assms by (auto simp: systems_agree_on_def)

lemma systems_agree_on_dependencies:
  assumes agree: "systems_agree_on P T U" and member: "d \<in> U"
  shows "(d,e) \<in> system_dependency_edges P \<longleftrightarrow> (d,e) \<in> system_dependency_edges T"
  using agree member by (auto simp: systems_agree_on_def system_dependency_edges_def; blast)

lemma systems_agree_on_closed:
  assumes agree: "systems_agree_on P T U" and closed: "system_dependency_closed P U"
  shows "system_dependency_closed T U"
  using systems_agree_on_dependencies[OF agree] closed by (auto simp: system_dependency_closed_def)

lemma schema_call_agreement:
  assumes pf: "schema_system_formed P" and tf: "schema_system_formed T"
    and agree: "systems_agree_on P T U" and member: "d \<in> U"
  shows "schema_call_formed P d t \<longleftrightarrow> schema_call_formed T d t"
  using pf tf agree member by (auto simp: schema_call_formed_def systems_agree_on_def; blast)

lemma admitted_instance_dependencies:
  assumes inst: "admitted_schema_instance P d c V t Q" and member: "(s,e,x) \<in> Q"
  shows "(d,e) \<in> system_dependency_edges P"
proof -
  obtain S where clause: "((d,c),S) \<in> system_clauses P" and schema: "schema_instance S V t Q"
    using inst by (auto simp: admitted_schema_instance_def)
  have target: "e \<in> fst ` rel_ran Q" using member by (auto simp: rel_ran_def intro: rev_image_eqI)
  have dep: "e \<in> schema_dependencies S" using target schema_instance_target_boundary[OF schema] by simp
  show ?thesis using clause dep unfolding system_dependency_edges_def by blast
qed

lemma admitted_instance_inside:
  assumes closed: "system_dependency_closed P U" and root: "d \<in> U"
    and inst: "admitted_schema_instance P d c V t Q"
  shows "\<forall>s e x. (s,e,x) \<in> Q \<longrightarrow> e \<in> U"
  using closed root admitted_instance_dependencies[OF inst]
  by (auto simp: system_dependency_closed_def)

lemma admitted_instance_transport:
  assumes pf: "schema_system_formed P" and tf: "schema_system_formed T"
    and agree: "systems_agree_on P T U" and closed: "system_dependency_closed P U"
    and root: "d \<in> U" and inst: "admitted_schema_instance P d c V t Q"
  shows "admitted_schema_instance T d c V t Q"
proof -
  have head: "schema_call_formed P d t" using inst by (simp add: admitted_schema_instance_def)
  have transported_head: "schema_call_formed T d t"
    using schema_call_agreement[OF pf tf agree root] head by simp
  obtain S where clause: "((d,c),S) \<in> system_clauses P" and schema: "schema_instance S V t Q"
    using inst by (auto simp: admitted_schema_instance_def)
  have transported_clause: "((d,c),S) \<in> system_clauses T"
    using clause agree root by (auto simp: systems_agree_on_def)
  have inside: "\<forall>s e x. (s,e,x) \<in> Q \<longrightarrow> e \<in> U"
    by (rule admitted_instance_inside[OF closed root inst])
  have calls: "\<forall>s e x. (s,e,x) \<in> Q \<longrightarrow> schema_call_formed T e x"
  proof (intro allI impI)
    fix s e x assume member: "(s,e,x) \<in> Q"
    have e: "e \<in> U" using inside member by blast
    have source: "schema_call_formed P e x" using inst member by (auto simp: admitted_schema_instance_def)
    show "schema_call_formed T e x" using schema_call_agreement[OF pf tf agree e] source by simp
  qed
  show ?thesis using transported_head transported_clause schema calls
    unfolding admitted_schema_instance_def by blast
qed

theorem positive_meaning_local_inclusion:
  assumes pf: "schema_system_formed P" and tf: "schema_system_formed T"
    and agree: "systems_agree_on P T U" and closed: "system_dependency_closed P U"
    and root: "d \<in> U" and holds: "(d,t) \<in> positive_meaning P"
  shows "(d,t) \<in> positive_meaning T"
proof -
  let ?X = "{(d,t). d \<in> U \<longrightarrow> (d,t) \<in> positive_meaning T}"
  have stable: "schema_consequences P ?X \<subseteq> ?X"
  proof
    fix call assume step: "call \<in> schema_consequences P ?X"
    obtain d t where shape: "call = (d,t)" by (cases call)
    obtain c V Q where inst: "admitted_schema_instance P d c V t Q"
      and support: "\<forall>s e x. (s,e,x) \<in> Q \<longrightarrow> (e,x) \<in> ?X"
      using step by (auto simp: shape schema_consequences_def)
    show "call \<in> ?X"
    proof (cases "d \<in> U")
      case False
      then show ?thesis by (simp add: shape)
    next
      case True
      have transported: "admitted_schema_instance T d c V t Q"
        by (rule admitted_instance_transport[OF pf tf agree closed True inst])
      have inside: "\<forall>s e x. (s,e,x) \<in> Q \<longrightarrow> e \<in> U"
        by (rule admitted_instance_inside[OF closed True inst])
      have children: "\<forall>s e x. (s,e,x) \<in> Q \<longrightarrow> (e,x) \<in> positive_meaning T"
        using support inside by blast
      have result: "(d,t) \<in> positive_meaning T" by (rule positive_meaning_step[OF transported children])
      show ?thesis using result by (simp add: shape)
    qed
  qed
  have included: "positive_meaning P \<subseteq> ?X" by (rule positive_meaning_least[OF stable])
  show ?thesis using included root holds by blast
qed

theorem positive_meaning_dependency_locality:
  assumes pf: "schema_system_formed P" and tf: "schema_system_formed T"
    and agree: "systems_agree_on P T U" and closed: "system_dependency_closed P U"
    and root: "d \<in> U"
  shows "(d,t) \<in> positive_meaning P \<longleftrightarrow> (d,t) \<in> positive_meaning T"
proof
  assume holds: "(d,t) \<in> positive_meaning P"
  show "(d,t) \<in> positive_meaning T"
    by (rule positive_meaning_local_inclusion[OF pf tf agree closed root holds])
next
  assume holds: "(d,t) \<in> positive_meaning T"
  have reverse: "systems_agree_on T P U" by (rule systems_agree_on_sym[OF agree])
  have tclosed: "system_dependency_closed T U" by (rule systems_agree_on_closed[OF agree closed])
  show "(d,t) \<in> positive_meaning P"
    by (rule positive_meaning_local_inclusion[OF tf pf reverse tclosed root holds])
qed

text \<open>
  This locality result fixes the interface and complete clause family at every
  definition in a dependency-closed set. Definitions outside that set may
  change while both systems remain formed. The theorem is about the extension
  of true calls. It grants no weakening or contraction of a context represented
  inside a call's argument term.
\<close>

end

