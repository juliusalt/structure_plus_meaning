theory RRA_Exact
  imports RRA_Footprint
begin

section \<open>Exact addressed artifacts\<close>

type_synonym local_address = octets
type_synonym exact_artifact = "(local_address,octets) structured_object"

lemma basis_values_restrictD:
  assumes "v \<in> basis_values (restrict_basis A D)"
  shows "v \<in> basis_values D"
  using assms basis_values_restrict[of A D] by blast

definition exact_formed :: "exact_artifact \<Rightarrow> bool" where
  "exact_formed R \<longleftrightarrow>
     object_formed R \<and>
     (\<forall>a \<in> rra_carrier (object_structure R). octets_formed a) \<and>
     (\<forall>v \<in> basis_values (object_data R). octets_formed v)"

definition empty_artifact :: exact_artifact where
  "empty_artifact =
    \<lparr>object_structure = \<lparr>rra_carrier = {}, rra_incidence = {}\<rparr>,
     object_data = empty_basis\<rparr>"

lemma empty_artifact_formed [simp]: "exact_formed empty_artifact"
  by (simp add: empty_artifact_def exact_formed_def object_formed_def rra_formed_def)

text \<open>
  Exact artifact identity is ordinary equality of the complete mathematical
  record.  A digest or reference may identify that value externally, but is not
  substituted for it here.
\<close>

lemma exact_identity_iff:
  fixes R R' :: exact_artifact
  shows "R = R' \<longleftrightarrow>
   object_structure R = object_structure R' \<and> object_data R = object_data R'"
  by (cases R; cases R') auto

lemma local_star_does_not_determine_exact_identity:
  "\<exists>R S :: exact_artifact. exact_formed R \<and> exact_formed S \<and>
    footprint_of R {[]} = footprint_of S {[]} \<and>
    [] \<in> rra_carrier (object_structure R) \<and>
    [] \<in> rra_carrier (object_structure S) \<and>
    R \<noteq> S \<and> (R,[]) \<noteq> (S,[])"
proof -
  let ?R = "\<lparr>object_structure = \<lparr>rra_carrier = {[]}, rra_incidence = {}\<rparr>,
    object_data = empty_basis\<rparr> :: exact_artifact"
  let ?S = "\<lparr>object_structure = \<lparr>rra_carrier = {[],[0]}, rra_incidence = {}\<rparr>,
    object_data = empty_basis\<rparr> :: exact_artifact"
  show ?thesis
    by (rule exI[of _ ?R], rule exI[of _ ?S])
       (auto simp: exact_formed_def object_formed_def rra_formed_def octets_formed_def
         basis_values_def basis_formed_def single_valued_def bag_support_def empty_basis_def footprint_of_def Let_def
         touching_incidence_def exact_identity_iff rra_identity)
qed

section \<open>Anchors are values\<close>

type_synonym exact_anchor = "exact_artifact \<times> local_address"

definition anchor_formed :: "exact_anchor \<Rightarrow> bool" where
  "anchor_formed a \<longleftrightarrow>
    exact_formed (fst a) \<and> snd a \<in> rra_carrier (object_structure (fst a))"

lemma empty_artifact_has_no_anchor:
  "\<not> anchor_formed (empty_artifact,a)"
  by (simp add: anchor_formed_def empty_artifact_def)

datatype exact_target =
    Whole_Artifact exact_artifact
  | Occurrence_Anchor exact_anchor

fun target_formed :: "exact_target \<Rightarrow> bool" where
  "target_formed (Whole_Artifact R) = exact_formed R"
| "target_formed (Occurrence_Anchor a) = anchor_formed a"

fun target_artifact :: "exact_target \<Rightarrow> exact_artifact" where
  "target_artifact (Whole_Artifact R) = R"
| "target_artifact (Occurrence_Anchor a) = fst a"

fun target_occurrence :: "exact_target \<Rightarrow> local_address option" where
  "target_occurrence (Whole_Artifact R) = None"
| "target_occurrence (Occurrence_Anchor a) = Some (snd a)"

lemma exact_anchor_identity:
  "(R,a) = (S,b) \<longleftrightarrow> R = S \<and> a = b"
  by simp

lemma exact_target_identity:
  "x = y \<longleftrightarrow>
    target_artifact x = target_artifact y \<and> target_occurrence x = target_occurrence y"
  by (cases x; cases y) auto

lemma target_formed_artifact:
  assumes "target_formed x"
  shows "exact_formed (target_artifact x)"
  using assms by (cases x) (auto simp: anchor_formed_def)

text \<open>
  An occurrence anchor is the complete artifact value paired with one of its
  addresses. A whole-artifact target also denotes the empty artifact, which has
  no occurrence anchor. Neither form contains a retrieval token.
\<close>

section \<open>Concrete local-address realizations\<close>

fun unary_address :: "nat \<Rightarrow> local_address" where
  "unary_address n = replicate n 0 @ [1]"

lemma unary_address_formed:
  "octets_formed (unary_address n)"
  by (auto simp: octets_formed_def)

lemma unary_address_length:
  "length (unary_address n) = Suc n"
  by simp

lemma unary_address_inj:
  "inj unary_address"
proof (rule injI)
  fix m n
  assume "unary_address m = unary_address n"
  then have "length (unary_address m) = length (unary_address n)"
    by simp
  then show "m = n"
    by simp
qed

lemma unary_address_eq_iff [simp]:
  "unary_address m = unary_address n \<longleftrightarrow> m = n"
  using unary_address_inj by (auto simp: inj_def)

definition fresh_address :: "local_address set \<Rightarrow> local_address" where
  "fresh_address A = unary_address (Max (length ` A))"

lemma fresh_address_formed [simp]:
  "octets_formed (fresh_address A)"
  unfolding fresh_address_def by (rule unary_address_formed)

lemma fresh_address_not_in:
  assumes "finite A"
  shows "fresh_address A \<notin> A"
proof
  assume member: "fresh_address A \<in> A"
  have fin: "finite (length ` A)" using assms by simp
  have bound: "length (fresh_address A) \<le> Max (length ` A)"
    by (rule Max_ge[OF fin]) (use member in auto)
  show False using bound by (simp add: fresh_address_def)
qed

fun fresh_addresses :: "local_address set \<Rightarrow> nat \<Rightarrow> local_address list" where
  "fresh_addresses A 0 = []"
| "fresh_addresses A (Suc n) =
    fresh_address A # fresh_addresses (insert (fresh_address A) A) n"

lemma fresh_addresses_length [simp]:
  "length (fresh_addresses A n) = n"
  by (induction n arbitrary: A) auto

lemma fresh_addresses_formed:
  "\<forall>a\<in>set (fresh_addresses A n). octets_formed a"
  by (induction n arbitrary: A) auto

lemma fresh_addresses_disjoint:
  assumes "finite A"
  shows "distinct (fresh_addresses A n) \<and> set (fresh_addresses A n) \<inter> A = {}"
  using assms
proof (induction n arbitrary: A)
  case 0
  then show ?case by simp
next
  case (Suc n)
  have fresh: "fresh_address A \<notin> A" by (rule fresh_address_not_in[OF Suc.prems])
  have tail: "distinct (fresh_addresses (insert (fresh_address A) A) n) \<and>
    set (fresh_addresses (insert (fresh_address A) A) n) \<inter> insert (fresh_address A) A = {}"
    by (rule Suc.IH) (use Suc.prems in simp)
  show ?case using fresh tail by auto
qed

lemma fresh_four_addresses:
  assumes "finite U"
  shows "\<exists>b r p q. distinct [b,r,p,q] \<and> {b,r,p,q} \<inter> U = {} \<and>
    (\<forall>a\<in>{b,r,p,q}. octets_formed a)"
proof -
  let ?b = "fresh_address U"
  let ?r = "fresh_address (insert ?b U)"
  let ?p = "fresh_address (insert ?r (insert ?b U))"
  let ?q = "fresh_address (insert ?p (insert ?r (insert ?b U)))"
  have separate: "distinct (fresh_addresses U 4) \<and> set (fresh_addresses U 4) \<inter> U = {}"
    by (rule fresh_addresses_disjoint[OF assms])
  have formed: "\<forall>a\<in>set (fresh_addresses U 4). octets_formed a" by (rule fresh_addresses_formed)
  have shape: "fresh_addresses U 4 = [?b,?r,?p,?q]" by (simp add: numeral_eq_Suc)
  have result: "distinct [?b,?r,?p,?q] \<and> {?b,?r,?p,?q} \<inter> U = {} \<and>
    (\<forall>a\<in>{?b,?r,?p,?q}. octets_formed a)" using separate formed shape by simp
  show ?thesis by (rule exI[of _ ?b], rule exI[of _ ?r], rule exI[of _ ?p], rule exI[of _ ?q]) (rule result)
qed

definition finite_addressing :: "'a set \<Rightarrow> ('a \<Rightarrow> local_address) \<Rightarrow> bool" where
  "finite_addressing U f \<longleftrightarrow>
     inj_on f U \<and> (\<forall>x \<in> U. octets_formed (f x))"

lemma finite_addressing_exists:
  assumes "finite U"
  shows "\<exists>f. finite_addressing U f"
proof -
  obtain g :: "'a \<Rightarrow> nat" where g: "inj_on g U"
    using finite_imp_inj_to_nat_seg[OF assms] by blast
  have i: "inj_on (unary_address \<circ> g) U"
    using g unary_address_inj
    by (auto simp: inj_on_def inj_def)
  have entry: "\<forall>x \<in> U. octets_formed ((unary_address \<circ> g) x)"
    using unary_address_formed by auto
  show ?thesis
    using i entry by (auto simp: finite_addressing_def)
qed

definition exact_realization ::
  "('a \<Rightarrow> local_address) \<Rightarrow> ('a,octets) structured_object \<Rightarrow> exact_artifact \<Rightarrow> bool" where
  "exact_realization f obj R \<longleftrightarrow>
     object_formed obj \<and> exact_formed R \<and>
     finite_addressing (rra_carrier (object_structure obj)) f \<and>
     object_structure R = push_structure f (object_structure obj) \<and>
     object_data R = push_basis (rra_carrier (object_structure obj)) f (object_data obj)"

lemma exact_realization_structure_iso:
  assumes "exact_realization f obj R"
  shows "rra_isomorphism f (object_structure obj) (object_structure R)"
proof -
  from assms have inj: "inj_on f (rra_carrier (object_structure obj))"
    and eq: "object_structure R = push_structure f (object_structure obj)"
    by (auto simp: exact_realization_def finite_addressing_def)
  have source: "rra_formed (object_structure obj)"
    using assms by (simp add: exact_realization_def object_formed_def)
  have "rra_isomorphism f (object_structure obj)
          (push_structure f (object_structure obj))"
    using push_structure_iso[OF source inj] .
  with eq show ?thesis by simp
qed

lemma exact_realization_exists:
  assumes formed: "object_formed obj"
    and vals: "\<forall>v\<in>basis_values (object_data obj). octets_formed v"
  shows "\<exists>f R. exact_realization f obj R"
proof -
  have fin: "finite (rra_carrier (object_structure obj))"
    using formed by (simp add: object_formed_def rra_formed_def)
  obtain f where fa: "finite_addressing (rra_carrier (object_structure obj)) f"
    using finite_addressing_exists[OF fin] by blast
  have compat: "basis_compatible f (object_data obj)"
    by (rule injective_gluing_compatible)
       (use formed fa in \<open>auto simp: object_formed_def finite_addressing_def\<close>)
  have pf: "object_formed (push_object f obj)"
    using push_object_formed_iff[OF formed, where f=f] compat by simp
  have ev: "\<forall>v\<in>basis_values (object_data (push_object f obj)). octets_formed v"
    using vals pushed_basis_values[of "rra_carrier (object_structure obj)" f "object_data obj"]
    by (auto simp: push_object_def)
  have ef: "exact_formed (push_object f obj)"
    using pf fa ev
    by (auto simp: exact_formed_def finite_addressing_def push_object_def push_structure_def)
  show ?thesis
    by (rule exI[of _ f], rule exI[of _ "push_object f obj"])
       (use formed fa ef in \<open>simp add: exact_realization_def push_object_def\<close>)
qed

lemma exact_realization_object_iso:
  assumes "exact_realization f obj R"
  shows "object_isomorphism f obj R"
  using assms exact_realization_structure_iso[OF assms]
  by (simp add: object_isomorphism_def exact_realization_def exact_formed_def push_object_def)

lemma exact_push_formed:
  assumes formed: "exact_formed R"
    and addressing: "finite_addressing (rra_carrier (object_structure R)) f"
  shows "exact_formed (push_object f R)"
proof -
  have source: "object_formed R" using formed by (simp add: exact_formed_def)
  have injective: "inj_on f (rra_carrier (object_structure R))"
    using addressing by (simp add: finite_addressing_def)
  have target: "object_formed (push_object f R)"
    using object_push_isomorphism[OF source injective] by (simp add: object_isomorphism_def)
  have payloads: "\<forall>v\<in>basis_values (object_data (push_object f R)). octets_formed v"
    using formed pushed_basis_values[of "rra_carrier (object_structure R)" f "object_data R"]
    by (auto simp: exact_formed_def push_object_def)
  show ?thesis using target payloads addressing
    by (auto simp: exact_formed_def finite_addressing_def push_object_def)
qed

text \<open>
  The spelling of a local address belongs to exact artifact identity, but has no
  structural meaning.  Any semantic invariance under exact re-addressing must
  be established through the isomorphism just exposed, never by treating two
  exact artifacts as literally equal.
\<close>

end
