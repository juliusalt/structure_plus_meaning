theory RRA_Scope_Construction
  imports RRA_Bound_Syntax_Construction
begin

section \<open>Adding a complete binder family around existing syntax\<close>

definition scope_wrapper ::
  "exact_artifact \<Rightarrow> local_address set \<Rightarrow> local_address \<Rightarrow> local_address \<Rightarrow>
    local_address \<Rightarrow> local_address \<Rightarrow> exact_artifact" where
  "scope_wrapper R V b r p q =
    \<lparr>object_structure =
      \<lparr>rra_carrier = rra_carrier (object_structure R) \<union> {b,r,p,q},
       rra_incidence = rra_incidence (object_structure R) \<union>
         {(r,p,b),(r,q,[]),(p,p,q)} \<union> (\<lambda>a. (b,a,a)) ` V\<rparr>,
     object_data = object_data R\<rparr>"

lemma scope_wrapper_formed:
  assumes formed: "exact_formed R" and root: "[] \<in> rra_carrier (object_structure R)"
    and vars: "V \<subseteq> rra_carrier (object_structure R)"
    and addresses: "\<forall>a\<in>{b,r,p,q}. octets_formed a"
  shows "exact_formed (scope_wrapper R V b r p q)"
proof -
  have sf: "rra_formed (object_structure R)"
    and df: "basis_formed (rra_carrier (object_structure R)) (object_data R)"
    using formed by (auto simp: exact_formed_def object_formed_def)
  have finite: "finite V" by (rule finite_subset[OF vars]) (use sf in \<open>simp add: rra_formed_def\<close>)
  have target_structure: "rra_formed (object_structure (scope_wrapper R V b r p q))"
    using sf root vars finite by (auto simp: scope_wrapper_def rra_formed_def)
  have target_data: "basis_formed (rra_carrier (object_structure (scope_wrapper R V b r p q)))
    (object_data (scope_wrapper R V b r p q))"
    by (simp only: scope_wrapper_def structured_object.select_convs rra_structure.select_convs)
       (rule basis_formed_mono[OF df], auto)
  show ?thesis using formed addresses target_structure target_data
    by (auto simp: exact_formed_def object_formed_def scope_wrapper_def)
qed

lemma scope_wrapper_reads:
  assumes fresh: "{b,r,p,q} \<inter> rra_carrier (object_structure R) = {}"
  shows "object_reads_agree R (scope_wrapper R V b r p q) (rra_carrier (object_structure R))"
  using fresh by (auto simp: object_reads_agree_def scope_wrapper_def headed_incidence_def)

lemma scope_wrapper_head:
  "headed_incidence (object_structure (scope_wrapper R V b r p q)) a =
    headed_incidence (object_structure R) a \<union>
    {(s,x). (a,s,x) \<in> {(r,p,b),(r,q,[]),(p,p,q)}} \<union>
    (if a = b then (\<lambda>x. (x,x)) ` V else {})"
  by (auto simp: scope_wrapper_def headed_incidence_def)

lemma formed_head_outside:
  assumes "object_formed R" "a \<notin> rra_carrier (object_structure R)"
  shows "headed_incidence (object_structure R) a = {}"
  using assms by (auto simp: object_formed_def rra_formed_def headed_incidence_def)

lemma scope_wrapper_record:
  assumes source: "exact_formed R" and target: "exact_formed (scope_wrapper R V b r p q)"
    and separate: "distinct [b,r,p,q]"
    and fresh: "{b,r,p,q} \<inter> rra_carrier (object_structure R) = {}"
  shows "record_at (scope_wrapper R V b r p q) r [p,q] [b,[]]"
proof -
  let ?T = "object_structure (scope_wrapper R V b r p q)"
  have oformed: "object_formed R" and df: "basis_formed (rra_carrier (object_structure R)) (object_data R)"
    using source by (auto simp: exact_formed_def object_formed_def)
  have old_empty: "headed_incidence (object_structure R) r = {}"
    "headed_incidence (object_structure R) p = {}" "headed_incidence (object_structure R) q = {}"
    by (rule formed_head_outside[OF oformed]; use fresh in auto)+
  have heads: "headed_incidence ?T r = {(p,b),(q,[])}"
    "headed_incidence ?T p = {(p,q)}" "headed_incidence ?T q = {}"
    using old_empty separate by (auto simp: scope_wrapper_head)
  have left_field: "field_endpoint ?T r p b" and right_field: "field_endpoint ?T r q []"
    using heads(1) separate by (auto simp: field_endpoint_from_head)
  have last: "record_path ?T r q [q] [[]]"
    by (rule record_path.path_last[OF _ heads(3) right_field]) (use separate in auto)
  have path: "record_path ?T r p [p,q] [b,[]]"
    by (rule record_path.path_slot[OF _ heads(2) left_field last]) (use separate in auto)
  have data: "restrict_basis (insert r (set [p,q])) (object_data R) = empty_basis"
    by (rule empty_restriction_outside[OF df]) (use fresh in auto)
  show ?thesis using target heads(1) path data
    by (simp add: record_at_def raw_record_at_def exact_formed_def scope_wrapper_def)
qed

lemma scope_wrapper_binders:
  assumes source: "exact_formed R" and target: "exact_formed (scope_wrapper R V b r p q)"
    and silent: "binder_silent R" and vars: "V \<subseteq> rra_carrier (object_structure R)" "V \<subseteq> binder_addresses"
    and separate: "distinct [b,r,p,q]"
    and fresh: "{b,r,p,q} \<inter> rra_carrier (object_structure R) = {}"
  shows "family_at (scope_wrapper R V b r p q) b ((\<lambda>a. (a,a)) ` V)"
proof -
  have oformed: "object_formed R" and df: "basis_formed (rra_carrier (object_structure R)) (object_data R)"
    using source by (auto simp: exact_formed_def object_formed_def)
  have old_empty: "headed_incidence (object_structure R) b = {}"
    by (rule formed_head_outside[OF oformed]) (use fresh in auto)
  have head: "headed_incidence (object_structure (scope_wrapper R V b r p q)) b = (\<lambda>a. (a,a)) ` V"
    using old_empty separate by (auto simp: scope_wrapper_head)
  have dom: "rel_dom ((\<lambda>a. (a,a)) ` V) = V" by (auto simp: rel_dom_def)
  have members: "\<forall>a\<in>V. headed_incidence (object_structure (scope_wrapper R V b r p q)) a = {}"
  proof (intro ballI)
    fix a assume member: "a \<in> V"
    have carrier: "a \<in> rra_carrier (object_structure R)" by (rule subsetD[OF vars(1) member])
    have bound: "a \<in> binder_addresses" by (rule subsetD[OF vars(2) member])
    have empty: "headed_incidence (object_structure R) a = {}"
      using silent bound unfolding binder_silent_def by blast
    have same: "headed_incidence (object_structure R) a =
      headed_incidence (object_structure (scope_wrapper R V b r p q)) a"
      using scope_wrapper_reads[OF fresh] carrier unfolding object_reads_agree_def by blast
    show "headed_incidence (object_structure (scope_wrapper R V b r p q)) a = {}"
      using same empty by simp
  qed
  have at_root: "restrict_basis {b} (object_data R) = empty_basis"
    by (rule empty_restriction_outside[OF df]) (use fresh in auto)
  have boundary_data: "restrict_basis binder_addresses (object_data R) = empty_basis"
    using silent by (simp add: binder_silent_def)
  have at_vars: "restrict_basis V (object_data R) = empty_basis"
    by (rule empty_restriction_mono[OF boundary_data vars(2)])
  have data: "restrict_basis (insert b V) (object_data R) = empty_basis"
    using empty_restriction_union[of "{b}" V "object_data R"] at_root at_vars by simp
  show ?thesis using target head dom members data vars(1) fresh
    by (auto simp: family_at_def exact_formed_def scope_wrapper_def single_valued_def)
qed

text \<open>
  The wrapper adds only a two-field record and one complete diagonal binder
  family. All four wrapper positions are chosen fresh when using its recognition
  theorems. Existing data is unchanged, and complete headed reads on the old
  carrier are preserved. The declaration family supplies the variable
  occurrences already reached by local pattern citations.
\<close>

end
