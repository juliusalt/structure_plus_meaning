theory RRA_Syntax_Construction
  imports RRA_Read_Transport
begin

section \<open>Finite packages for external literal slots\<close>

definition literal_environment ::
  "exact_artifact \<Rightarrow> (local_address \<times> exact_artifact) set \<Rightarrow>
    local_address option artifact_environment" where
  "literal_environment R M =
    \<lparr>environment_artifacts = insert (None,R) ((\<lambda>(k,S). (Some k,S)) ` M),
     environment_bindings = (\<lambda>k. ((None,k),Some k)) ` rel_dom M\<rparr>"

lemma literal_environment_artifacts [simp]:
  "artifact_at (literal_environment R M) None S \<longleftrightarrow> S = R"
  "artifact_at (literal_environment R M) (Some k) S \<longleftrightarrow> (k,S) \<in> M"
  by (auto simp: literal_environment_def artifact_at_def)

lemma literal_environment_bindings [simp]:
  "binds_slot (literal_environment R M) None k v \<longleftrightarrow>
    k \<in> rel_dom M \<and> v = Some k"
  "binds_slot (literal_environment R M) (Some l) k v \<longleftrightarrow> False"
  by (auto simp: literal_environment_def binds_slot_def)

lemma literal_environment_uses:
  "environment_uses (literal_environment R M) = insert None (Some ` rel_dom M)"
  by (auto simp: environment_uses_def literal_environment_def rel_dom_def)

lemma literal_environment_formed:
  assumes source: "exact_formed R" and finite: "finite M" and functional: "single_valued M"
    and targets: "\<forall>k S. (k,S) \<in> M \<longrightarrow> exact_formed S"
    and slots: "rel_dom M \<subseteq> rra_carrier (object_structure R)"
  shows "environment_formed (literal_environment R M)"
  using assms finite_rel_dom[OF finite]
  by (auto simp: environment_formed_def literal_environment_def artifact_at_def
      binds_slot_def single_valued_def environment_uses_def rel_dom_def)

lemma literal_environment_slot_values [simp]:
  "external_slot_values (literal_environment R M) None k = {S. (k,S) \<in> M}"
  by (auto simp: external_slot_values_def rel_dom_def)

lemma literal_environment_closed:
  assumes formed: "environment_formed (literal_environment R M)"
  shows "environment_closed (literal_environment R M) {None} ((\<lambda>k. (None,k)) ` rel_dom M)"
proof -
  let ?E = "literal_environment R M"
  have roots: "{None} \<subseteq> environment_uses ?E"
    by (simp add: literal_environment_uses)
  have reached: "environment_reachable ?E {None} \<subseteq> environment_uses ?E"
    by (rule environment_reachable_in_uses[OF formed roots])
  have required: "environment_uses ?E \<subseteq> environment_reachable ?E {None}"
  proof
    fix u assume member: "u \<in> environment_uses ?E"
    show "u \<in> environment_reachable ?E {None}"
    proof (cases u)
      case None
      then show ?thesis by (simp add: environment_reachable_def)
    next
      case (Some k)
      have slot: "k \<in> rel_dom M" using member Some by (auto simp: literal_environment_uses)
      have edge: "(None,Some k) \<in> environment_edges ?E"
        using slot by (auto simp: environment_edges_def)
      have path: "(None,Some k) \<in> (environment_edges ?E)\<^sup>*"
        by (rule r_into_rtrancl[OF edge])
      show ?thesis using Some path by (auto simp: environment_reachable_def)
    qed
  qed
  have demands: "rel_dom (environment_bindings ?E) = (\<lambda>k. (None,k)) ` rel_dom M"
    by (auto simp: literal_environment_def rel_dom_def intro: rev_image_eqI)
  show ?thesis using formed roots reached required demands by (auto simp: environment_closed_def)
qed

section \<open>A direct opaque payload leaf\<close>

definition payload_syntax :: "octets \<Rightarrow> exact_artifact" where
  "payload_syntax v = \<lparr>object_structure = \<lparr>rra_carrier={[]}, rra_incidence={}\<rparr>,
    object_data=\<lparr>bag_count=(\<lambda>_. 0), functional_bindings={([],v)}\<rparr>\<rparr>"

lemma payload_syntax_properties [simp]:
  "rra_carrier (object_structure (payload_syntax v)) = {[]}"
  "rra_incidence (object_structure (payload_syntax v)) = {}"
  "bag_count (object_data (payload_syntax v)) = (\<lambda>_. 0)"
  by (simp_all add: payload_syntax_def)

lemma payload_syntax_formed:
  assumes "octets_formed v"
  shows "exact_formed (payload_syntax v)"
  using assms
  by (auto simp: payload_syntax_def exact_formed_def object_formed_def rra_formed_def
      basis_formed_def basis_values_def bag_support_def single_valued_def octets_formed_def)

lemma payload_syntax_recovers:
  "payload_leaf_at (payload_syntax v) [] v"
  by (auto simp: payload_leaf_at_def payload_syntax_def object_formed_def rra_formed_def
      basis_formed_def bag_support_def single_valued_def headed_incidence_def
      payload_at_characterization)

section \<open>Concrete external literal leaves\<close>

fun literal_syntax :: "exact_target \<Rightarrow> exact_artifact" where
  "literal_syntax (Whole_Artifact R) =
    \<lparr>object_structure = \<lparr>rra_carrier = {[],[4]}, rra_incidence = {([],[4],[4])}\<rparr>,
     object_data = empty_basis\<rparr>"
| "literal_syntax (Occurrence_Anchor (R,a)) =
    \<lparr>object_structure =
      \<lparr>rra_carrier = {[],[4],[5]}, rra_incidence = {([],[],[4]),([],[4],[5])}\<rparr>,
     object_data = \<lparr>bag_count = (\<lambda>_. 0), functional_bindings = {([5],a)}\<rparr>\<rparr>"

fun literal_citation :: "exact_target \<Rightarrow> citation" where
  "literal_citation (Whole_Artifact R) = External_Whole [4]"
| "literal_citation (Occurrence_Anchor (R,a)) = External [4] a"

fun literal_interior :: "exact_target \<Rightarrow> local_address set" where
  "literal_interior (Whole_Artifact R) = {[]}"
| "literal_interior (Occurrence_Anchor (R,a)) = {[],[5]}"

lemma literal_syntax_properties:
  "rra_carrier (object_structure (literal_syntax t)) = literal_interior t \<union> {[4]}"
  "[] \<in> literal_interior t"
  "literal_interior t \<inter> {[4]} = {}"
  "bag_count (object_data (literal_syntax t)) = (\<lambda>_. 0)"
  "citation_slots (literal_citation t) = {[4]}"
  by (cases t; auto simp: empty_basis_def split: prod.splits)+

lemma literal_syntax_formed:
  assumes "target_formed t"
  shows "exact_formed (literal_syntax t)"
  using assms
  by (cases t)
     (auto simp: exact_formed_def anchor_formed_def object_formed_def rra_formed_def
       basis_formed_def single_valued_def basis_values_def bag_support_def octets_formed_def empty_basis_def
       split: prod.splits)

lemma literal_syntax_citation:
  assumes formed: "target_formed t"
  shows "citation_at (literal_syntax t) [] (literal_citation t) (literal_interior t)"
proof -
  have raw: "raw_citation_at (literal_syntax t) [] (literal_citation t) (literal_interior t)"
  proof (cases t)
    case (Whole_Artifact R)
    show ?thesis unfolding Whole_Artifact literal_syntax.simps literal_citation.simps literal_interior.simps
      by (rule raw_citation_at.external_whole) (auto simp: headed_incidence_def)
  next
    case (Occurrence_Anchor b)
    obtain R a where pair: "b = (R,a)" by (cases b) auto
    show ?thesis
      unfolding Occurrence_Anchor pair literal_syntax.simps literal_citation.simps literal_interior.simps
      by (rule raw_citation_at.external)
         (auto simp: headed_incidence_def payload_at_def restrict_basis_def basis_identity fun_eq_iff)
  qed
  have empty: "restrict_basis {[]} (object_data (literal_syntax t)) = empty_basis"
    by (cases t)
       (auto simp: restrict_basis_def empty_basis_def basis_identity fun_eq_iff split: prod.splits)
  show ?thesis using literal_syntax_formed[OF formed] raw empty literal_syntax_properties(1,2)[of t]
    by (auto simp: citation_at_def)
qed

lemma literal_syntax_interpretation:
  assumes "target_formed t" "external_slot_values E u [4] = {target_artifact t}"
  shows "interpret_citation E u (literal_citation t) t"
  using assms
  by (cases t)
     (auto simp: external_interpretation_by_slot split: prod.splits
       simp del: interpret_citation.simps)

section \<open>Pair syntax built from disjoint prefixed copies\<close>

definition pair_syntax :: "exact_artifact \<Rightarrow> exact_artifact \<Rightarrow> exact_artifact" where
  "pair_syntax R S =
    \<lparr>object_structure =
      \<lparr>rra_carrier = {[],[0],[1]} \<union>
          Cons 2 ` rra_carrier (object_structure R) \<union>
          Cons 3 ` rra_carrier (object_structure S),
       rra_incidence = {([],[0],[2]),([],[1],[3]),([0],[0],[1])} \<union>
          rra_incidence (push_structure (Cons 2) (object_structure R)) \<union>
          rra_incidence (push_structure (Cons 3) (object_structure S))\<rparr>,
     object_data = \<lparr>bag_count = (\<lambda>_. 0),
       functional_bindings =
         (\<lambda>(a,v). (2#a,v)) ` functional_bindings (object_data R) \<union>
         (\<lambda>(a,v). (3#a,v)) ` functional_bindings (object_data S)\<rparr>\<rparr>"

lemma prefix_addressing:
  assumes "exact_formed R" "n < 256"
  shows "finite_addressing (rra_carrier (object_structure R)) (Cons n)"
  using assms by (auto simp: finite_addressing_def inj_on_def exact_formed_def octets_formed_def)

lemma pair_syntax_formed:
  assumes "exact_formed R" "exact_formed S"
    "[] \<in> rra_carrier (object_structure R)" "[] \<in> rra_carrier (object_structure S)"
  shows "exact_formed (pair_syntax R S)"
proof -
  have sources: "object_formed R" "object_formed S"
    using assms(1,2) by (auto simp: exact_formed_def)
  have formed: "object_formed (pair_syntax R S)"
    using sources assms(3,4)
    by (auto simp: pair_syntax_def object_formed_def rra_formed_def
        push_structure_def basis_formed_def single_valued_def bag_support_def)
  have payloads: "\<And>a v. (a,v) \<in> functional_bindings (object_data R) \<union>
    functional_bindings (object_data S) \<Longrightarrow> octets_formed v"
  proof -
    fix a v
    assume member: "(a,v) \<in> functional_bindings (object_data R) \<union>
      functional_bindings (object_data S)"
    have "v \<in> basis_values (object_data R) \<union> basis_values (object_data S)"
      using member by (force simp: basis_values_def)
    then show "octets_formed v" using assms(1,2) by (auto simp: exact_formed_def)
  qed
  have addresses: "\<And>a. a \<in> rra_carrier (object_structure R) \<union>
    rra_carrier (object_structure S) \<Longrightarrow> octets_formed a"
    using assms(1,2) by (auto simp: exact_formed_def)
  show ?thesis using formed payloads addresses
    by (auto simp: exact_formed_def pair_syntax_def basis_values_def
        bag_support_def octets_formed_def; blast)
qed

lemma pair_syntax_root [simp]:
  "[] \<in> rra_carrier (object_structure (pair_syntax R S))"
  by (simp add: pair_syntax_def)

lemma pair_syntax_no_counts [simp]:
  "bag_count (object_data (pair_syntax R S)) = (\<lambda>_. 0)"
  by (simp add: pair_syntax_def)

lemma pair_syntax_reads_left:
  assumes counts: "bag_count (object_data R) = (\<lambda>_. 0)"
  shows "object_reads_agree (push_object (Cons 2) R) (pair_syntax R S)
    (Cons 2 ` rra_carrier (object_structure R))"
  by (auto simp: object_reads_agree_def pair_syntax_def push_object_def push_structure_def
      headed_incidence_def restrict_basis_def basis_identity push_basis_def
      pushed_count_def fun_eq_iff counts intro: rev_image_eqI)

lemma pair_syntax_reads_right:
  assumes counts: "bag_count (object_data S) = (\<lambda>_. 0)"
  shows "object_reads_agree (push_object (Cons 3) S) (pair_syntax R S)
    (Cons 3 ` rra_carrier (object_structure S))"
  by (auto simp: object_reads_agree_def pair_syntax_def push_object_def push_structure_def
      headed_incidence_def restrict_basis_def basis_identity push_basis_def
      pushed_count_def fun_eq_iff counts intro: rev_image_eqI)

lemma pair_syntax_record:
  assumes formed: "exact_formed (pair_syntax R S)"
  shows "record_at (pair_syntax R S) [] [[0],[1]] [[2],[3]]"
proof -
  let ?T = "object_structure (pair_syntax R S)"
  have last: "record_path ?T [] [1] [[1]] [[3]]"
    by (rule record_path.path_last)
       (auto simp: pair_syntax_def push_structure_def headed_incidence_def field_endpoint_def)
  have path: "record_path ?T [] [0] [[0],[1]] [[2],[3]]"
    by (rule record_path.path_slot[OF _ _ _ last])
       (auto simp: pair_syntax_def push_structure_def headed_incidence_def field_endpoint_def)
  show ?thesis using formed path
    by (auto simp: record_at_def raw_record_at_def exact_formed_def pair_syntax_def
        push_structure_def headed_incidence_def restrict_basis_def empty_basis_def
        basis_identity fun_eq_iff)
qed

text \<open>
  Prefix bytes choose concrete fresh positions in these witnesses. They are
  not labels read by the syntax. The pair construction copies all functional
  data and requires zero counted data when claiming preservation of a child.
  The native artifact type retains both data components without restriction.
\<close>

end
