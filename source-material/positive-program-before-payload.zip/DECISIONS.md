# Decisions and reasons

The current owner's request governs this reconstruction. Earlier generated
documents supply evidence of direction, including where they attribute words
to the owner; those attributions do not elevate their details above the current
request. Isabelle checks statements relative to definitions. Alignment of those
definitions with the intended system remains a separate review obligation.

Each choice below records its reason and its limits. Proof references are added
only after the corresponding theory is accepted.

## Source and build boundary

The theory source uses Isabelle symbol escapes. This is a source representation
choice, with no mathematical force. The delivered spelling failed to parse in
Isabelle2025-2; normalization exposed further proof errors.

The delivered top-level theories and explanatory files are preserved in
source-material/bootstrap-delivered.zip. They are design provenance, not an
additional active foundation. validation/delivered-sources.sha256 identifies
their original bytes.

tools/build.py records the Isabelle version, command, source hashes, exit code,
and log. A failed invocation cannot produce an accepted receipt. A successful
build does not establish that every requirement of the reconstruction is met.

## Data transport

Counted anonymous attachments and functional attachments have different
transport equations: counts add over a gluing fibre; equal functional values
coalesce, and unequal values conflict. The multiplicity-one encoding must be
tested against transport, not only against static values.

The reconstruction retains the two transport equations. Replacing a functional
attachment by a counted occurrence changes a valid equal-value gluing into a
count of two. Adding payload-occurrence identities would also change the
anonymous bag boundary; adding a merge-mode discriminator would move the same
distinction to a new field. Retaining the two components introduces neither
change. This is a choice over the stated attachment and gluing boundary, not a
claim to have ruled out every possible structural encoding.

The plan's unqualified legacy round-trip requirement also needs a boundary:
deleting the old profile tag maps no-data and the empty functional profile to
the same new basis. The reconstruction preserves recovery within each legacy
view, with that view explicit in the migration account. It does not restore a
profile discriminator inside the new core to preserve this discarded distinction.

## Quotation

The plan asks for determination of a quotation grammar from completeness,
recovery, no-extra structure, and fixed boundaries. These conditions must be
tested independently of a selected grammar. Uniqueness within a grammar will
not be reported as determination of the grammar.

## Assembly output

Pieces and a complete origin map determine the output carrier, incidence, and
data. The output-determination proof therefore licenses making that output a
derived projection of the witness, instead of retaining a duplicated field.
Construction applications still state the exact output being judged and compare
it with the derived value. This removes redundant storage without identifying
the application, its witness, and its result.

## Local structure and exact identity

Agreement on an incident star preserves recognition that reads only that star.
It does not preserve an exact anchor whose artifact component contains additional
structure: changing that exterior changes the exact artifact value. A semantic
locality statement must therefore retain every exact artifact value it observes,
as well as its structural and environment dependencies. The reconstruction keeps
local pattern invariance and exact identity invariance separate. It also states
formation preconditions explicitly when comparing two containing artifacts.

## Underdetermined choices

The current request authorizes reasoned choices with an explicit review record.
It supersedes earlier generated instructions to leave every such choice for
prior owner approval. Choices will be resolved against structurality,
explicitness, non-conflation, irredundancy, and non-nominality, and recorded here.

## Scoped environments

An environment is a finite graph of artifact-use occurrences and outgoing local
slot bindings. Equal artifact values may occupy different uses. Disjoint
composition labels the input uses as separate copies; merging identified uses
requires agreement of both their artifact values and their slot targets. This
extends the assembly discipline to dependency boundaries without making an
artifact's identity depend on its environment.

Environment closure is relative to an explicitly supplied complete demand set.
It checks exact slot coverage and reachability from the supplied roots. The
structural recognizer must derive that demand set; closure of a freely chosen
set alone does not establish semantic closure. Cycles of finite citation
bindings are not prohibited here. Restrictions on meaning recursion belong to
the definition and dependency layers.

Whole-artifact targets are retained alongside occurrence anchors. The empty
formed artifact has no occurrence anchor, so eliminating whole-artifact targets
would exclude a structural value that assembly already produces.

## Citation geometry

The citation grammar uses equality of tuple positions to distinguish local and
external references, with separate whole-artifact and occurrence forms. Local
references reach an atom directly. External references reach a scoped slot, and
an occurrence form also reaches a leaf containing its target address. Roots
have no attached data; address leaves carry exactly one functional value.
Incoming incidence is part of the explicit relative footprint.

These are chosen and stated structural patterns. Their constructor names exist
only in the recovered mathematical projection. Their admission rests on local
self-citation without a self-value, explicit external bindings, representation
of the empty artifact, functional recovery, and complete local data and incidence
boundaries. This does not assert that these conditions uniquely determine every
possible quotation grammar. A shape can participate in different structural
views when a supplied application selects those views; no intrinsic nominal
kind is assigned to an occurrence.

## Record order and family multiplicity

A record's complete field incidence already identifies every socket. A finite
successor path through exactly those sockets determines the first and last.
The reconstruction therefore uses only links between consecutive sockets:
a separate header, numeric position, and terminal marker would store facts
recoverable from the complete path. Empty and singleton records need no order
links. They share their encoding with the corresponding family because there
is no additional order information to represent.

Families expose the socket-to-endpoint relation, rather than only its range.
Distinct sockets reaching one endpoint remain distinct. Field order is recovered
only when successor incidence supplies it. These grammars are explicit admitted
views; their principality among arbitrary encodings is not assumed.

## What quotation determination requires

`RRA_Representation_Audit.recoverable_encodings_need_not_be_isomorphic`
constructs a formed addressed object with every carrier atom exposed at its
boundary. Rotating each incidence triple is reversible on all formed finite
objects. It preserves the complete carrier, every attachment, and every boundary
binding, and has exactly one output incidence per source incidence. The original
and rotated example nevertheless admit no atom isomorphism.

Thus recovery, complete material accounting, and boundary fixity do not force
primitive orientation. The reconstruction chooses quotation that preserves each
primitive incidence coordinate and each data attachment through an explicit
carrier correspondence. This strengthens the quotation boundary. It is justified
by retaining the already declared RRA primitives, and is stated separately from
the weaker conditions in the plan. `RRA_Data.bounded_copies_agree` proves that two
such copies of one bounded object are isomorphic with their boundary preserved.

This result is not reflective adequacy. A compiler between distinct source
languages still needs a meaning-preservation proof, and bootstrap reflection
still needs independently defined public relations and a concrete internal
implementation. No uniqueness of arbitrary record or citation grammars is
claimed.

## Generation values and scoped predecessors

A generation core contains its exact locus, finite set of direct predecessor
cores, exact payload, and exact recorded cause. Direct predecessor membership
has no order or multiplicity: repeating an identical edge adds no fact.
Its structural family therefore must give a bijection from its sockets to those
predecessor cores. This restriction applies to succession; it does not remove
repeated occurrences from general families or premise boundaries.

The recursive reader preserves the use occurrence selected by a predecessor
citation. Projecting first to an artifact value and then choosing any use of
that value would conflate distinct environments. A core is independent of
containing and selecting artifacts once its resolved fields are fixed.
A local whole-artifact citation does observe its container, so changing that
container can change a field; an unconditional invariance claim would be false.

Cause recording establishes a formed exact target and its structural citation.
It does not establish base admission or validate a construction account.
The later cause judgment must make that join. Evidence and adoption are absent
from the core datatype and from generation recovery.

## Snapshots, publications, and transactions

A snapshot stores selected generation cores, with at most one per locus. Its
locus graph is derived from the locus already present in each core. A general
selection may contain multiple generations at one locus; snapshot formation
adds the functional selection condition without claiming currentness.

A transaction supplies expected selections, expected absence, proposed
selections, and proposed absence. Expected and proposed locus graphs are
derived, avoiding repeated locus fields for selected cores. Removing a selection
is allowed and does not remove or alter a generation. Every changed locus must
be compared. Conflict returns the complete observed comparison graph and no
output snapshot. Success supplies the complete replacement, with all other
lookups preserved. Succession and cause validity are separate later joins.

A publication view consists of a snapshot and exact dependency and evidence
selections. The view is recovered at a supplied artifact use and root.
Equal views do not identify presentation sites. Evidence selection does not
establish proof validity, and publication formation establishes no adoption.

## The four-relation bridge

The supplied Factor signature is supported by a structural view with five
ordered fields: one complete carrier family and four complete binary-relation
fields. Each relation is the headed incidence at its selected field occurrence.
The carrier family preserves isolated source occurrences. The complete encoding
accounts for every auxiliary socket, every incidence, and all data; this legacy
class has empty attached data because its source signature has none.

The encoding uses disjoint copies for original atoms and construction sockets.
Those copy constructors occur only in the mathematical construction account.
The recognizer does not inspect them: it reads record order and incidence.
Encoding recovery, injectivity on formed sources, and injective transport are
proved. The source's ownership and successor restrictions are retained in a
separate conformance predicate. Other native Factor grammars may use the full
RRA incidence and data basis.

The local matching theorem compares complete incident stars. It requires an
injective correspondence on the declared pattern carrier and fixes every
external pattern atom. Its image may sit in a larger target, but every target
incidence touching the mapped interior must come from the pattern. The encoded
interior includes each source interior atom and its carrier socket. Record
scaffolding remains at the fixed boundary.

This makes explicit a gap in the source package's pointwise matching equation:
checking only tuples whose endpoints lie in the proposed image cannot detect an
extra incoming edge from outside that image. Its prose also requires complete
boundary accounting. The reconstruction adopts that complete-star reading and
proves transport for it, rather than claiming that the weaker pointwise test
already enforces it. The incoming-edge counterexample is checked in
`Factor_Structure`. `four_star_match_transport` proves both directions for every
formed four-relation source and target, including the retained legacy class.

## Reader-specific environment closure

A dependency is required by a structural read, rather than by the mere presence
of a citation-shaped subgraph anywhere in an artifact. RRA_Citation_Closure
derives requested slot bindings and observed uses from complete citation
requests. Its restriction preserves interpretation and scoped locations and is
the least sub-environment supporting those requests.

RRA_Generation_Dependencies supplies a concrete enclosing grammar. It recovers
the four record fields, requests their citations and every predecessor-family
endpoint, and recursively follows the predecessor locations. Locus, payload,
and cause targets are exact data observations; their contents are not
automatically read as further generations. The read sites and requests are
finite. Restriction preserves the exact cores, and reading the restricted
package produces the same sites, requests, and slot demands. Closure is therefore
checked against the restricted package's own grammar-derived boundary.

The generic citation utility does not let a certificate choose a sufficient
subset of requests. Each other public reader must similarly establish its
complete requests. Generation closure is proved; it is not evidence that the
remaining Factor and reflection readers have already been implemented.

Slot renaming moves structural occurrences and their environment keys. Opaque
remote address operands remain fixed, and the corresponding environment slots
must still supply the same exact target artifacts. Structural transport is
proved for all citation forms. External target identity is preserved under that
boundary; local citations instead refer to the readdressed containing artifact.

## The initial term quotation class

Factor_Terms introduces mathematical terms made from exact targets and ordered
pairs, with finite variable scopes for generic patterns. Constants retain the
entire exact target, including any structure and sharing inside its artifact.
Variable renaming fixes those constants. Instantiation, substitution, and an
infinite family of formed future terms are proved independently of truth.

The initial native reader uses external citation leaves and ordered pair
records. External citations keep literal target identity independent of the
artifact carrying the quotation. Its pair interiors are disjoint; this is a
tree quotation class, not a claim that every native RRA graph is a tree.
General RRA citations, including local self-citation, remain available.

The reader uniquely recovers the term, interior, and external slots. Every
formed term has a finite native representation and an environment closed over
exactly those slots. The witness source contains precisely the quotation
interior and the literal slots. Child prefixes choose fresh concrete addresses;
the reader does not test their bytes. Injective position maps preserve the
reading when the used syntax observations and exact external artifact values
agree. A remote occurrence address remains unchanged as an opaque operand.

These results do not establish general principality or admit a complete
semantic basis. In particular, total representability is not a proof that all
presentations of the same term have isomorphic complete carriers. The
presentation and candidate-form audit remains a separate obligation.

## Generic positive schemas and finite derivations

The current positive class has finite interfaces, identified clause occurrences,
and identified premise sockets. A schema's complete fields determine its
variable scope and direct callees. A binding assignment produces one conclusion
and one complete premise graph. Distinct sockets remain distinct when their
instantiated calls agree. An interface checks application formation separately
from whether any clause establishes that application.

Meaning is the least fixed point of the positive consequence operator. This is
one explicitly admitted mathematical recursion mechanism; arbitrary circular
truth selection is not supplied. A system with no premise-free instance has
empty meaning. The finite equality example accepts diagonal pairs of all formed
future terms without listing those arguments in the system. Native quotation
already covers each such argument; recovery of complete native systems remains.

The set iterated by this operator is the extension of true calls. An argument's
context or resource structure is part of its term and is not that set. The
representation introduces no operation that edits those argument structures.
The full audit of premise topologies and candidate semantic forms is still
required before claiming the intended complete semantic basis.

A finite derivation tree stores a clause occurrence, complete variable
bindings, and complete child bindings. The claimed call is a separate input.
The selected schema and bindings determine each expected child call, so the
certificate does not repeat those calls or the conclusion. Soundness and
completeness against positive meaning are proved independently of artifact
realization and evidence retention. The checker is primitive recursive in the
finite tree; executable checks for every node condition and complete native
realization remain separate obligations. This layer is named Factor_Derivation;
generic replay will additionally require realization and retention.

## Native scopes, schema recovery, and pattern construction

A scoped pattern records a binder-family root and a pattern root. The binder
family is diagonal: each binder occurrence is also its family's endpoint. It
has no headed incidence or data, and the declared set must equal the variables
used by the complete pattern. A schema similarly records its scope, conclusion
pattern, and complete prospective-premise family. A definition records its
scoped interface and complete clause family. These readers recover their
projections uniquely and invoke no truth predicate.

A prospective call resolves its callee through its actual citation and supplied
artifact use. This location is retained in the schema projection. Complete
definition-package recovery must establish that every such location contains
an admitted definition; a formed occurrence citation alone does not establish
that fact. Clause and premise family sockets remain distinct when their
endpoints or recovered values agree. Sharing an endpoint is explicit incidence.

Every formed finite pattern now has a native scoped representation. Construction
assigns binders injectively into fresh positions, copies syntax positions while
fixing those shared binders, and adds a fresh enclosing record and binder family.
The selected byte prefixes are construction coordinates; no reader inspects
them. The complete resulting carrier consists of the recovered interior and
literal slots, and its finite environment is closed over exactly those slots.
The use type in this existence theorem is an unbounded address space, so each
finite package can retain as many distinct exact literal targets as it needs.

## Native positive packages and exact dependency closure

A root citation family selects definition sites. Each site includes its artifact
use and local root. The reader follows every callee in every recovered clause,
and package formation requires a native definition at every reached site.
Reachability is a set used for dependency analysis; the original root, clause,
and premise families keep their distinct socket occurrences.

Structural source uses and interpreted slots are separate derived boundaries.
An empty root family still requires its source artifact even though it requests
no citation. The generic `read_environment` helper therefore takes both source
uses and slots. The native grammar supplies them by traversing all record
fields, family members, pattern leaves, and prospective callees. It does not
scan an artifact collection to select definitions.

The resulting restriction is finite and closed from the package root, recovers
the identical program, and derives the same boundary on rereading. Every
smaller included environment that still reads a valid package must retain all
of this material. A formed extension retaining that restriction recovers the
same interfaces, clauses, and callee sites. Literal target artifacts are exact
data values; their contents are not automatically evaluated as definitions.

Native ground applications recover a definition citation and term argument,
then use the recovered interface for formation. Their positive truth is the
independently defined least fixed point. No proof or evidence field enters it.
Closing the program leaves future argument material in its supplied containing
environment. The program's finite environment does not bound future arguments.

These results concern the admitted positive schema class. They do not yet admit
the other candidate semantic forms, prove complete native presentation
construction, establish general quotation principality, or implement reflection.
