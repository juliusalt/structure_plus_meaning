# Reconstruction obligations

This ledger tracks the obligations in `plan.md`. “Proved” names a mathematical
result in the reconstructed theories; it does not close the final alignment or
every-line repository audit. “Revised” identifies a claim whose original form
conflicts with another required distinction. Reasons are recorded in
`DECISIONS.md`. All unlisted higher-layer results from the delivered bootstrap
are historical and are not counted as implementation evidence.

| Obligation | State | Evidence or remaining work |
|---|---|---|
| O-1 | Proved | Carrier-locality lemmas in RRA_Data; attachment identity is a carrier/value position and an anonymous count, or a functional pair. |
| O-2 | Proved | RRA_Core.rra_identity, RRA_Data.basis_identity, RRA_Exact.exact_identity_iff. |
| O-3 | Revised; proved per view | RRA_Data_Views proves recovery within each legacy view. Empty profiles collapse; unqualified global recovery is false. See DECISIONS.md. |
| O-4 | Partial | Native data-preserving isomorphism and legacy injective transport are proved; the full correspondence audit remains. |
| O-5 | Proved | RRA_Data.basis_compatibility_finite_check and RRA_Assembly.K2_finite_compatibility_check. Complete finite binding lists exist; pushforward and empty output are determined. |
| O-6 | Proved | RRA_Data_Views connects each legacy node crossing to a crossing structural incidence. |
| O-7 | Proved within stated boundary | Multiplicity-one functional encoding fails to commute with equal-value gluing. The admitted two-component basis is justified in DECISIONS.md. |
| O-8 | Proved | RRA_Footprint: exact star and data, finite closure, derived boundary, and realization iff formation. |
| O-9 | Revised; partial | Primitive observations and selected restrictions are local. Exact identity is not determined by a star; a formed counterexample is proved. Syntax and semantic locality remain. |
| O-10 | Open | Resolver-based higher theories are archived. Replacement normative judgments remain to be implemented. |
| O-11 | Proved | RRA_Environment.citation_interpretation_functional and RRA_Structural_Syntax.anchored_at_unique include structural citation recovery. |
| O-12 | Proved | local_self_citation_in_closed_use constructs a closed use with empty attached data and the exact local occurrence target. |
| O-13 | Proved for citation interpretation | citation_alias_invariance equates both external target forms when their supplied bindings denote the same artifact. |
| O-14 | Partial | Citation and generation locality are proved over their recognized, finite dependency boundaries. Higher semantic readers remain. |
| O-15 | Proved for citations and terms | citation_at_push transports structural positions; external_citation_readdressing preserves remote targets. Factor_Quotation.term_quotation_transport extends this to recursively quoted terms while fixing opaque literal operands. |
| O-16 | Partial | RRA_Citation_Closure computes the least environment supporting complete citation requests. RRA_Generation_Dependencies derives those requests from generation syntax, follows predecessor locations, and proves a closed restriction that recovers the same cores and the same demands. Higher reader grammars remain. |
| O-17 | Proved | Four incidence patterns distinguish local/external and whole/occurrence forms. Raw recovery is unique; every formed projection has a representation. |
| O-18 | Partial | Structural recognition, recovery, data boundaries, and relative locality are proved. The geometry is an explicit choice; general quotation determination is separate. |
| O-19 | Proved | RRA_Fragment partitions incidence and both data components and reconstructs the complete source from material, crossing boundary, and omitted object. |
| O-20 | Proved | RRA_Assembly derives output from pieces and origins, relates it to an independently supplied output, proves formation and existence, and handles the empty family. |
| O-21 | Open | Not yet implemented in the reconstructed system. |
| O-22 | Proved | RRA_Generation.generation_predecessor_resolves and generation_predecessor_is_formed. |
| O-23 | Proved | predecessor_size_decreases, predecessor_acyclic, and predecessor_well_founded establish descent over exact cores. |
| O-24 | Partial | The exact core excludes container and selection fields. Scoped recovery and environment locality are proved; quotation transport remains. |
| O-25 | Partial | Publication evidence selections vary independently of the selected exact cores. Adoption joins remain. |
| O-26 | Open | Not yet implemented in the reconstructed system. |
| O-27 | Proved | RRA_Transaction.no_partial_success, successful_transaction_lookup, and result determinacy. |
| O-28 | Proved | conflict_contains_every_observation proves complete finite domain, every observed value, and no output snapshot. |
| O-29 | Implemented; audit pending | Snapshot, publication, and transaction relations contain no currentness or authority premise or conclusion. Final dependency audit remains. |
| O-30 | Proved for the four-relation view | Factor_Structure.four_structure_unique derives field recovery from record and family recovery. |
| O-31 | Partial | Recognition checks complete carrier, data, and incidence equations; disagreement is rejected. General Factor grammar remains. |
| O-32 | Proved for the four-relation class | Encoding and recovery preserve every source occurrence and relation; four_star_match_transport preserves and reflects complete local stars. The full language remains. |
| O-33 | Partial | Record, family, and four-structure injective transport are proved. The full language remains. |
| O-34 | Revised; proved for the supported class | legacy_factor_representable, four_encode_injective, and four_star_match_transport. The complete-star reading and the source's weaker pointwise equation are distinguished in DECISIONS.md. |
| O-35 | Proved for the positive presentation class | Native readers uniquely recover patterns, schemas, definitions, complete root-selected finite systems, and ground applications. Other candidate forms remain. |
| O-36 | Open | Not yet implemented in the reconstructed system. |
| O-37 | Partial | Native term and pattern renaming, positive meaning locality, and native whole-package locality over the least grammar-derived environment are proved. Complete native schema/package renaming remains. |
| O-38 | Proved for the positive class | Factor_Native_Equality recovers one concrete closed native program and constructs calls over arbitrary future formed terms. Its meaning is exactly the diagonal, and its domain is infinite. The program is preserved in every constructed call environment. |
| O-39 | Open | Not yet implemented in the reconstructed system. |
| O-40 | Open | Not yet implemented in the reconstructed system. |
| O-41 | Proved for the positive class | A native root citation family determines every definition read and demanded slot. Formation requires all reachable callees. The finite derived restriction is closed, preserves the exact program, is stable on rereading, and is included in every smaller valid package. Other candidate forms remain. |
| O-42 | Proved for the positive class | Recursion is confined to one monotone least-fixed-point construction. unsupported_positive_cycle_is_empty rejects unseeded recursion as a source of judgments. Other candidate forms remain unaudited. |
| O-43 | Partial | Terms, scoped patterns, and ground calls have structural readers, unique recovery, and total native witnesses with complete carrier accounting. A concrete native equality package is constructed. General complete-definition quotation and full material/principality obligations remain. |
| O-44 | Revised; partial | Coordinate rotation refutes determination from the weaker conditions. Primitive-preserving bounded copies are determined up to boundary isomorphism; the Factor quotation layer remains. |
| O-45 | Open | Not yet implemented in the reconstructed system. |
| O-46 | Open | Not yet implemented in the reconstructed system. |
| O-47 | Open | Not yet implemented in the reconstructed system. |
| O-48 | Open | Not yet implemented in the reconstructed system. |
| O-49 | Proved for the positive class | Factor_Derivation.schema_proof_sound and schema_proof_complete connect finite derivation trees to the independently defined positive meaning, with no retention premise. Other admitted forms remain. |
| O-50 | Open | Not yet implemented in the reconstructed system. |
| O-51 | Open | Not yet implemented in the reconstructed system. |
| O-52 | Open | Not yet implemented in the reconstructed system. |
| O-53 | Open | Not yet implemented in the reconstructed system. |
| O-54 | Open | Not yet implemented in the reconstructed system. |
| O-55 | Open | Not yet implemented in the reconstructed system. |
| O-56 | Open | Not yet implemented in the reconstructed system. |
| O-57 | Open | Not yet implemented in the reconstructed system. |
| O-58 | Open | Not yet implemented in the reconstructed system. |
| O-59 | Open | Not yet implemented in the reconstructed system. |
| O-60 | Open | Not yet implemented in the reconstructed system. |
| O-61 | Open | Not yet implemented in the reconstructed system. |
| O-62 | Open | Not yet implemented in the reconstructed system. |
| O-63 | Open | Not yet implemented in the reconstructed system. |
| O-64 | Open | Not yet implemented in the reconstructed system. |
| O-65 | Open | Not yet implemented in the reconstructed system. |
| O-66 | Open | Not yet implemented in the reconstructed system. |
| O-67 | Open | Not yet implemented in the reconstructed system. |
| O-68 | Open | Not yet implemented in the reconstructed system. |
| O-69 | Open | Not yet implemented in the reconstructed system. |
| O-70 | Open | Not yet implemented in the reconstructed system. |
| O-71 | Open | Not yet implemented in the reconstructed system. |
| O-72 | Open | Not yet implemented in the reconstructed system. |
| O-73 | Open | Not yet implemented in the reconstructed system. |
| O-74 | Proved | external_citation_has_distinct_closed_uses exhibits different interpretations of the same structurally recognized citation under closed environments. |
| O-75 | Partial | Disjoint-use composition, compatible merging, and interpretation preservation are proved. Transport under artifact readdressing remains. |
| O-76 | Open | Not yet implemented in the reconstructed system. |
| O-77 | Proved for generation recovery | generation_at_unique, generation_closed_restriction, generation_requests_restricted, and request_environment_least establish unique recovery and the finite minimal dependency boundary. General higher readers remain separate obligations. |
| O-78 | Open | Not yet implemented in the reconstructed system. |
| O-79 | Open | Not yet implemented in the reconstructed system. |
| O-80 | Revised; partial | The rotation counterexample and bounded-copy theorem are independent of record and citation geometry. Complete quotation integration remains. |
| O-81 | Open | Not yet implemented in the reconstructed system. |
| O-82 | Open | Not yet implemented in the reconstructed system. |
| O-83 | Open | Not yet implemented in the reconstructed system. |

The final audit has not begun. It must include all active source and tools,
all explanatory documents, and every supplied unique text, with duplicate
and binary/archive contents accounted for explicitly.
