# Structural semantics

This repository is being reconstructed from `plan.md` and the supplied design
material. The owner's principles govern the reconstruction: structurality,
explicitness, non-conflation, irredundancy, and non-nominality. Individual claims
in the supplied documents remain subject to proof and alignment review.

The work is incomplete. The current active session establishes the structural
and data basis, relative footprints, exact artifacts, fragments, and assembly.
Scoped citation environments, structural citation recognition, record and family representations,
finite evidence envelopes, scoped generation recovery, immutable selections,
publications, and atomic transactions are proved. The Factor relation bridge
has encoding, recovery, and complete local-match transport proofs. Citation
requests determine least closed environments, and the generation grammar
recovers its own finite recursive dependency boundary. Exact-target and pair
terms have native quotations, unique recovery, transport, and total construction
in finite closed environments. Every formed pattern has a native scoped
quotation with complete binder recovery. Native readers recover positive
schemas and definitions. A native root citation family selects a complete finite
system by following every recovered callee. Ground applications recover their
definition and argument, then check the recovered interface. Generic positive
schemas have independently fixed meaning, locality over closed definition
dependencies, and finite derivation soundness and completeness. The package
grammar determines a least closed environment, preserves the recovered system,
and computes the same boundary on rereading. Native application truth uses that
independent meaning. Proof realization and retention, validated continuation,
computational adequacy, reflection, and concrete genesis
remain open. A successful build does not establish those unfinished claims.

A concrete finite native equality program is recovered from one closed
artifact environment. It accepts native calls over arbitrary future formed
terms, with truth exactly when the two terms agree. Its argument domain and
family of native call environments are infinite.

Run `python3 tools/build.py` from this directory. The wrapper records the Isabelle
version, exact source hashes, exit status, and full log in `validation/`. The
receipt states whether that invocation was accepted. The active theory graph is
in [THEORY_MAP.md](THEORY_MAP.md); requirement status is in
[OBLIGATIONS.md](OBLIGATIONS.md); reasoned choices are in
[DECISIONS.md](DECISIONS.md).

Exact artifact identity includes the complete carrier, incidence, and data.
Occurrence anchors pair that value with an address. Structural isomorphism and
agreement on a local footprint are distinct relations. Locality claims must
state every artifact value and environment binding they observe.

Assembly stores its pieces and one complete origin map. Carrier, incidence, and
data in its output are derived from them. Functional attachments must agree
where atoms are identified; anonymous counts add over each fibre. A fragment
retains its exact source and selected carrier; its material, crossing incidence,
and omitted object are derived, with complete reconstruction proved.

Supplied and intermediate systems are preserved under `source-material/`.
Their statements of completeness or normativity describe their historical
claims. They do not extend the active session selected by `ROOT`.
