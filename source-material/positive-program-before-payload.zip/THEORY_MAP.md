# Active theory graph

This table describes the current source imports. It is an implementation status
record, not the completed graph proposed in `plan.md`.

| Theory | Direct imports | Content |
|---|---|---|
| Bootstrap_Relations | Main | Finite extensional relations, exact maps, images, direct and transitive ancestry. |
| RRA_Core | Bootstrap_Relations | One carrier and ternary incidence, restriction, renaming, bounded views, connectivity. |
| RRA_Data | RRA_Core | Anonymous counted and functional attachments, restriction, compatible gluing, structured objects. |
| RRA_Data_Views | RRA_Data | Legacy encodings, recovery, transport, and crossing-boundary comparisons; a leaf. |
| RRA_Footprint | RRA_Data | Interior, complete incident star and local data; derived boundary and closure; locality of primitive observations. |
| RRA_Exact | RRA_Footprint | Exact artifacts and value anchors, whole-artifact targets, finite addressing and exact realization. |
| RRA_Representation_Audit | RRA_Exact | A reversible incidence-coordinate encoding need not preserve the isomorphism class. A leaf audit. |
| RRA_Environment | RRA_Exact | Finite use scopes, local and external citation interpretation, explicit dependency agreement. |
| RRA_Structural_Syntax | RRA_Environment | Incidence-based citations, complete payload leaves, ordered record recovery, and socket-preserving families. |
| RRA_Read_Transport | RRA_Structural_Syntax | Headed-incidence and local-data agreement used to preserve structural reads in a larger artifact; distinct from full footprint or exact identity. |
| RRA_Syntax_Construction | RRA_Read_Transport | Finite closed literal environments, external leaf witnesses, and ordered pair construction from disjoint prefixed copies. |
| RRA_Bound_Syntax_Construction | RRA_Syntax_Construction | Copies syntax while fixing shared binder positions; formation, preservation of child reads, silent binder boundaries, and pair recognition. |
| RRA_Scope_Construction | RRA_Bound_Syntax_Construction | Adds a fresh record and complete binder family; formation and preservation of all reads on the old carrier. |
| RRA_Citation_Closure | RRA_Structural_Syntax | Grammar-supplied citation requests, exact slot and use projections, least closed restrictions, target and location preservation. |
| RRA_Read_Environment | RRA_Citation_Closure | Least environment material for explicit structural source uses and demanded bindings, including readers with no citations; preservation, closed restriction, and idempotence. |
| RRA_Evidence | RRA_Structural_Syntax | Exact links and complete finite envelopes; unique recovery and environment locality. |
| RRA_Generation | RRA_Structural_Syntax, HOL-Library.FSet | Finite predecessor cores, acyclicity, scoped recursive recovery, and environment locality. |
| RRA_Generation_Dependencies | RRA_Generation, RRA_Citation_Closure | Grammar-derived recursive requests, stable closed restriction, and locality over the minimal environment material. |
| RRA_Selection | RRA_Generation | Structural selections, at most one core per locus in snapshots, derived lookup, exact replacement. |
| RRA_Publication | RRA_Selection | Recovered snapshot, dependency, and evidence selections at an exact site; no adoption judgment. |
| RRA_Transaction | RRA_Selection | Complete comparison, atomic replacement, exact conflict observations, and structural request recovery. |
| Factor_Structure | RRA_Structural_Syntax | Complete four-relation view, separate legacy conformance class, encoding, recovery, injective transport, and complete incident-star matching. |
| Factor_Terms | Factor_Structure | Mathematical term and variable-pattern projections, finite scoped instantiation, substitution, renaming, and an infinite future term domain. |
| Factor_Quotation | Factor_Terms, RRA_Citation_Closure, RRA_Read_Transport | Native term reader: external citation leaves and ordered pairs; unique term, interior, and slot recovery; transport under injective syntax maps and exact literal agreement. |
| Factor_Term_Encoding | Factor_Quotation, RRA_Syntax_Construction | Every formed term has a native quotation and a finite environment closed over exactly its recovered slots; complete source carrier accounting. |
| Factor_Patterns | Factor_Term_Encoding | Complete binder families and native variable/constant/pair patterns; unique recovery, injective transport, and embedding under exact literal agreement. |
| Factor_Schemas | Factor_Patterns | Generic finite schemas, derived variable scope and dependencies, total and unique instantiation, complete identified premise sockets. |
| Factor_Interfaces | Factor_Schemas | Finite interface and clause projections, explicit direct dependencies, and formed schema applications without a truth premise. |
| Factor_Presentation | Factor_Interfaces | Native scoped patterns, prospective calls, complete premise and clause families, schemas, and definitions; unique recovery. |
| Factor_Packages | Factor_Presentation, RRA_Citation_Closure | Native root citation families and complete definition dependency traversal; finite functional system recovery, exact clauses and edges, and rejection of missing callees. |
| Factor_Applications | Factor_Packages | Native definition citation and ground term arguments; functional recovery and formation against the recovered interface. |
| Factor_Application_Encoding | Factor_Applications | Total finite call construction for a formed target anchor and term, use renaming, preservation of the target artifact, and complete call carrier accounting. |
| Factor_Presentation_Dependencies | Factor_Packages, RRA_Read_Environment | Compatible extension preserves native readers; record and family traversal derives every pattern, call, schema, and definition slot. |
| Factor_Presentation_Restriction | Factor_Presentation_Dependencies | Retaining the derived source and slot boundary preserves each native reader and the slots it recovers. |
| Factor_Package_Dependencies | Factor_Presentation_Restriction | Grammar-derived source uses and demands; unchanged recursive traversal and program, stable rereading, idempotence, and closed native package recovery. |
| Factor_Package_Locality | Factor_Package_Dependencies | Whole-program locality under compatible extension, boundary invariance, and required material in every smaller valid package. |
| Factor_Pattern_Encoding | Factor_Presentation, RRA_Scope_Construction | Total native scoped-pattern construction after injective binder addressing; exact variable use, finite closed literal environments, and complete carrier accounting. |
| Factor_Positive_Meaning | Factor_Interfaces | Independently fixed positive meaning, least closure, unseeded-recursion rejection, and a generic equality example. |
| Factor_Positive_Locality | Factor_Positive_Meaning | Positive meaning is unchanged when complete interfaces and clause families agree throughout a closed definition dependency boundary. |
| Factor_Native_Meaning | Factor_Applications, Factor_Package_Locality, Factor_Positive_Locality | Truth of recovered native ground applications, formation, closed-program recovery, and dependency locality, with no proof or retention premise. |
| Factor_Native_Equality | Factor_Native_Meaning, Factor_Application_Encoding | A concrete closed native program with exact diagonal meaning; arbitrary future native calls use the same program and compare formed terms. |
| Factor_Derivation | Factor_Positive_Meaning, HOL-Library.FSet | Finite certificate trees checked against a separate claimed call; soundness and completeness for positive meaning. Native realization and evidence retention remain. |
| RRA_Fragment | RRA_Structural_Syntax | Selected material and omitted object, incidence and data partition, complete source reconstruction. |
| RRA_Assembly | RRA_Fragment | Slot-separated copies, one origin graph, derived output, formation, existence, and empty assembly. |

The higher layers remain to be reconstructed. The earlier
resolver-based theories, including their checked intermediate state after the
data migration, are preserved in
`source-material/intermediate-data-assembly-footprint.zip`. Their placeholder
reflection and genesis predicates are not part of the active theory graph.
