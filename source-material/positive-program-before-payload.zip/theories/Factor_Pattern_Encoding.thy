theory Factor_Pattern_Encoding
  imports Factor_Presentation RRA_Scope_Construction
begin

section \<open>Finite binder address assignments\<close>

definition binder_addressing :: "'a set \<Rightarrow> ('a \<Rightarrow> local_address) \<Rightarrow> bool" where
  "binder_addressing V f \<longleftrightarrow> finite_addressing V f \<and> f ` V \<subseteq> binder_addresses"

lemma binder_addressing_mono:
  assumes "binder_addressing V f" "W \<subseteq> V"
  shows "binder_addressing W f"
proof -
  have source: "inj_on f V" "\<forall>a\<in>V. octets_formed (f a)" "f ` V \<subseteq> binder_addresses"
    using assms(1) by (auto simp: binder_addressing_def finite_addressing_def)
  have injective: "inj_on f W" by (rule inj_on_subset[OF source(1) assms(2)])
  have formed: "\<forall>a\<in>W. octets_formed (f a)" using source(2) assms(2) by blast
  have bound: "f ` W \<subseteq> binder_addresses"
    by (rule subset_trans[OF image_mono[OF assms(2)] source(3)])
  show ?thesis using injective formed bound by (simp add: binder_addressing_def finite_addressing_def)
qed

lemma binder_addressing_exists:
  assumes "finite V"
  shows "\<exists>f. binder_addressing V f"
proof -
  obtain f where source: "finite_addressing V f" using finite_addressing_exists[OF assms] by blast
  have "binder_addressing V (Cons 6 \<circ> f)"
    using source by (auto simp: binder_addressing_def finite_addressing_def inj_on_def octets_formed_def)
  then show ?thesis by blast
qed

lemma rename_pattern_fixed:
  assumes "\<forall>a\<in>pattern_variables p. f a = a"
  shows "rename_pattern f p = p"
  using assms by (induction p) (auto simp: rename_pattern_def)

section \<open>Variable leaves and recursively paired pattern syntax\<close>

definition variable_syntax :: "local_address \<Rightarrow> exact_artifact" where
  "variable_syntax a =
    \<lparr>object_structure = \<lparr>rra_carrier = {[],a}, rra_incidence = {([],[],a)}\<rparr>,
     object_data = empty_basis\<rparr>"

lemma variable_syntax_formed:
  assumes "octets_formed a"
  shows "exact_formed (variable_syntax a)"
  using assms by (simp add: variable_syntax_def exact_formed_def object_formed_def rra_formed_def octets_formed_def)

lemma variable_syntax_citation:
  assumes "octets_formed a"
  shows "citation_at (variable_syntax a) [] (Local a) {[]}"
proof -
  have raw: "raw_citation_at (variable_syntax a) [] (Local a) {[]}"
    by (rule raw_citation_at.local) (auto simp: variable_syntax_def headed_incidence_def)
  show ?thesis using raw variable_syntax_formed[OF assms]
    by (simp add: citation_at_def variable_syntax_def)
qed

lemma variable_syntax_silent [simp]:
  "binder_silent (variable_syntax a)"
  by (auto simp: binder_silent_def variable_syntax_def headed_incidence_def)

lemma literal_syntax_silent [simp]:
  "binder_silent (literal_syntax t)"
  by (cases t)
     (auto simp: binder_silent_def headed_incidence_def restrict_basis_def empty_basis_def
       basis_identity fun_eq_iff split: prod.splits)

lemma literal_interior_outside_binders:
  "literal_interior t \<inter> binder_addresses = {}"
  by (cases t) (auto split: prod.splits)

fun pattern_syntax :: "('a \<Rightarrow> local_address) \<Rightarrow> 'a term_pattern \<Rightarrow> exact_artifact" where
  "pattern_syntax f (Pattern_Variable a) = variable_syntax (f a)"
| "pattern_syntax f (Pattern_Target t) = literal_syntax t"
| "pattern_syntax f (Pattern_Pair p q) = bound_pair_syntax (pattern_syntax f p) (pattern_syntax f q)"

fun pattern_literal_bindings :: "'a term_pattern \<Rightarrow> (local_address \<times> exact_artifact) set" where
  "pattern_literal_bindings (Pattern_Variable a) = {}"
| "pattern_literal_bindings (Pattern_Target t) = {([4],target_artifact t)}"
| "pattern_literal_bindings (Pattern_Pair p q) =
    (\<lambda>(k,R). (2#k,R)) ` pattern_literal_bindings p \<union>
    (\<lambda>(k,R). (3#k,R)) ` pattern_literal_bindings q"

fun pattern_syntax_interior :: "'a term_pattern \<Rightarrow> local_address set" where
  "pattern_syntax_interior (Pattern_Variable a) = {[]}"
| "pattern_syntax_interior (Pattern_Target t) = literal_interior t"
| "pattern_syntax_interior (Pattern_Pair p q) =
    {[],[0],[1]} \<union> Cons 2 ` pattern_syntax_interior p \<union> Cons 3 ` pattern_syntax_interior q"

lemma pattern_literal_slots [simp]:
  "rel_dom (pattern_literal_bindings (Pattern_Variable a)) = {}"
  "rel_dom (pattern_literal_bindings (Pattern_Target t)) = {[4]}"
  "rel_dom (pattern_literal_bindings (Pattern_Pair p q)) =
    Cons 2 ` rel_dom (pattern_literal_bindings p) \<union> Cons 3 ` rel_dom (pattern_literal_bindings q)"
  by (auto simp: rel_dom_def intro: rev_image_eqI)

lemma pattern_literal_bindings_finite [simp]:
  "finite (pattern_literal_bindings p)"
  by (induction p) auto

lemma pattern_literal_bindings_functional:
  "single_valued (pattern_literal_bindings p)"
  by (induction p) (auto simp: single_valued_def)

lemma pattern_literal_bindings_formed:
  assumes "pattern_formed p"
  shows "\<forall>k R. (k,R) \<in> pattern_literal_bindings p \<longrightarrow> exact_formed R"
  using assms by (induction p) (auto dest: target_formed_artifact)

lemma pattern_syntax_root [simp]:
  "[] \<in> rra_carrier (object_structure (pattern_syntax f p))"
  by (cases p) (use literal_syntax_properties(1,2) in \<open>auto simp: variable_syntax_def\<close>)

lemma pattern_syntax_no_counts [simp]:
  "bag_count (object_data (pattern_syntax f p)) = (\<lambda>_. 0)"
  by (cases p) (simp_all add: variable_syntax_def empty_basis_def literal_syntax_properties(4))

lemma pattern_syntax_silent [simp]:
  "binder_silent (pattern_syntax f p)"
  by (induction p) (auto intro: bound_pair_silent)

lemma pattern_syntax_formed:
  assumes "pattern_formed p" "binder_addressing (pattern_variables p) f"
  shows "exact_formed (pattern_syntax f p)"
  using assms
proof (induction p)
  case (Pattern_Variable a)
  have "octets_formed (f a)" using Pattern_Variable.prems by (simp add: binder_addressing_def finite_addressing_def)
  then show ?case by (simp add: variable_syntax_formed)
next
  case (Pattern_Target t)
  then show ?case by (simp add: literal_syntax_formed)
next
  case (Pattern_Pair p q)
  have pf: "pattern_formed p" and qf: "pattern_formed q" using Pattern_Pair.prems(1) by auto
  have paddr: "binder_addressing (pattern_variables p) f"
    by (rule binder_addressing_mono[OF Pattern_Pair.prems(2)]) auto
  have qaddr: "binder_addressing (pattern_variables q) f"
    by (rule binder_addressing_mono[OF Pattern_Pair.prems(2)]) auto
  have left: "exact_formed (pattern_syntax f p)" by (rule Pattern_Pair.IH(1)[OF pf paddr])
  have right: "exact_formed (pattern_syntax f q)" by (rule Pattern_Pair.IH(2)[OF qf qaddr])
  show ?case using bound_pair_syntax_formed[OF left right] by simp
qed

lemma pattern_syntax_interior_outside:
  "pattern_syntax_interior p \<inter> binder_addresses = {}"
  by (induction p) (auto simp: literal_interior_outside_binders)

lemma pattern_literal_slots_outside:
  "rel_dom (pattern_literal_bindings p) \<inter> binder_addresses = {}"
  by (induction p; simp only: pattern_literal_slots; auto)

lemma pattern_syntax_slot_boundary:
  "pattern_syntax_interior p \<inter> rel_dom (pattern_literal_bindings p) = {}"
  by (induction p; simp only: pattern_literal_slots; auto simp: literal_syntax_properties(3))

lemma pattern_syntax_carrier:
  assumes "binder_addressing (pattern_variables p) f"
  shows "rra_carrier (object_structure (pattern_syntax f p)) =
    pattern_syntax_interior p \<union> rel_dom (pattern_literal_bindings p) \<union> f ` pattern_variables p"
  using assms
proof (induction p)
  case (Pattern_Variable a)
  show ?case by (simp only: pattern_syntax.simps pattern_syntax_interior.simps pattern_literal_slots
    pattern_variables.simps) (auto simp: variable_syntax_def)
next
  case (Pattern_Target t)
  show ?case by (simp only: pattern_syntax.simps pattern_syntax_interior.simps pattern_literal_slots
    pattern_variables.simps literal_syntax_properties(1)) simp
next
  case (Pattern_Pair p q)
  have paddr: "binder_addressing (pattern_variables p) f"
    by (rule binder_addressing_mono[OF Pattern_Pair.prems]) auto
  have qaddr: "binder_addressing (pattern_variables q) f"
    by (rule binder_addressing_mono[OF Pattern_Pair.prems]) auto
  have pb: "f ` pattern_variables p \<subseteq> binder_addresses"
    and qb: "f ` pattern_variables q \<subseteq> binder_addresses"
    using paddr qaddr by (auto simp: binder_addressing_def)
  have left: "syntax_prefix 2 ` rra_carrier (object_structure (pattern_syntax f p)) =
    Cons 2 ` pattern_syntax_interior p \<union> Cons 2 ` rel_dom (pattern_literal_bindings p) \<union> f ` pattern_variables p"
    by (simp only: Pattern_Pair.IH(1)[OF paddr] image_Un
        syntax_prefix_image_outside[OF pattern_syntax_interior_outside]
        syntax_prefix_image_outside[OF pattern_literal_slots_outside]
        syntax_prefix_image_binders[OF pb])
  have right: "syntax_prefix 3 ` rra_carrier (object_structure (pattern_syntax f q)) =
    Cons 3 ` pattern_syntax_interior q \<union> Cons 3 ` rel_dom (pattern_literal_bindings q) \<union> f ` pattern_variables q"
    by (simp only: Pattern_Pair.IH(2)[OF qaddr] image_Un
        syntax_prefix_image_outside[OF pattern_syntax_interior_outside]
        syntax_prefix_image_outside[OF pattern_literal_slots_outside]
        syntax_prefix_image_binders[OF qb])
  show ?case
    by (simp only: pattern_syntax.simps pattern_syntax_interior.simps pattern_literal_slots
        pattern_variables.simps) (auto simp: bound_pair_syntax_def left right image_Un)
qed

definition pattern_environment ::
  "('a \<Rightarrow> local_address) \<Rightarrow> 'a term_pattern \<Rightarrow> local_address option artifact_environment" where
  "pattern_environment f p = literal_environment (pattern_syntax f p) (pattern_literal_bindings p)"

lemma pattern_environment_formed:
  assumes "pattern_formed p" "binder_addressing (pattern_variables p) f"
  shows "environment_formed (pattern_environment f p)"
  unfolding pattern_environment_def
  by (rule literal_environment_formed[OF pattern_syntax_formed[OF assms]
        pattern_literal_bindings_finite pattern_literal_bindings_functional
        pattern_literal_bindings_formed[OF assms(1)]])
     (auto simp: pattern_syntax_carrier[OF assms(2)])

lemma pattern_environment_source [simp]:
  "artifact_at (pattern_environment f p) None (pattern_syntax f p)"
  by (simp add: pattern_environment_def)

lemma pattern_environment_slots [simp]:
  "external_slot_values (pattern_environment f p) None k = {R. (k,R) \<in> pattern_literal_bindings p}"
  by (simp add: pattern_environment_def)

lemma pattern_environment_pair_slots:
  assumes "k \<notin> binder_addresses"
  shows "external_slot_values (pattern_environment f (Pattern_Pair p q)) None (syntax_prefix 2 k) =
    external_slot_values (pattern_environment f p) None k"
    "external_slot_values (pattern_environment f (Pattern_Pair p q)) None (syntax_prefix 3 k) =
    external_slot_values (pattern_environment f q) None k"
  using assms by (auto simp: syntax_prefix_def)

lemma renamed_pattern_prefix:
  assumes "binder_addressing (pattern_variables p) f"
  shows "rename_pattern (syntax_prefix n) (rename_pattern f p) = rename_pattern f p"
proof -
  have subset: "pattern_variables (rename_pattern f p) \<subseteq> binder_addresses"
    using assms by (simp add: binder_addressing_def rename_pattern_variables)
  show ?thesis by (rule rename_pattern_fixed) (use subset in \<open>auto simp: syntax_prefix_def\<close>)
qed

theorem pattern_syntax_recovers:
  assumes formed: "pattern_formed p" and addressing: "binder_addressing (pattern_variables p) f"
    and scope: "f ` pattern_variables p \<subseteq> V" and boundary: "V \<subseteq> binder_addresses"
  shows "pattern_quoted_at (pattern_environment f p) None V [] (rename_pattern f p)
    (pattern_syntax_interior p) (rel_dom (pattern_literal_bindings p))"
  using formed addressing scope
proof (induction p)
  case (Pattern_Variable a)
  have af: "octets_formed (f a)" using Pattern_Variable.prems(2)
    by (simp add: binder_addressing_def finite_addressing_def)
  have member: "f a \<in> V" using Pattern_Variable.prems(3) by simp
  have ef: "environment_formed (pattern_environment f (Pattern_Variable a))"
    by (rule pattern_environment_formed[OF Pattern_Variable.prems(1,2)])
  have source: "artifact_at (pattern_environment f (Pattern_Variable a)) None (variable_syntax (f a))"
    by (simp add: pattern_environment_def)
  have separate: "{[]} \<inter> V = {}" using boundary by auto
  have quote: "pattern_quoted_at (pattern_environment f (Pattern_Variable a)) None V []
    (Pattern_Variable (f a)) {[]} {}"
    by (rule pattern_quoted_at.variable[OF ef source variable_syntax_citation[OF af] member separate])
  show ?case using quote by (simp add: rename_pattern_def rel_dom_def)
next
  case (Pattern_Target t)
  have tf: "target_formed t" using Pattern_Target.prems(1) by simp
  have ef: "environment_formed (pattern_environment f (Pattern_Target t))"
    by (rule pattern_environment_formed[OF Pattern_Target.prems(1,2)])
  have source: "artifact_at (pattern_environment f (Pattern_Target t)) None (literal_syntax t)"
    by (simp add: pattern_environment_def)
  have cite: "citation_at (literal_syntax t) [] (literal_citation t) (literal_interior t)"
    by (rule literal_syntax_citation[OF tf])
  have external: "citation_slots (literal_citation t) \<noteq> {}"
    by (simp add: literal_syntax_properties(5))
  have interpreted: "interpret_citation (pattern_environment f (Pattern_Target t)) None (literal_citation t) t"
    by (rule literal_syntax_interpretation[OF tf]) simp
  have leaf: "term_quoted_at (pattern_environment f (Pattern_Target t)) None [] (Target_Term t)
    (literal_interior t) (citation_slots (literal_citation t))"
    by (rule term_quoted_at.target[OF ef source cite external interpreted])
  have separate: "literal_interior t \<inter> V = {}"
    using literal_interior_outside_binders[of t] boundary by blast
  have quote: "pattern_quoted_at (pattern_environment f (Pattern_Target t)) None V []
    (Pattern_Target t) (literal_interior t) (citation_slots (literal_citation t))"
    by (rule pattern_quoted_at.target[OF leaf separate])
  show ?case using quote
    by (simp only: pattern_literal_slots pattern_syntax_interior.simps literal_syntax_properties(5))
       (simp add: rename_pattern_def)
next
  case (Pattern_Pair p q)
  let ?E = "pattern_environment f (Pattern_Pair p q)"
  let ?R = "bound_pair_syntax (pattern_syntax f p) (pattern_syntax f q)"
  have pf: "pattern_formed p" and qf: "pattern_formed q" using Pattern_Pair.prems(1) by auto
  have paddr: "binder_addressing (pattern_variables p) f"
    by (rule binder_addressing_mono[OF Pattern_Pair.prems(2)]) auto
  have qaddr: "binder_addressing (pattern_variables q) f"
    by (rule binder_addressing_mono[OF Pattern_Pair.prems(2)]) auto
  have pscope: "f ` pattern_variables p \<subseteq> V" and qscope: "f ` pattern_variables q \<subseteq> V"
    using Pattern_Pair.prems(3) by auto
  have ef: "environment_formed ?E" by (rule pattern_environment_formed[OF Pattern_Pair.prems(1,2)])
  have destination: "artifact_at ?E None ?R" by (simp add: pattern_environment_def)
  have rf: "exact_formed ?R" using pattern_syntax_formed[OF Pattern_Pair.prems(1,2)] by simp
  have rec: "record_at ?R [] [[0],[1]] [[2],[3]]" by (rule bound_pair_record[OF rf])
  have left_addressing: "finite_addressing (rra_carrier (object_structure (pattern_syntax f p))) (syntax_prefix 2)"
    by (rule syntax_prefix_addressing[OF pattern_syntax_formed[OF pf paddr]]) simp_all
  have right_addressing: "finite_addressing (rra_carrier (object_structure (pattern_syntax f q))) (syntax_prefix 3)"
    by (rule syntax_prefix_addressing[OF pattern_syntax_formed[OF qf qaddr]]) simp_all
  have left_reads: "object_reads_agree (push_object (syntax_prefix 2) (pattern_syntax f p)) ?R
    (syntax_prefix 2 ` pattern_syntax_interior p)"
    by (rule object_reads_agree_mono[OF bound_pair_reads_left[OF pattern_syntax_no_counts pattern_syntax_silent]])
       (auto simp: pattern_syntax_carrier[OF paddr])
  have right_reads: "object_reads_agree (push_object (syntax_prefix 3) (pattern_syntax f q)) ?R
    (syntax_prefix 3 ` pattern_syntax_interior q)"
    by (rule object_reads_agree_mono[OF bound_pair_reads_right[OF pattern_syntax_no_counts pattern_syntax_silent]])
       (auto simp: pattern_syntax_carrier[OF qaddr])
  have left_slots: "\<forall>k\<in>rel_dom (pattern_literal_bindings p).
    external_slot_values (pattern_environment f p) None k = external_slot_values ?E None (syntax_prefix 2 k)"
  proof (intro ballI)
    fix k assume member: "k \<in> rel_dom (pattern_literal_bindings p)"
    have outside: "k \<notin> binder_addresses" using pattern_literal_slots_outside[of p] member by blast
    show "external_slot_values (pattern_environment f p) None k = external_slot_values ?E None (syntax_prefix 2 k)"
      using pattern_environment_pair_slots(1)[OF outside, where f=f and p=p and q=q] by simp
  qed
  have right_slots: "\<forall>k\<in>rel_dom (pattern_literal_bindings q).
    external_slot_values (pattern_environment f q) None k = external_slot_values ?E None (syntax_prefix 3 k)"
  proof (intro ballI)
    fix k assume member: "k \<in> rel_dom (pattern_literal_bindings q)"
    have outside: "k \<notin> binder_addresses" using pattern_literal_slots_outside[of q] member by blast
    show "external_slot_values (pattern_environment f q) None k = external_slot_values ?E None (syntax_prefix 3 k)"
      using pattern_environment_pair_slots(2)[OF outside, where f=f and p=p and q=q] by simp
  qed
  have left_inj: "inj (syntax_prefix 2)" by (rule syntax_prefix_injective) simp
  have right_inj: "inj (syntax_prefix 3)" by (rule syntax_prefix_injective) simp
  have left_copy: "pattern_quoted_at ?E None (syntax_prefix 2 ` V) (syntax_prefix 2 [])
    (rename_pattern (syntax_prefix 2) (rename_pattern f p))
    (syntax_prefix 2 ` pattern_syntax_interior p) (syntax_prefix 2 ` rel_dom (pattern_literal_bindings p))"
    by (rule pattern_quotation_transport[OF Pattern_Pair.IH(1)[OF pf paddr pscope]
          pattern_environment_source left_addressing left_reads left_slots left_inj ef destination])
  have right_copy: "pattern_quoted_at ?E None (syntax_prefix 3 ` V) (syntax_prefix 3 [])
    (rename_pattern (syntax_prefix 3) (rename_pattern f q))
    (syntax_prefix 3 ` pattern_syntax_interior q) (syntax_prefix 3 ` rel_dom (pattern_literal_bindings q))"
    by (rule pattern_quotation_transport[OF Pattern_Pair.IH(2)[OF qf qaddr qscope]
          pattern_environment_source right_addressing right_reads right_slots right_inj ef destination])
  have left: "pattern_quoted_at ?E None V [2] (rename_pattern f p)
    (Cons 2 ` pattern_syntax_interior p) (Cons 2 ` rel_dom (pattern_literal_bindings p))"
    using left_copy by (simp only: syntax_prefix_image_binders[OF boundary] syntax_prefix_root
      renamed_pattern_prefix[OF paddr] syntax_prefix_image_outside[OF pattern_syntax_interior_outside]
      syntax_prefix_image_outside[OF pattern_literal_slots_outside])
  have right: "pattern_quoted_at ?E None V [3] (rename_pattern f q)
    (Cons 3 ` pattern_syntax_interior q) (Cons 3 ` rel_dom (pattern_literal_bindings q))"
    using right_copy by (simp only: syntax_prefix_image_binders[OF boundary] syntax_prefix_root
      renamed_pattern_prefix[OF qaddr] syntax_prefix_image_outside[OF pattern_syntax_interior_outside]
      syntax_prefix_image_outside[OF pattern_literal_slots_outside])
  have outside: "pattern_syntax_interior (Pattern_Pair p q) \<inter>
    (rel_dom (pattern_literal_bindings (Pattern_Pair p q)) \<union> V) = {}"
    using pattern_syntax_slot_boundary[of "Pattern_Pair p q"]
      pattern_syntax_interior_outside[of "Pattern_Pair p q"] boundary by blast
  have record_separate: "insert [] (set [[0],[1]]) \<inter>
    (Cons 2 ` pattern_syntax_interior p \<union> Cons 3 ` pattern_syntax_interior q) = {}" by auto
  have children_separate: "Cons 2 ` pattern_syntax_interior p \<inter> Cons 3 ` pattern_syntax_interior q = {}" by auto
  have slots_separate: "insert [] (set [[0],[1]] \<union> Cons 2 ` pattern_syntax_interior p \<union>
      Cons 3 ` pattern_syntax_interior q) \<inter>
    (Cons 2 ` rel_dom (pattern_literal_bindings p) \<union> Cons 3 ` rel_dom (pattern_literal_bindings q) \<union> V) = {}"
    using outside by (simp only: pattern_syntax_interior.simps pattern_literal_slots) auto
  have quote: "pattern_quoted_at ?E None V [] (Pattern_Pair (rename_pattern f p) (rename_pattern f q))
    (insert [] (set [[0],[1]] \<union> Cons 2 ` pattern_syntax_interior p \<union> Cons 3 ` pattern_syntax_interior q))
    (Cons 2 ` rel_dom (pattern_literal_bindings p) \<union> Cons 3 ` rel_dom (pattern_literal_bindings q))"
    by (rule pattern_quoted_at.pair[OF ef destination rec left right record_separate children_separate slots_separate])
  show ?case using quote
    by (simp only: pattern_syntax_interior.simps pattern_literal_slots) (simp add: rename_pattern_def)
qed

lemma scoped_pattern_encoding_exists:
  assumes formed: "pattern_formed p" and addressing: "binder_addressing (pattern_variables p) f"
    and distinct: "distinct [b,r,s,t]"
    and fresh: "{b,r,s,t} \<inter> rra_carrier (object_structure (pattern_syntax f p)) = {}"
    and addresses: "\<forall>a\<in>{b,r,s,t}. octets_formed a"
  shows "\<exists>E :: local_address option artifact_environment. \<exists>I K.
    artifact_at E None (scope_wrapper (pattern_syntax f p) (f ` pattern_variables p) b r s t) \<and>
    scoped_pattern_at E None r (rename_pattern f p) I K \<and>
    environment_closed E {None} ((\<lambda>k. (None,k)) ` K) \<and>
    rra_carrier (object_structure (scope_wrapper (pattern_syntax f p) (f ` pattern_variables p) b r s t)) = I \<union> K"
proof -
  let ?R = "pattern_syntax f p"
  let ?U = "rra_carrier (object_structure ?R)"
  let ?V = "f ` pattern_variables p"
  let ?J = "pattern_syntax_interior p"
  let ?K = "rel_dom (pattern_literal_bindings p)"
  let ?T = "scope_wrapper ?R ?V b r s t"
  let ?E = "literal_environment ?T (pattern_literal_bindings p)"
  let ?I = "insert r (set [s,t] \<union> insert b ?V \<union> ?J)"
  have rf: "exact_formed ?R" by (rule pattern_syntax_formed[OF formed addressing])
  have carrier: "?U = ?J \<union> ?K \<union> ?V" by (rule pattern_syntax_carrier[OF addressing])
  have vi: "?V \<subseteq> ?U" and ji: "?J \<subseteq> ?U" and ki: "?K \<subseteq> ?U" using carrier by blast+
  have vb: "?V \<subseteq> binder_addresses" using addressing by (simp add: binder_addressing_def)
  have tf: "exact_formed ?T" by (rule scope_wrapper_formed[OF rf pattern_syntax_root vi addresses])
  have slots_inside: "?K \<subseteq> rra_carrier (object_structure ?T)"
    using ki by (auto simp: scope_wrapper_def)
  have ef: "environment_formed ?E"
    by (rule literal_environment_formed[OF tf pattern_literal_bindings_finite
          pattern_literal_bindings_functional pattern_literal_bindings_formed[OF formed] slots_inside])
  have art: "artifact_at ?E None ?T" by simp
  have rec: "record_at ?T r [s,t] [b,[]]" by (rule scope_wrapper_record[OF rf tf distinct fresh])
  have family: "family_at ?T b ((\<lambda>a. (a,a)) ` ?V)"
    by (rule scope_wrapper_binders[OF rf tf pattern_syntax_silent vi vb distinct fresh])
  have scope: "binder_scope_at ?T b ?V" using family by (simp add: binder_scope_at_def)
  have original: "pattern_quoted_at (pattern_environment f p) None ?V [] (rename_pattern f p) ?J ?K"
    by (rule pattern_syntax_recovers[OF formed addressing _ vb]) simp
  have reads: "object_reads_agree ?R ?T ?J"
    by (rule object_reads_agree_mono[OF scope_wrapper_reads[OF fresh] ji])
  have slots: "\<forall>k\<in>?K. external_slot_values (pattern_environment f p) None k = external_slot_values ?E None k"
    by simp
  have body: "pattern_quoted_at ?E None ?V [] (rename_pattern f p) ?J ?K"
    by (rule pattern_quotation_embedding[OF original pattern_environment_source reads slots ef art])
  have top_separate: "insert r (set [s,t]) \<inter> (insert b ?V \<union> ?J) = {}"
    using distinct fresh vi ji by auto
  have binder_separate: "insert b ?V \<inter> ?J = {}"
    using pattern_syntax_interior_outside[of p] vb fresh ji by auto
  have key_separate: "?I \<inter> ?K = {}"
    using pattern_syntax_slot_boundary[of p] pattern_literal_slots_outside[of p] vb fresh ki by auto
  have scoped: "scoped_pattern_at ?E None r (rename_pattern f p) ?I ?K"
    unfolding scoped_pattern_at_def
    apply (rule conjI[OF ef])
    apply (rule exI[of _ ?T], rule exI[of _ "[s,t]"], rule exI[of _ b], rule exI[of _ "[]"],
        rule exI[of _ ?V], rule exI[of _ ?J])
    using art rec scope body top_separate binder_separate key_separate
    by (simp add: rename_pattern_variables)
  have closed: "environment_closed ?E {None} ((\<lambda>k. (None,k)) ` ?K)"
    by (rule literal_environment_closed[OF ef])
  have all_positions: "rra_carrier (object_structure ?T) = ?I \<union> ?K"
    using carrier by (auto simp: scope_wrapper_def)
  show ?thesis
    by (rule exI[of _ ?E], rule exI[of _ ?I], rule exI[of _ ?K])
       (use art scoped closed all_positions in blast)
qed

theorem scoped_pattern_representation_total:
  assumes formed: "pattern_formed p"
  shows "\<exists>f. \<exists>E :: local_address option artifact_environment. \<exists>R r I K.
    binder_addressing (pattern_variables p) f \<and>
    artifact_at E None R \<and> scoped_pattern_at E None r (rename_pattern f p) I K \<and>
    environment_closed E {None} ((\<lambda>k. (None,k)) ` K) \<and>
    rra_carrier (object_structure R) = I \<union> K"
proof -
  obtain f where addressing: "binder_addressing (pattern_variables p) f"
    using binder_addressing_exists[OF pattern_variables_finite, of p] by blast
  have rf: "exact_formed (pattern_syntax f p)" by (rule pattern_syntax_formed[OF formed addressing])
  have finite: "finite (rra_carrier (object_structure (pattern_syntax f p)))"
    using rf by (simp add: exact_formed_def object_formed_def rra_formed_def)
  obtain b r s t where positions: "distinct [b,r,s,t]"
    "{b,r,s,t} \<inter> rra_carrier (object_structure (pattern_syntax f p)) = {}"
    "\<forall>a\<in>{b,r,s,t}. octets_formed a"
    using fresh_four_addresses[OF finite] by auto
  obtain E :: "local_address option artifact_environment" and I K where result:
    "artifact_at E None (scope_wrapper (pattern_syntax f p) (f ` pattern_variables p) b r s t)"
    "scoped_pattern_at E None r (rename_pattern f p) I K"
    "environment_closed E {None} ((\<lambda>k. (None,k)) ` K)"
    "rra_carrier (object_structure (scope_wrapper (pattern_syntax f p) (f ` pattern_variables p) b r s t)) = I \<union> K"
    using scoped_pattern_encoding_exists[OF formed addressing positions] by (auto; blast)
  show ?thesis
    by (rule exI[of _ f], rule exI[of _ E],
        rule exI[of _ "scope_wrapper (pattern_syntax f p) (f ` pattern_variables p) b r s t"],
        rule exI[of _ r], rule exI[of _ I], rule exI[of _ K])
       (use addressing result in blast)
qed

text \<open>
  Every formed finite pattern has a native scoped quotation after injectively
  assigning its binder occurrences. The enclosing record declares exactly the
  variables used by the pattern. The finite environment is closed over exactly
  the recovered literal slots, and the complete source carrier is its syntax
  interior together with those slots. Constants retain their exact values.
\<close>

end
