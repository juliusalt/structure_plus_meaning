theory Factor_Term_Encoding
  imports Factor_Quotation RRA_Syntax_Construction
begin

section \<open>A finite native quotation for every formed term\<close>

fun term_syntax :: "factor_term \<Rightarrow> exact_artifact" where
  "term_syntax (Target_Term t) = literal_syntax t"
| "term_syntax (Pair_Term x y) = pair_syntax (term_syntax x) (term_syntax y)"

fun term_literal_bindings :: "factor_term \<Rightarrow> (local_address \<times> exact_artifact) set" where
  "term_literal_bindings (Target_Term t) = {([4],target_artifact t)}"
| "term_literal_bindings (Pair_Term x y) =
    (\<lambda>(k,R). (2#k,R)) ` term_literal_bindings x \<union>
    (\<lambda>(k,R). (3#k,R)) ` term_literal_bindings y"

fun term_syntax_interior :: "factor_term \<Rightarrow> local_address set" where
  "term_syntax_interior (Target_Term t) = literal_interior t"
| "term_syntax_interior (Pair_Term x y) =
    {[],[0],[1]} \<union> Cons 2 ` term_syntax_interior x \<union> Cons 3 ` term_syntax_interior y"

lemma term_literal_slots [simp]:
  "rel_dom (term_literal_bindings (Target_Term t)) = {[4]}"
  "rel_dom (term_literal_bindings (Pair_Term x y)) =
    Cons 2 ` rel_dom (term_literal_bindings x) \<union> Cons 3 ` rel_dom (term_literal_bindings y)"
  by (auto simp: rel_dom_def intro: rev_image_eqI)

lemma term_literal_bindings_finite [simp]:
  "finite (term_literal_bindings t)"
  by (induction t) auto

lemma term_literal_bindings_functional:
  "single_valued (term_literal_bindings t)"
  by (induction t) (auto simp: single_valued_def)

lemma term_literal_bindings_formed:
  assumes "term_formed t"
  shows "\<forall>k R. (k,R) \<in> term_literal_bindings t \<longrightarrow> exact_formed R"
  using assms
  by (induction t) (auto dest: target_formed_artifact)

lemma term_syntax_root [simp]:
  "[] \<in> rra_carrier (object_structure (term_syntax t))"
  by (cases t) (use literal_syntax_properties(1,2) in auto)

lemma term_syntax_no_counts [simp]:
  "bag_count (object_data (term_syntax t)) = (\<lambda>_. 0)"
  by (cases t) (simp_all add: literal_syntax_properties(4))

lemma term_syntax_formed:
  assumes "term_formed t"
  shows "exact_formed (term_syntax t)"
  using assms
  by (induction t) (auto intro: literal_syntax_formed pair_syntax_formed)

lemma term_syntax_carrier:
  "rra_carrier (object_structure (term_syntax t)) =
    term_syntax_interior t \<union> rel_dom (term_literal_bindings t)"
  by (induction t; simp only: term_literal_slots;
      auto simp: literal_syntax_properties(1) pair_syntax_def)

lemma term_syntax_slot_boundary:
  "term_syntax_interior t \<inter> rel_dom (term_literal_bindings t) = {}"
  by (induction t; simp only: term_literal_slots; auto simp: literal_syntax_properties(3))

definition term_environment :: "factor_term \<Rightarrow> local_address option artifact_environment" where
  "term_environment t = literal_environment (term_syntax t) (term_literal_bindings t)"

lemma term_environment_formed:
  assumes "term_formed t"
  shows "environment_formed (term_environment t)"
  unfolding term_environment_def
  by (rule literal_environment_formed[OF term_syntax_formed[OF assms]
        term_literal_bindings_finite term_literal_bindings_functional
        term_literal_bindings_formed[OF assms]])
     (simp add: term_syntax_carrier)

lemma term_environment_source [simp]:
  "artifact_at (term_environment t) None (term_syntax t)"
  by (simp add: term_environment_def)

lemma term_environment_slots [simp]:
  "external_slot_values (term_environment t) None k = {R. (k,R) \<in> term_literal_bindings t}"
  by (simp add: term_environment_def)

lemma term_environment_pair_slots [simp]:
  "external_slot_values (term_environment (Pair_Term x y)) None (2#k) =
    external_slot_values (term_environment x) None k"
  "external_slot_values (term_environment (Pair_Term x y)) None (3#k) =
    external_slot_values (term_environment y) None k"
  by auto

theorem term_syntax_recovers:
  assumes "term_formed t"
  shows "term_quoted_at (term_environment t) None [] t (term_syntax_interior t)
    (rel_dom (term_literal_bindings t))"
  using assms
proof (induction t)
  case (Target_Term t)
  have tf: "target_formed t" using Target_Term.prems by simp
  have ef: "environment_formed (term_environment (Target_Term t))"
    by (rule term_environment_formed[OF Target_Term.prems])
  have source: "artifact_at (term_environment (Target_Term t)) None (literal_syntax t)"
    by (simp add: term_environment_def)
  have cite: "citation_at (literal_syntax t) [] (literal_citation t) (literal_interior t)"
    by (rule literal_syntax_citation[OF tf])
  have external: "citation_slots (literal_citation t) \<noteq> {}"
    by (simp add: literal_syntax_properties(5))
  have interpreted: "interpret_citation (term_environment (Target_Term t)) None (literal_citation t) t"
    by (rule literal_syntax_interpretation[OF tf]) simp
  have "term_quoted_at (term_environment (Target_Term t)) None [] (Target_Term t)
    (literal_interior t) (citation_slots (literal_citation t))"
    by (rule term_quoted_at.target[OF ef source cite external interpreted])
  then show ?case
    by (simp only: term_literal_slots term_syntax_interior.simps literal_syntax_properties(5))
next
  case (Pair_Term x y)
  let ?E = "term_environment (Pair_Term x y)"
  let ?R = "pair_syntax (term_syntax x) (term_syntax y)"
  let ?L = "Cons 2 ` term_syntax_interior x"
  let ?Q = "Cons 3 ` term_syntax_interior y"
  let ?A = "Cons 2 ` rel_dom (term_literal_bindings x)"
  let ?B = "Cons 3 ` rel_dom (term_literal_bindings y)"
  have xf: "term_formed x" and yf: "term_formed y" using Pair_Term.prems by auto
  have ef: "environment_formed ?E" by (rule term_environment_formed[OF Pair_Term.prems])
  have destination: "artifact_at ?E None ?R" by (simp add: term_environment_def)
  have rf: "exact_formed ?R" using term_syntax_formed[OF Pair_Term.prems] by simp
  have rec: "record_at ?R [] [[0],[1]] [[2],[3]]" by (rule pair_syntax_record[OF rf])
  have left_addressing: "finite_addressing (rra_carrier (object_structure (term_syntax x))) (Cons 2)"
    by (rule prefix_addressing[OF term_syntax_formed[OF xf]]) simp
  have right_addressing: "finite_addressing (rra_carrier (object_structure (term_syntax y))) (Cons 3)"
    by (rule prefix_addressing[OF term_syntax_formed[OF yf]]) simp
  have left_reads: "object_reads_agree (push_object (Cons 2) (term_syntax x)) ?R ?L"
    by (rule object_reads_agree_mono[OF pair_syntax_reads_left[OF term_syntax_no_counts]])
       (auto simp: term_syntax_carrier)
  have right_reads: "object_reads_agree (push_object (Cons 3) (term_syntax y)) ?R ?Q"
    by (rule object_reads_agree_mono[OF pair_syntax_reads_right[OF term_syntax_no_counts]])
       (auto simp: term_syntax_carrier)
  have left_slots: "\<forall>k\<in>rel_dom (term_literal_bindings x).
    external_slot_values (term_environment x) None k = external_slot_values ?E None (2#k)"
    by (simp only: term_environment_pair_slots; blast)
  have right_slots: "\<forall>k\<in>rel_dom (term_literal_bindings y).
    external_slot_values (term_environment y) None k = external_slot_values ?E None (3#k)"
    by (simp only: term_environment_pair_slots; blast)
  have left: "term_quoted_at ?E None [2] x ?L ?A"
    by (rule term_quotation_transport[OF Pair_Term.IH(1)[OF xf] term_environment_source
          left_addressing left_reads left_slots ef destination])
  have right: "term_quoted_at ?E None [3] y ?Q ?B"
    by (rule term_quotation_transport[OF Pair_Term.IH(2)[OF yf] term_environment_source
          right_addressing right_reads right_slots ef destination])
  have boundary: "insert [] ({[0],[1]} \<union> ?L \<union> ?Q) \<inter> (?A \<union> ?B) = {}"
    using term_syntax_slot_boundary[of x] term_syntax_slot_boundary[of y] by auto
  have "term_quoted_at ?E None [] (Pair_Term x y)
    (insert [] (set [[0],[1]] \<union> ?L \<union> ?Q)) (?A \<union> ?B)"
    by (rule term_quoted_at.pair[OF ef destination rec left right])
       (use boundary in auto)
  then show ?case by (simp only: term_literal_slots term_syntax_interior.simps) auto
qed

theorem term_quotation_total:
  assumes "term_formed t"
  shows "\<exists>E :: local_address option artifact_environment. \<exists>R I K.
    environment_formed E \<and> artifact_at E None R \<and>
    term_quoted_at E None [] t I K \<and>
    rra_carrier (object_structure R) = I \<union> K"
  using term_environment_formed[OF assms] term_environment_source[of t]
    term_syntax_recovers[OF assms] term_syntax_carrier[of t]
  by blast

theorem term_quotation_closed_total:
  assumes "term_formed t"
  shows "term_quoted_at (term_environment t) None [] t (term_syntax_interior t)
      (rel_dom (term_literal_bindings t)) \<and>
    environment_closed (term_environment t) {None}
      ((\<lambda>k. (None,k)) ` rel_dom (term_literal_bindings t))"
proof
  show "term_quoted_at (term_environment t) None [] t (term_syntax_interior t)
    (rel_dom (term_literal_bindings t))" by (rule term_syntax_recovers[OF assms])
  show "environment_closed (term_environment t) {None}
    ((\<lambda>k. (None,k)) ` rel_dom (term_literal_bindings t))"
    unfolding term_environment_def
    by (rule literal_environment_closed)
       (use term_environment_formed[OF assms] in \<open>simp add: term_environment_def\<close>)
qed

text \<open>
  The environment contains a source use and one target use per literal slot.
  Its values and bindings are finite. Closure is checked against exactly the
  slots recovered by the quotation reader. Its source carrier contains exactly
  the recursively constructed syntax interior and literal slots. Every formed
  term has this representation, regardless of the size of its exact operands.
  This existence theorem does not identify all possible presentations of a term.
\<close>

end
