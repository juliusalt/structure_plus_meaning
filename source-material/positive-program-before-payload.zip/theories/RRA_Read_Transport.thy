theory RRA_Read_Transport
  imports RRA_Structural_Syntax
begin

section \<open>Agreement on the observations used by structural readers\<close>

definition object_reads_agree ::
  "('a,'v) structured_object \<Rightarrow> ('a,'v) structured_object \<Rightarrow> 'a set \<Rightarrow> bool" where
  "object_reads_agree obj other I \<longleftrightarrow>
    I \<subseteq> rra_carrier (object_structure obj) \<and> I \<subseteq> rra_carrier (object_structure other) \<and>
    (\<forall>a\<in>I. headed_incidence (object_structure obj) a = headed_incidence (object_structure other) a) \<and>
    restrict_basis I (object_data obj) = restrict_basis I (object_data other)"

lemma basis_restriction_agreement_mono:
  assumes same: "restrict_basis I D = restrict_basis I E" and subset: "J \<subseteq> I"
  shows "restrict_basis J D = restrict_basis J E"
proof -
  have inter: "J \<inter> I = J" using subset by blast
  have "restrict_basis J D = restrict_basis J (restrict_basis I D)"
    by (simp add: restriction_composes inter)
  also have "\<dots> = restrict_basis J (restrict_basis I E)"
    by (rule arg_cong[where f="restrict_basis J", OF same])
  also have "\<dots> = restrict_basis J E" by (simp add: restriction_composes inter)
  finally show ?thesis .
qed

lemma object_reads_agree_mono:
  assumes agree: "object_reads_agree obj other I" and subset: "J \<subseteq> I"
  shows "object_reads_agree obj other J"
proof -
  have data: "restrict_basis I (object_data obj) = restrict_basis I (object_data other)"
    using agree by (simp add: object_reads_agree_def)
  have restricted: "restrict_basis J (object_data obj) = restrict_basis J (object_data other)"
    by (rule basis_restriction_agreement_mono[OF data subset])
  show ?thesis using agree subset restricted by (auto simp: object_reads_agree_def)
qed

lemma object_reads_agree_symmetric:
  "object_reads_agree obj other I \<longleftrightarrow> object_reads_agree other obj I"
  by (auto simp: object_reads_agree_def)

lemma object_reads_payload:
  assumes agree: "object_reads_agree obj other I" and member: "a \<in> I"
  shows "payload_at obj a v \<longleftrightarrow> payload_at other a v"
proof -
  have small: "object_reads_agree obj other {a}"
    by (rule object_reads_agree_mono[OF agree]) (use member in simp)
  have data: "restrict_basis {a} (object_data obj) = restrict_basis {a} (object_data other)"
    using small by (simp add: object_reads_agree_def)
  show ?thesis by (simp only: payload_at_def data)
qed

lemma record_at_read_transport:
  assumes source: "record_at obj r ps xs" and target: "object_formed other"
    and agree: "object_reads_agree obj other I" and inside: "insert r (set ps) \<subseteq> I"
  shows "record_at other r ps xs"
proof -
  have small: "object_reads_agree obj other (insert r (set ps))"
    by (rule object_reads_agree_mono[OF agree inside])
  have root: "r \<in> rra_carrier (object_structure other)"
    and heads: "\<And>a. a \<in> insert r (set ps) \<Longrightarrow>
      headed_incidence (object_structure obj) a = headed_incidence (object_structure other) a"
    using small by (auto simp: object_reads_agree_def)
  have source_data: "restrict_basis (insert r (set ps)) (object_data obj) = empty_basis"
    using source by (simp add: record_at_def)
  have target_data: "restrict_basis (insert r (set ps)) (object_data other) = empty_basis"
    using small source_data by (simp add: object_reads_agree_def)
  show ?thesis by (rule record_at_same_heads[OF source target root heads target_data])
qed

lemma citation_at_read_transport:
  assumes cite: "citation_at R r c I" and formed: "exact_formed S"
    and agree: "object_reads_agree R S I"
  shows "citation_at S r c I"
proof -
  have raw: "raw_citation_at R r c I"
    and empty: "restrict_basis {r} (object_data R) = empty_basis"
    using cite by (auto simp: citation_at_def)
  have root: "r \<in> I" by (rule raw_citation_interior(2)[OF raw])
  have heads: "\<And>a. a \<in> I \<Longrightarrow>
    headed_incidence (object_structure R) a = headed_incidence (object_structure S) a"
    using agree by (simp add: object_reads_agree_def)
  have payloads: "\<And>a v. a \<in> I \<Longrightarrow> payload_at R a v = payload_at S a v"
    by (rule object_reads_payload[OF agree])
  have carrier: "r \<in> rra_carrier (object_structure S)"
    using agree root by (auto simp: object_reads_agree_def)
  have small: "object_reads_agree R S {r}"
    by (rule object_reads_agree_mono[OF agree]) (use root in simp)
  have data: "restrict_basis {r} (object_data S) = empty_basis"
    using small empty by (simp add: object_reads_agree_def)
  have recovered: "raw_citation_at S r c I"
  proof (cases rule: raw_citation_at.cases[OF raw, case_names local local_whole external_whole external])
    case (local a)
    have "raw_citation_at S r (Local a) {r}"
      by (rule raw_citation_at.local) (use local heads[OF root] in simp)
    then show ?thesis using local by simp
  next
    case local_whole
    have "raw_citation_at S r Local_Whole {r}"
      by (rule raw_citation_at.local_whole) (use local_whole heads[OF root] in simp)
    then show ?thesis using local_whole by simp
  next
    case (external_whole k)
    have "raw_citation_at S r (External_Whole k) {r}"
      by (rule raw_citation_at.external_whole) (use external_whole heads[OF root] in auto)
    then show ?thesis using external_whole by simp
  next
    case (external k d a)
    have member: "d \<in> I" using external by simp
    have "raw_citation_at S r (External k a) {r,d}"
      by (rule raw_citation_at.external)
         (use external heads[OF root] heads[OF member] payloads[OF member, of a] in auto)
    then show ?thesis using external by simp
  qed
  show ?thesis using formed carrier data recovered by (simp add: citation_at_def)
qed

text \<open>
  This agreement describes the fields read by the syntax recognizers. It is
  weaker than complete incident-star equality: an enclosing record can add
  incoming incidences at a quoted root. Those incidences remain part of the
  target's explicit footprint boundary. This relation neither identifies exact
  artifacts nor establishes semantic agreement on observed exact targets.
\<close>

end
